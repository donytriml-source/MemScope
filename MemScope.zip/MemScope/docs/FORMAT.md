# MemScope capture format — `.msc`

**Format id:** `MemScope.Capture`
**Format version:** `1`
**Container:** gzip-compressed UTF-8 JSON (RFC 1952). A plain `.json` file containing the same object is also accepted.

MemScope sniffs the first two bytes before decoding. `0x1F 0x8B` means gzip; anything else is parsed as plain JSON.

---

## 1. Top-level object

```jsonc
{
  "format": "MemScope.Capture",
  "formatVersion": 1,
  "app": "MemScope 1.0.0 · Obsidian · Release",
  "metadata": { ... },
  "modules": [ ... ],
  "frames": [ ... ],
  "stacks": [ ... ],
  "events": { ... },
  "snapshots": [ ... ],
  "heaps": [ ... ],
  "sourceFiles": { ... }
}
```

| Field | Required | Notes |
| --- | --- | --- |
| `format` | yes | Must equal `MemScope.Capture`. |
| `formatVersion` | yes | Readers reject versions newer than they support. |
| `app` | no | Free-form producer line. |
| `metadata` | recommended | Identity and target description. |
| `modules` | no | Loaded images referenced by frame indexes. |
| `frames` | no | Interned, symbolised stack frames. |
| `stacks` | no | Aggregated allocation paths. |
| `events` | no | Columnar allocation timeline; omit for aggregate-only captures. |
| `snapshots` | no | Point-in-time statistics used by the timeline. |
| `heaps` | no | Native heaps and committed sizes. |
| `sourceFiles` | no | Reconstructed source keyed by absolute path. |

Unknown properties are ignored, so producers may add fields without breaking readers.

## 2. Metadata

```jsonc
"metadata": {
  "captureId": "9f2c...",
  "name": "Aurora Studio · frame capture",
  "targetProcess": "AuroraStudio.exe",
  "targetPath": "C:\\Program Files\\Aurora\\AuroraStudio.exe",
  "machineName": "STUDIO-01",
  "operatingSystem": "Microsoft Windows NT 10.0.22631.0",
  "capturedAt": "2026-11-15T18:44:09.5120000+03:00",
  "durationMs": 8620,
  "samplingIntervalMs": 250,
  "pointerSize": 8,
  "threadCount": 6,
  "heapCount": 6,
  "processorCount": 28,
  "origin": "Capture",
  "toolVersion": "1.0.0",
  "notes": "",
  "isSynthetic": false,
  "tags": ["render-loop"]
}
```

`origin` is `Capture`, `Live` or `Synthetic`. `isSynthetic` marks the built-in walkthrough.
Dates use ISO 8601 with offset.

## 3. Modules

```jsonc
"modules": [
  {
    "name": "AuroraStudio.exe",
    "path": "C:\\Program Files\\Aurora\\AuroraStudio.exe",
    "version": "3.4.1.0",
    "baseAddress": 140695296,
    "imageSize": 8454144,
    "isManaged": true,
    "isSystem": false,
    "pdbPath": "C:\\Symbols\\AuroraStudio.pdb"
  }
]
```

`frames[].m` is an index into this array (`-1` when unknown).

## 4. Frames

```jsonc
"frames": [
  { "i": 0, "a": 14069529984, "m": 0, "f": "AuroraStudio.AppHost.RunRenderLoop()", "s": "D:\\aurora\\AppHost.cs", "l": 214 }
]
```

| Key | Meaning |
| --- | --- |
| `i` | Frame id (unique within the capture). |
| `a` | Absolute address. `0` when unavailable. |
| `m` | Module index, or `-1`. |
| `f` | Display function signature. `"Unknown"` is allowed. |
| `s` | Source file path, or `null`. |
| `l` | Source line, `0` when unavailable. |

## 5. Stacks

One record per unique call path. Frames are ordered **leaf → root**.

```jsonc
"stacks": [
  {
    "i": 0,
    "f": [12, 8, 3, 1],
    "al": 36700,
    "fr": 18000,
    "re": 794,
    "lv": 734228,
    "pk": 812000,
    "tt": 1048576,
    "th": 4212,
    "hp": "Render arena",
    "ls": [0, 120000, 310000, 734228]
  }
]
```

| Key | Meaning |
| --- | --- |
| `i` | Stack id. |
| `f` | Frame ids, leaf first. |
| `al` | Allocation count. |
| `fr` | Free count. |
| `re` | Reallocation count. |
| `lv` | Live bytes retained. |
| `pk` | Peak bytes. |
| `tt` | Total bytes ever allocated. |
| `th` | Thread id that produced the path. |
| `hp` | Heap name. Defaults to `Process heap`. |
| `ls` | Optional live bytes per snapshot, parallel to `snapshots`. |

Consumers should tolerate unknown keys and derive anything missing.

## 6. Events (columnar)

Events are stored as parallel arrays rather than objects, keeping captures compact.

```jsonc
"events": {
  "a": [14069529984, 14069530112],
  "s": [4096, 128],
  "k": [0, 2],
  "t": [0, 12],
  "st": [0, 0],
  "th": [4212, 4212]
}
```

| Key | Type | Meaning |
| --- | --- | --- |
| `a` | `long[]` | Addresses. |
| `s` | `int[]` | Sizes in bytes. |
| `k` | `byte[]` | `0` allocate, `1` reallocate, `2` free. |
| `t` | `int[]` | Milliseconds since capture start, clamped to `Int32.MaxValue`. |
| `st` | `int[]` | Stack id, or `-1`. |
| `th` | `int[]` | Thread id. |

All arrays should share the same length. Readers fall back to safe defaults when an optional column is short or missing.

## 7. Snapshots

```jsonc
"snapshots": [
  {
    "name": "S1",
    "timestampMs": 0,
    "usageBytes": 1048576,
    "peakBytes": 1048576,
    "overheadBytes": 65536,
    "peakOverheadBytes": 65536,
    "operations": 1200,
    "allocations": 980,
    "reallocations": 22,
    "frees": 240,
    "liveBlocks": 742,
    "heapCount": 6,
    "threadCount": 6,
    "note": "warm-up"
  }
]
```

Snapshots drive the memory timeline and the histogram envelope. They are independent of `events`; a capture may contain either, both or neither.

## 8. Heaps

```jsonc
"heaps": [
  { "id": 140000, "name": "Render arena", "blockCount": 25000, "committedBytes": 3400000, "isDefault": false, "isShared": false }
]
```

## 9. Source files

```jsonc
"sourceFiles": {
  "D:\\aurora\\AppHost.cs": "using Aurora.Render;\n\nnamespace AuroraStudio;\n..."
}
```

Keys are absolute paths as they appeared in `frames[].s`. Values are UTF-8 text. Missing entries simply disable the source viewer for that frame.

## 10. Exports

| Export | Shape |
| --- | --- |
| Branded HTML | Self-contained report with timeline, histogram, observations, top backtraces and MR8AD AL-Tmimi attribution. |
| Call-tree CSV | One row per backtrace: title, module, file, line, live, peak, allocations, frees, reallocations, score. |
| Metrics JSON | Metadata, statistics, top stacks and snapshots for downstream tooling. |

Exports never include `sourceFiles`, keeping reports small.

## 11. Compatibility rules

1. Bump `formatVersion` for breaking changes only.
2. Additive keys do not change the version; readers ignore what they do not know.
3. A reader must reject an unknown `format` and a newer `formatVersion` with a clear message — MemScope does both.
4. Producers should write gzip unless a human-readable capture is explicitly requested.
