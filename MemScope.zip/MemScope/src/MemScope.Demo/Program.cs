using System.Diagnostics;
using System.Text;

namespace MemScope.Demo;

/// <summary>
/// A deliberately leaky render-loop simulation. Attach MemScope to this process to watch
/// the working set climb, the heap grow and the allocation histogram move in real time.
/// Crafted for MemScope by MR8AD AL-Tmimi.
/// </summary>
internal static class Program
{
    private const int TargetFramesPerSecond = 60;
    private const int FrameBudgetMs = 16;
    private const int LeakEveryFrames = 30;
    private const int LeakBlockBytes = 768 * 1024;
    private const int LeakCeilingBlocks = 420; // ~315 MB before recycling the oldest atlas

    private static readonly List<byte[]> Retained = new();
    private static readonly List<byte[]> Churn = new();
    private static long _leakedBytes;
    private static long _frame;
    private static volatile bool _running = true;

    private static void Main()
    {
        try { Console.OutputEncoding = Encoding.UTF8; } catch { /* redirected console */ }
        Console.Title = "MemScope.Demo — Aurora Studio (leaky render loop)";

        Console.WriteLine("┌──────────────────────────────────────────────────────────────┐");
        Console.WriteLine("│  AURORA STUDIO · synthetic render pipeline                   │");
        Console.WriteLine("│  MemScope live-monitor demo · crafted by MR8AD AL-Tmimi      │");
        Console.WriteLine("└──────────────────────────────────────────────────────────────┘");
        Console.WriteLine();
        Console.WriteLine("This process intentionally retains render-target atlases.");
        Console.WriteLine("In MemScope: Live monitor → pick 'MemScope.Demo' → Attach.");
        Console.WriteLine("Press Ctrl+C to stop.");
        Console.WriteLine();

        Console.CancelKeyPress += (_, e) =>
        {
            e.Cancel = true;
            _running = false;
        };

        var random = new Random(8);
        var clock = Stopwatch.StartNew();
        var process = Process.GetCurrentProcess();
        long nextReport = 0;

        while (_running)
        {
            var frameStart = clock.ElapsedMilliseconds;

            // Short-lived per-frame churn: vertex buffers, draw commands, tokens.
            for (int i = 0; i < 110; i++)
            {
                Churn.Add(new byte[random.Next(48, 8192)]);
            }
            if (Churn.Count > 1200) Churn.RemoveRange(0, 640);

            // The leak: an atlas that is appended to the retained list and never released.
            if (_frame % LeakEveryFrames == 0)
            {
                var atlas = new byte[LeakBlockBytes];
                random.NextBytes(atlas);
                Retained.Add(atlas);
                _leakedBytes += atlas.Length;
                if (Retained.Count > LeakCeilingBlocks)
                {
                    Retained.RemoveAt(0);
                    _leakedBytes -= LeakBlockBytes;
                }
            }

            _frame++;

            if (clock.ElapsedMilliseconds >= nextReport)
            {
                nextReport = clock.ElapsedMilliseconds + 2000;
                process.Refresh();
                double fps = _frame / Math.Max(0.001, clock.Elapsed.TotalSeconds);
                Console.WriteLine(
                    $"[{clock.Elapsed:mm\\:ss}] frame {_frame,6:N0}  {fps,5:0.0} fps  " +
                    $"working set {process.WorkingSet64 / 1024.0 / 1024.0,7:0.0} MB  " +
                    $"retained {_leakedBytes / 1024.0 / 1024.0,7:0.0} MB  " +
                    $"managed {GC.GetTotalMemory(false) / 1024.0 / 1024.0,6:0.0} MB");
            }

            int elapsed = (int)(clock.ElapsedMilliseconds - frameStart);
            int sleep = FrameBudgetMs - elapsed;
            if (sleep > 0) Thread.Sleep(sleep);
        }

        Console.WriteLine();
        Console.WriteLine($"Demo stopped after {_frame:N0} frames. Every byte released with the process.");
        Console.WriteLine("© 2026 MR8AD AL-Tmimi");
    }
}
