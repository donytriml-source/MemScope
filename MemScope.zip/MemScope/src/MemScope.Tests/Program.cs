using MemScope.Core;
using MemScope.Core.Analysis;
using MemScope.Core.Models;
using MemScope.Core.Sessions;
using MemScope.Core.Util;

namespace MemScope.Tests;

/// <summary>Dependency-free verification harness for the MemScope engine.</summary>
internal static class Program
{
    private static int _passed;
    private static int _failed;

    private static int Main()
    {
        Banner();
        var session = DemoSessionFactory.Create();

        Check("demo capture builds", session.Stacks.Count > 30);
        Check("demo has frames", session.Frames.Count > 40);
        Check("demo has modules", session.Modules.Count >= 10);
        Check("demo timeline", session.Snapshots.Count == 12);
        Check("demo events sampled", session.Events.Count > 5_000);
        Check("demo source reconstructed", session.SourceFiles.Count >= 8);
        Check("live heap matches authored target", Math.Abs(session.ComputeStatistics().UsageBytes - 7_996_210) < 20_000);

        var stats = session.ComputeStatistics();
        Check("allocations exceed live blocks", stats.Allocations > stats.LiveBlocks);
        Check("peak >= live", stats.PeakUsageBytes >= stats.UsageBytes);
        Check("overhead positive", stats.OverheadBytes > 0);
        Check("snapshot stats scoped", session.ComputeStatistics(3).IsSnapshotScoped);

        var baseline = DemoSessionFactory.CreateBaseline();
        Check("walkthrough baseline builds", baseline.Stacks.Count == session.Stacks.Count - 3);
        Check("walkthrough baseline retains less", baseline.TotalLiveBytes < session.TotalLiveBytes);
        var walkthroughDiff = SessionComparer.Compare(baseline, session);
        Check("walkthrough diff shows growth", walkthroughDiff.GrownCount > 0 && walkthroughDiff.Delta > 0);
        Check("walkthrough diff shows shrinkage", walkthroughDiff.ShrunkCount > 0);
        Check("walkthrough diff shows new paths", walkthroughDiff.NewCount == 3);
        Check("walkthrough diff resolved none", walkthroughDiff.ResolvedCount == 0);

        var tree = CallTreeBuilder.Build(session);
        Check("call tree roots", tree.Children.Count > 0);
        Check("call tree usage equals live heap", tree.Usage == stats.UsageBytes);
        Check("root children sorted", tree.Children.Zip(tree.Children.Skip(1)).All(p => p.First.Usage >= p.Second.Usage));
        Check("tree percentages bounded", tree.Children.All(c => c.Share is > 0 and <= 1.0000001));
        Check("tree depth", MaxDepth(tree) >= 6);

        var filtered = CallTreeBuilder.Build(session, new CallTreeOptions { Search = "TextureCache" });
        Check("search filter keeps ancestors", filtered.Children.Count > 0 && filtered.Children[0].Usage > 0);
        Check("search filter finds target", Flatten(filtered).Any(n => n.Name.Contains("TextureCache", StringComparison.OrdinalIgnoreCase)));

        var grouped = CallTreeBuilder.Build(session, new CallTreeOptions { GroupByModule = true });
        Check("module grouping active", grouped.Children.All(c => c.IsGroup));

        var untracked = session.Stacks.Count(s => s.Allocations == 0);
        Check("all demo stacks tracked", untracked == 0);

        var hotspots = HotspotAnalyzer.Analyze(session, HotspotMode.LiveBytes, 25);
        Check("hotspots ranked", hotspots.Count == 25 && hotspots[0].Score >= hotspots[^1].Score);

        var leaks = LeakAnalyzer.Analyze(session, 20);
        Check("leak analysis produces candidates", leaks.Count > 0);
        Check("leak confidence assigned", leaks.All(l => Enum.IsDefined(l.Confidence)));

        var histogram = HistogramBuilder.Build(session);
        Check("histogram buckets", histogram.Buckets.Count == HistogramBuilder.Ranges.Length);
        Check("histogram totals", histogram.Buckets.Sum(b => b.Count) == histogram.TotalCount);
        Check("histogram has bytes", histogram.TotalBytes > 0);

        var timeline = TimelineBuilder.Build(session);
        Check("timeline points", timeline.Points.Count == session.Snapshots.Count);
        Check("timeline growth positive", timeline.Delta > 0);
        Check("timeline max", timeline.MaxUsage >= timeline.EndUsage);

        var insights = InsightAnalyzer.Analyze(session);
        Check("insights produced", insights.Count >= 3);

        var tiles = TreemapLayout.Build(tree, 900, 500, maxDepth: 3);
        Check("treemap produces tiles", tiles.Count > 10);
        Check("treemap inside bounds", tiles.All(t => t.X >= -0.5 && t.Y >= -0.5 && t.X + t.Width <= 900.5 && t.Y + t.Height <= 500.5));
        Check("treemap area sane", tiles.Sum(t => t.Area) > 0);

        var copy = session;
        var diff = SessionComparer.Compare(copy, session);
        Check("self diff balanced", diff.Delta == 0 && diff.NewCount == 0 && diff.ResolvedCount == 0);

        var tmp = Path.Combine(Path.GetTempPath(), $"memscope-{Guid.NewGuid():N}.msc");
        try
        {
            SessionSerializer.Save(session, tmp);
            Check("serialized file exists", File.Exists(tmp));
            var loaded = SessionSerializer.Load(tmp);
            Check("round-trip stacks", loaded.Stacks.Count == session.Stacks.Count);
            Check("round-trip frames", loaded.Frames.Count == session.Frames.Count);
            Check("round-trip events", loaded.Events.Count == session.Events.Count);
            Check("round-trip snapshots", loaded.Snapshots.Count == session.Snapshots.Count);
            Check("round-trip live bytes", loaded.ComputeStatistics().UsageBytes == stats.UsageBytes);
            Check("round-trip source", loaded.SourceFiles.Count == session.SourceFiles.Count);
            Check("capture identification", SessionSerializer.IsMemScopeCapture(tmp));
        }
        finally
        {
            if (File.Exists(tmp)) File.Delete(tmp);
        }

        var csv = Path.Combine(Path.GetTempPath(), $"memscope-{Guid.NewGuid():N}.csv");
        var html = Path.Combine(Path.GetTempPath(), $"memscope-{Guid.NewGuid():N}.html");
        try
        {
            SessionExporter.ExportFlattenedCallTreeCsv(session, tree, csv);
            Check("csv exported", new FileInfo(csv).Length > 500);
            SessionExporter.ExportHtmlReport(session, html);
            var report = File.ReadAllText(html);
            Check("html report branded", report.Contains("MR8AD AL-Tmimi") && report.Contains("MemScope"));
            Check("html report has timeline", report.Contains("Memory timeline") && report.Contains("<svg"));
        }
        finally
        {
            if (File.Exists(csv)) File.Delete(csv);
            if (File.Exists(html)) File.Delete(html);
        }

        Console.WriteLine();
        Console.WriteLine($"  Statistics  : {Humanize.Bytes(stats.UsageBytes)} live · {Humanize.Count(stats.Allocations)} allocs · {Humanize.Bytes(stats.PeakUsageBytes)} peak");
        Console.WriteLine($"  Backtraces  : {session.Stacks.Count} · frames {session.Frames.Count} · tree depth {MaxDepth(tree)}");
        Console.WriteLine($"  Leaks       : {leaks.Count} candidates · top {leaks.FirstOrDefault()?.Title}");
        Console.WriteLine();

        // Persist the bundled sample capture so the repository ships with a ready capture.
        try
        {
            var samplePath = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "..", "samples", "aurora-demo.msc"));
            SessionSerializer.Save(session, samplePath);
            Console.WriteLine($"  Sample capture written → {samplePath}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"  (sample capture skipped: {ex.Message})");
        }

        Console.WriteLine();
        Console.WriteLine($"  RESULT: {_passed} passed, {_failed} failed");
        return _failed == 0 ? 0 : 1;
    }

    private static IEnumerable<CallTreeNode> Flatten(CallTreeNode node)
    {
        foreach (var child in node.Children)
        {
            yield return child;
            foreach (var nested in Flatten(child)) yield return nested;
        }
    }

    private static int MaxDepth(CallTreeNode node)
    {
        int best = 0;
        foreach (var child in node.Children) best = Math.Max(best, MaxDepth(child));
        return best + 1;
    }

    private static void Check(string name, bool condition)
    {
        if (condition)
        {
            _passed++;
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.Write("  PASS  ");
            Console.ResetColor();
            Console.WriteLine(name);
        }
        else
        {
            _failed++;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("  FAIL  ");
            Console.ResetColor();
            Console.WriteLine(name);
        }
    }

    private static void Banner()
    {
        Console.ForegroundColor = ConsoleColor.DarkYellow;
        Console.WriteLine();
        Console.WriteLine("  ┌──────────────────────────────────────────────────────────────┐");
        Console.WriteLine("  │  MEMSCOPE · ENGINE VERIFICATION                              │");
        Console.WriteLine("  │  © 2026 MR8AD AL-Tmimi                                       │");
        Console.WriteLine("  └──────────────────────────────────────────────────────────────┘");
        Console.ResetColor();
        Console.WriteLine();
    }
}
