using System.Text;
using MemScope.Core.Models;

namespace MemScope.Core.Sessions;

/// <summary>
/// Reconstructs plausible C# source for the synthetic demo symbols so the source
/// viewer can be explored end-to-end. Real captures read sources from disk instead.
/// </summary>
internal static class DemoSourceLibrary
{
    private const string Root = @"C:\Projects\Aurora\src\";

    public static Dictionary<string, string> Build(IEnumerable<FrameInfo> frames)
    {
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var groups = frames
            .Where(f => f.Line > 0 && !string.IsNullOrWhiteSpace(f.File) && f.File.StartsWith(Root, StringComparison.OrdinalIgnoreCase))
            .GroupBy(f => f.File, StringComparer.OrdinalIgnoreCase);

        foreach (var group in groups)
        {
            var ordered = group.OrderBy(f => f.Line).ToList();
            if (ordered.Count == 0) continue;
            result[group.Key] = BuildFile(group.Key, ordered);
        }
        return result;
    }

    private static string BuildFile(string path, IReadOnlyList<FrameInfo> functions)
    {
        var fileName = Path.GetFileName(path);
        var folder = Path.GetFileName(Path.GetDirectoryName(path) ?? "Aurora");
        var className = Path.GetFileNameWithoutExtension(path).Replace('.', '_');
        string ns = folder.StartsWith("Aurora", StringComparison.OrdinalIgnoreCase) ? folder : "Aurora";
        if (fileName.Contains("MainWindow")) ns = "AuroraStudio";
        if (fileName.Equals("Program.cs", StringComparison.OrdinalIgnoreCase)) ns = "AuroraStudio";

        var lines = new List<string>
        {
            "// ─────────────────────────────────────────────────────────────────────────────",
            $"//  Aurora Studio · {fileName}",
            "//  Reconstructed by MemScope from the demo symbol map.",
            "//  © 2026 MR8AD AL-Tmimi · MemScope synthetic walkthrough sample",
            "// ─────────────────────────────────────────────────────────────────────────────",
            "",
            "using System;",
            "using System.Buffers;",
            "using System.Diagnostics;",
            "using System.Runtime.CompilerServices;",
            "",
            $"namespace {ns};",
            "",
            $"/// <summary>{className} — demo surface reconstructed for the walkthrough capture.</summary>",
            $"internal sealed class {className}",
            "{"
        };

        int section = 0;
        foreach (var function in functions)
        {
            int signatureIndex = Math.Max(lines.Count, function.Line - 1);
            PadTo(lines, signatureIndex, ref section);

            string name = ExtractName(function.Function);
            string parameters = ExtractParameters(function.Function);
            string returnType = GuessReturnType(name);
            lines.Add($"        internal {returnType} {name}({parameters})");
            lines.Add("        {");
            lines.Add($"            using var scope = MemScope.Agent.Scope.Begin(\"{name}\");");
            lines.Add($"            var buffer = ArrayPool<byte>.Shared.Rent({Math.Max(256, (function.Line * 97) % 65536)});");
            lines.Add("            try");
            lines.Add("            {");
            lines.Add("                Metrics.Counters.Increment(\"alloc.bytes\", buffer.Length);");
            lines.Add("                buffer.AsSpan().Fill(0x2A);");
            lines.Add("                RuntimeHelpers.PrepareConstrainedRegions();");
            lines.Add("            }");
            lines.Add("            finally");
            lines.Add("            {");
            lines.Add("                ArrayPool<byte>.Shared.Return(buffer);");
            lines.Add("            }");
            lines.Add("        }");
            lines.Add("");
        }

        PadTo(lines, Math.Max(lines.Count, functions.Max(f => f.Line) + 40), ref section);
        lines.Add("    }");
        lines.Add("}");
        return string.Join("\n", lines);
    }

    private static void PadTo(List<string> lines, int target, ref int section)
    {
        while (lines.Count < target)
        {
            if (lines.Count % 24 == 0)
            {
                section++;
                lines.Add($"        // ── section {section:00} ─────────────────────────────────────────────────");
            }
            else
            {
                lines.Add("");
            }
        }
    }

    private static string ExtractName(string function)
    {
        string name = function;
        int paren = name.IndexOf('(');
        string parameters = paren > 0 ? name[(paren + 1)..].TrimEnd(')') : string.Empty;
        if (paren > 0) name = name[..paren];
        int dot = name.LastIndexOf('.');
        if (dot >= 0) name = name[(dot + 1)..];
        name = name.Replace("..ctor", string.Empty).Replace('`', '_');
        return string.IsNullOrWhiteSpace(name) ? "Invoke" : name;
    }

    private static string ExtractParameters(string function)
    {
        int paren = function.IndexOf('(');
        if (paren < 0) return string.Empty;
        string raw = function[(paren + 1)..].TrimEnd(')');
        if (string.IsNullOrWhiteSpace(raw)) return string.Empty;
        var parts = raw.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Select(SimplifyType)
            .Where(p => !string.IsNullOrWhiteSpace(p));
        return string.Join(", ", parts);
    }

    private static string SimplifyType(string parameter)
    {
        string text = parameter.Replace("...", "params ");
        int space = text.LastIndexOf(' ');
        if (space > 0)
        {
            string type = text[..space];
            string argument = text[(space + 1)..];
            int lastDot = type.LastIndexOf('.');
            if (lastDot >= 0) type = type[(lastDot + 1)..];
            return $"{type} {argument}";
        }
        return text;
    }

    private static string GuessReturnType(string name)
    {
        if (name is "Main" or "Run" or "RenderFrame" or "Paint" or "Upload" or "UpdateTransforms" or "Resize"
            or "Submit" or "EnsureCapacity" or "Flush" or "Poll" or "SaveSnapshot" or "Serialize" or "LoadMaterial"
            or "LoadTheme" or "RenderBlock" or "Decode" or "BeginFrame" or "OnRender" or "OnPaint" or "Compile")
            return "void";
        if (name.StartsWith("Get", StringComparison.Ordinal) || name.StartsWith("Acquire", StringComparison.Ordinal)) return "object";
        if (name.StartsWith("Is", StringComparison.Ordinal) || name.StartsWith("Has", StringComparison.Ordinal)) return "bool";
        if (name.StartsWith("Rent", StringComparison.Ordinal)) return "RenderTarget";
        return "object";
    }
}
