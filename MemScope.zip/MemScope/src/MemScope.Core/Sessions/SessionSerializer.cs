using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Serialization;
using MemScope.Core.Models;

namespace MemScope.Core.Sessions;

/// <summary>Reads and writes the MemScope capture format (.msc = gzip-compressed JSON).</summary>
public static class SessionSerializer
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        WriteIndented = false
    };

    private static readonly JsonSerializerOptions PrettyOptions = new(JsonOptions) { WriteIndented = true };

    public static void Save(MemSession session, string path, bool compress = true)
    {
        var directory = Path.GetDirectoryName(Path.GetFullPath(path));
        if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);

        using var stream = File.Create(path);
        if (compress)
        {
            using var gzip = new GZipStream(stream, CompressionLevel.Optimal, leaveOpen: true);
            JsonSerializer.Serialize(gzip, ToFile(session), JsonOptions);
        }
        else
        {
            JsonSerializer.Serialize(stream, ToFile(session), PrettyOptions);
        }
    }

    public static async Task SaveAsync(MemSession session, string path, bool compress = true, CancellationToken cancellationToken = default)
    {
        var directory = Path.GetDirectoryName(Path.GetFullPath(path));
        if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);

        await using var stream = File.Create(path);
        if (compress)
        {
            await using var gzip = new GZipStream(stream, CompressionLevel.Optimal, leaveOpen: true);
            await JsonSerializer.SerializeAsync(gzip, ToFile(session), JsonOptions, cancellationToken).ConfigureAwait(false);
        }
        else
        {
            await JsonSerializer.SerializeAsync(stream, ToFile(session), PrettyOptions, cancellationToken).ConfigureAwait(false);
        }
    }

    public static MemSession Load(string path)
    {
        using var stream = File.OpenRead(path);
        Stream payload = IsGzip(stream) ? new GZipStream(stream, CompressionMode.Decompress) : stream;
        try
        {
            var file = JsonSerializer.Deserialize<SessionFile>(payload, JsonOptions)
                       ?? throw new InvalidDataException("The capture file is empty or malformed.");
            if (!string.Equals(file.Format, Branding.SessionFormat, StringComparison.Ordinal))
                throw new InvalidDataException($"Unrecognised capture format '{file.Format}'. Expected '{Branding.SessionFormat}'.");
            if (file.FormatVersion > Branding.SessionFormatVersion)
                throw new InvalidDataException($"Capture format v{file.FormatVersion} is newer than this build supports (v{Branding.SessionFormatVersion}).");
            return FromFile(file);
        }
        finally
        {
            if (!ReferenceEquals(payload, stream)) payload.Dispose();
        }
    }

    public static async Task<MemSession> LoadAsync(string path, CancellationToken cancellationToken = default)
    {
        await using var stream = File.OpenRead(path);
        Stream payload = IsGzip(stream) ? new GZipStream(stream, CompressionMode.Decompress) : stream;
        try
        {
            var file = await JsonSerializer.DeserializeAsync<SessionFile>(payload, JsonOptions, cancellationToken).ConfigureAwait(false)
                       ?? throw new InvalidDataException("The capture file is empty or malformed.");
            if (!string.Equals(file.Format, Branding.SessionFormat, StringComparison.Ordinal))
                throw new InvalidDataException($"Unrecognised capture format '{file.Format}'.");
            return FromFile(file);
        }
        finally
        {
            if (!ReferenceEquals(payload, stream)) payload.Dispose();
        }
    }

    public static bool IsMemScopeCapture(string path)
    {
        try
        {
            using var stream = File.OpenRead(path);
            if (IsGzip(stream))
            {
                using var gzip = new GZipStream(stream, CompressionMode.Decompress);
                Span<byte> probe = stackalloc byte[512];
                int read = gzip.Read(probe);
                return System.Text.Encoding.UTF8.GetString(probe[..read]).Contains(Branding.SessionFormat, StringComparison.Ordinal);
            }
            Span<byte> buffer = stackalloc byte[512];
            int count = stream.Read(buffer);
            return System.Text.Encoding.UTF8.GetString(buffer[..count]).Contains(Branding.SessionFormat, StringComparison.Ordinal);
        }
        catch
        {
            return false;
        }
    }

    private static bool IsGzip(Stream stream)
    {
        int a = stream.ReadByte();
        int b = stream.ReadByte();
        stream.Seek(0, SeekOrigin.Begin);
        return a == 0x1F && b == 0x8B;
    }

    private static SessionFile ToFile(MemSession session) => new()
    {
        Format = Branding.SessionFormat,
        FormatVersion = Branding.SessionFormatVersion,
        App = Branding.VersionLine,
        Metadata = session.Metadata,
        Modules = session.Modules,
        Frames = session.Frames.Select(f => new FrameDto
        {
            Id = f.Id,
            Address = f.Address,
            Module = f.ModuleIndex,
            Function = f.Function,
            File = f.File,
            Line = f.Line
        }).ToList(),
        Stacks = session.Stacks.Select(s => new StackDto
        {
            Id = s.Id,
            Frames = s.Frames,
            Allocations = s.Allocations,
            Frees = s.Frees,
            Reallocations = s.Reallocations,
            Live = s.LiveBytes,
            Peak = s.PeakBytes,
            Total = s.TotalBytes,
            Thread = s.ThreadId,
            Heap = s.Heap,
            LiveBySnapshot = s.LiveBySnapshot
        }).ToList(),
        Events = session.Events.Count == 0 ? null : new EventColumns
        {
            Addresses = session.Events.Select(e => e.Address).ToArray(),
            Sizes = session.Events.Select(e => e.Size).ToArray(),
            Kinds = session.Events.Select(e => (byte)e.Kind).ToArray(),
            Timestamps = session.Events.Select(e => (int)Math.Clamp(e.TimestampMs, 0, int.MaxValue)).ToArray(),
            Stacks = session.Events.Select(e => e.StackId).ToArray(),
            Threads = session.Events.Select(e => e.ThreadId).ToArray()
        },
        Snapshots = session.Snapshots,
        Heaps = session.Heaps,
        SourceFiles = session.SourceFiles.Count == 0 ? null : session.SourceFiles
    };

    private static MemSession FromFile(SessionFile file)
    {
        var session = new MemSession
        {
            Metadata = file.Metadata ?? new SessionMetadata(),
            Modules = file.Modules ?? new List<ModuleInfo>(),
            Snapshots = file.Snapshots ?? new List<MemorySnapshot>(),
            Heaps = file.Heaps ?? new List<HeapInfo>(),
            SourceFiles = file.SourceFiles is null
                ? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
                : new Dictionary<string, string>(file.SourceFiles, StringComparer.OrdinalIgnoreCase)
        };

        session.Frames = (file.Frames ?? new List<FrameDto>()).Select(f => new FrameInfo
        {
            Id = f.Id,
            Address = f.Address,
            ModuleIndex = f.Module,
            Function = string.IsNullOrWhiteSpace(f.Function) ? "Unknown" : f.Function,
            File = f.File ?? string.Empty,
            Line = f.Line
        }).ToList();

        session.Stacks = (file.Stacks ?? new List<StackDto>()).Select(s => new StackRecord
        {
            Id = s.Id,
            Frames = s.Frames ?? Array.Empty<int>(),
            Allocations = s.Allocations,
            Frees = s.Frees,
            Reallocations = s.Reallocations,
            LiveBytes = s.Live,
            PeakBytes = s.Peak,
            TotalBytes = s.Total,
            ThreadId = s.Thread,
            Heap = s.Heap ?? "Process heap",
            LiveBySnapshot = s.LiveBySnapshot
        }).ToList();

        var events = file.Events;
        if (events?.Addresses is { Length: > 0 } addresses && events.Sizes is not null)
        {
            int count = addresses.Length;
            var list = new List<AllocationEvent>(count);
            for (int i = 0; i < count; i++)
            {
                list.Add(new AllocationEvent(
                    addresses[i],
                    i < events.Sizes.Length ? events.Sizes[i] : 0,
                    i < (events.Kinds?.Length ?? 0) ? (AllocationEventKind)events.Kinds![i] : AllocationEventKind.Allocate,
                    i < (events.Timestamps?.Length ?? 0) ? events.Timestamps![i] : 0,
                    i < (events.Stacks?.Length ?? 0) ? events.Stacks![i] : -1,
                    i < (events.Threads?.Length ?? 0) ? events.Threads![i] : 0));
            }
            session.Events = list;
        }

        session.Metadata.ToolVersion = string.IsNullOrWhiteSpace(session.Metadata.ToolVersion) ? Branding.Version : session.Metadata.ToolVersion;
        return session;
    }

    private sealed class SessionFile
    {
        [JsonPropertyName("format")] public string Format { get; set; } = Branding.SessionFormat;
        [JsonPropertyName("formatVersion")] public int FormatVersion { get; set; } = Branding.SessionFormatVersion;
        [JsonPropertyName("app")] public string? App { get; set; }
        [JsonPropertyName("metadata")] public SessionMetadata? Metadata { get; set; }
        [JsonPropertyName("modules")] public List<ModuleInfo>? Modules { get; set; }
        [JsonPropertyName("frames")] public List<FrameDto>? Frames { get; set; }
        [JsonPropertyName("stacks")] public List<StackDto>? Stacks { get; set; }
        [JsonPropertyName("events")] public EventColumns? Events { get; set; }
        [JsonPropertyName("snapshots")] public List<MemorySnapshot>? Snapshots { get; set; }
        [JsonPropertyName("heaps")] public List<HeapInfo>? Heaps { get; set; }
        [JsonPropertyName("sourceFiles")] public Dictionary<string, string>? SourceFiles { get; set; }
    }

    private sealed class FrameDto
    {
        [JsonPropertyName("i")] public int Id { get; set; }
        [JsonPropertyName("a")] public long Address { get; set; }
        [JsonPropertyName("m")] public int Module { get; set; }
        [JsonPropertyName("f")] public string Function { get; set; } = "Unknown";
        [JsonPropertyName("s")] public string? File { get; set; }
        [JsonPropertyName("l")] public int Line { get; set; }
    }

    private sealed class StackDto
    {
        [JsonPropertyName("i")] public int Id { get; set; }
        [JsonPropertyName("f")] public int[] Frames { get; set; } = Array.Empty<int>();
        [JsonPropertyName("al")] public long Allocations { get; set; }
        [JsonPropertyName("fr")] public long Frees { get; set; }
        [JsonPropertyName("re")] public long Reallocations { get; set; }
        [JsonPropertyName("lv")] public long Live { get; set; }
        [JsonPropertyName("pk")] public long Peak { get; set; }
        [JsonPropertyName("tt")] public long Total { get; set; }
        [JsonPropertyName("th")] public int Thread { get; set; }
        [JsonPropertyName("hp")] public string? Heap { get; set; }
        [JsonPropertyName("ls")] public long[]? LiveBySnapshot { get; set; }
    }

    private sealed class EventColumns
    {
        [JsonPropertyName("a")] public long[] Addresses { get; set; } = Array.Empty<long>();
        [JsonPropertyName("s")] public int[] Sizes { get; set; } = Array.Empty<int>();
        [JsonPropertyName("k")] public byte[] Kinds { get; set; } = Array.Empty<byte>();
        [JsonPropertyName("t")] public int[] Timestamps { get; set; } = Array.Empty<int>();
        [JsonPropertyName("st")] public int[] Stacks { get; set; } = Array.Empty<int>();
        [JsonPropertyName("th")] public int[] Threads { get; set; } = Array.Empty<int>();
    }
}
