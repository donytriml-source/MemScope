using System.Globalization;
using System.Net;
using System.Text;
using MemScope.Core.Analysis;
using MemScope.Core.Models;
using MemScope.Core.Util;

namespace MemScope.Core.Sessions;

/// <summary>Exports captures to CSV, JSON and a self-contained branded HTML dossier.</summary>
public static class SessionExporter
{
    public static void ExportFlattenedCallTreeCsv(MemSession session, CallTreeNode root, string path)
    {
        var sb = new StringBuilder();
        sb.AppendLine("depth,function,module,file,line,usage_bytes,peak_bytes,allocations,frees,reallocations,share");
        AppendCsvTree(sb, root, 0);
        File.WriteAllText(path, sb.ToString(), new UTF8Encoding(true));
    }

    private static void AppendCsvTree(StringBuilder sb, CallTreeNode node, int depth)
    {
        foreach (var child in node.Children)
        {
            sb.Append(depth).Append(',')
              .Append(Escape(child.Name)).Append(',')
              .Append(Escape(child.Module)).Append(',')
              .Append(Escape(child.File)).Append(',')
              .Append(child.Line).Append(',')
              .Append(child.Usage).Append(',')
              .Append(child.PeakUsage).Append(',')
              .Append(child.Allocations).Append(',')
              .Append(child.Frees).Append(',')
              .Append(child.Reallocations).Append(',')
              .Append(child.Share.ToString("0.######", CultureInfo.InvariantCulture))
              .AppendLine();
            AppendCsvTree(sb, child, depth + 1);
        }
    }

    public static void ExportHotspotsCsv(MemSession session, string path)
    {
        var rows = HotspotAnalyzer.Analyze(session, HotspotMode.LiveBytes, 5000);
        var sb = new StringBuilder();
        sb.AppendLine("rank,function,module,file,line,live_bytes,allocations,frees,reallocations,churn_ratio,call_path");
        int rank = 0;
        foreach (var row in rows)
        {
            rank++;
            sb.Append(rank).Append(',')
              .Append(Escape(row.Function)).Append(',')
              .Append(Escape(row.Module)).Append(',')
              .Append(Escape(row.File)).Append(',')
              .Append(row.Line).Append(',')
              .Append(row.LiveBytes).Append(',')
              .Append(row.Allocations).Append(',')
              .Append(row.Frees).Append(',')
              .Append(row.Reallocations).Append(',')
              .Append(row.ChurnRatio.ToString("0.####", CultureInfo.InvariantCulture)).Append(',')
              .Append(Escape(row.Path))
              .AppendLine();
        }
        File.WriteAllText(path, sb.ToString(), new UTF8Encoding(true));
    }

    public static void ExportLeaksCsv(MemSession session, string path)
    {
        var rows = LeakAnalyzer.Analyze(session, 1000);
        var sb = new StringBuilder();
        sb.AppendLine("rank,function,module,file,line,live_bytes,allocations,frees,free_ratio,growth_ratio,score,confidence,reasons");
        int rank = 0;
        foreach (var row in rows)
        {
            rank++;
            sb.Append(rank).Append(',')
              .Append(Escape(row.Title)).Append(',')
              .Append(Escape(row.Module)).Append(',')
              .Append(Escape(row.File)).Append(',')
              .Append(row.Line).Append(',')
              .Append(row.LiveBytes).Append(',')
              .Append(row.Allocations).Append(',')
              .Append(row.Frees).Append(',')
              .Append(row.FreeRatio.ToString("0.####", CultureInfo.InvariantCulture)).Append(',')
              .Append(row.GrowthRatio.ToString("0.####", CultureInfo.InvariantCulture)).Append(',')
              .Append(row.Score.ToString("0.##", CultureInfo.InvariantCulture)).Append(',')
              .Append(row.Confidence).Append(',')
              .Append(Escape(string.Join(" · ", row.Reasons)))
              .AppendLine();
        }
        File.WriteAllText(path, sb.ToString(), new UTF8Encoding(true));
    }

    public static void ExportOperationsCsv(MemSession session, string path)
    {
        var sb = new StringBuilder();
        sb.AppendLine("sequence,timestamp_ms,kind,address,size,function,module,thread");
        long seq = 0;
        foreach (var evt in session.Events)
        {
            seq++;
            var stack = session.Stacks.FirstOrDefault(s => s.Id == evt.StackId);
            var leaf = stack is null ? null : session.LeafFrame(stack);
            sb.Append(seq).Append(',')
              .Append(evt.TimestampMs).Append(',')
              .Append(evt.KindLabel).Append(',')
              .Append(Humanize.Address(evt.Address)).Append(',')
              .Append(evt.Size).Append(',')
              .Append(Escape(leaf?.DisplayFunction ?? "Unknown")).Append(',')
              .Append(Escape(session.ModuleNameOf(leaf))).Append(',')
              .Append(evt.ThreadId)
              .AppendLine();
        }
        File.WriteAllText(path, sb.ToString(), new UTF8Encoding(true));
    }

    public static void ExportMetricsJson(MemSession session, string path)
    {
        var stats = session.ComputeStatistics();
        var timeline = TimelineBuilder.Build(session);
        var sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine($"  \"product\": \"{Branding.ProductName}\",");
        sb.AppendLine($"  \"version\": \"{Branding.Version}\",");
        sb.AppendLine($"  \"author\": \"{Branding.Author}\",");
        sb.AppendLine($"  \"copyright\": \"{Branding.Copyright}\",");
        sb.AppendLine($"  \"capture\": \"{Json(session.Metadata.Name)}\",");
        sb.AppendLine($"  \"target\": \"{Json(session.Metadata.TargetProcess)}\",");
        sb.AppendLine("  \"statistics\": {");
        sb.AppendLine($"    \"usageBytes\": {stats.UsageBytes},");
        sb.AppendLine($"    \"peakUsageBytes\": {stats.PeakUsageBytes},");
        sb.AppendLine($"    \"allocations\": {stats.Allocations},");
        sb.AppendLine($"    \"frees\": {stats.Frees},");
        sb.AppendLine($"    \"reallocations\": {stats.Reallocations},");
        sb.AppendLine($"    \"liveBlocks\": {stats.LiveBlocks},");
        sb.AppendLine($"    \"overheadBytes\": {stats.OverheadBytes},");
        sb.AppendLine($"    \"backtraces\": {session.Stacks.Count},");
        sb.AppendLine($"    \"heaps\": {stats.Heaps}");
        sb.AppendLine("  },");
        sb.AppendLine("  \"timeline\": [");
        for (int i = 0; i < timeline.Points.Count; i++)
        {
            var p = timeline.Points[i];
            sb.Append($"    {{ \"t\": {p.TimestampMs}, \"usage\": {p.UsageBytes}, \"peak\": {p.PeakBytes}, \"blocks\": {p.LiveBlocks} }}");
            sb.AppendLine(i == timeline.Points.Count - 1 ? string.Empty : ",");
        }
        sb.AppendLine("  ]");
        sb.AppendLine("}");
        File.WriteAllText(path, sb.ToString(), new UTF8Encoding(true));
    }

    public static void ExportHtmlReport(MemSession session, string path)
    {
        File.WriteAllText(path, BuildHtmlReport(session), new UTF8Encoding(true));
    }

    public static string BuildHtmlReport(MemSession session)
    {
        var stats = session.ComputeStatistics();
        var timeline = TimelineBuilder.Build(session);
        var histogram = HistogramBuilder.Build(session);
        var hotspots = HotspotAnalyzer.Analyze(session, HotspotMode.LiveBytes, 18);
        var leaks = LeakAnalyzer.Analyze(session, 10);
        var insights = InsightAnalyzer.Analyze(session);
        var modules = session.Modules
            .Select(m => new
            {
                Module = m,
                Live = session.Stacks.Where(s => session.GetFrame(s.Frames.FirstOrDefault())?.ModuleIndex == m.BaseAddress.GetHashCode() * 0).Sum(s => s.LiveBytes)
            })
            .ToList();

        var moduleLive = session.Stacks
            .GroupBy(s => session.ModuleNameOf(session.LeafFrame(s)))
            .Select(g => new { Name = g.Key, Bytes = g.Sum(s => s.LiveBytes) })
            .OrderByDescending(x => x.Bytes)
            .Take(8)
            .ToList();

        var sb = new StringBuilder();
        sb.AppendLine("<!doctype html>");
        sb.AppendLine("<html lang=\"en\"><head><meta charset=\"utf-8\">");
        sb.AppendLine($"<meta name=\"generator\" content=\"{Branding.VersionLine}\">");
        sb.AppendLine($"<title>{H(session.Metadata.Name)} · MemScope dossier</title>");
        sb.AppendLine("<style>");
        sb.AppendLine(@"
:root{--bg:#08090c;--panel:#101218;--panel2:#151821;--line:#242835;--text:#eef1f8;--muted:#9aa3b8;--brass:#e2b567;--brass2:#f6d79a;--cyan:#5fd4ff;--emerald:#48d597;--rose:#ff7d8a;--violet:#a693ff}
*{box-sizing:border-box}
body{margin:0;background:radial-gradient(1200px 600px at 12% -10%,#1a1c27 0,transparent 60%),radial-gradient(900px 500px at 100% 0,#1b1710 0,transparent 55%),var(--bg);color:var(--text);font:14px/1.55 'Segoe UI',system-ui,sans-serif}
.wrap{max-width:1180px;margin:0 auto;padding:54px 34px 80px}
.brand{display:flex;align-items:center;gap:18px;margin-bottom:6px}
.logo{width:58px;height:58px;border-radius:16px;background:linear-gradient(145deg,#f6d79a,#c99036 55%,#8e5f16);display:grid;place-items:center;color:#1a1206;font-weight:800;font-size:22px;letter-spacing:-1px;box-shadow:0 14px 40px rgba(226,181,103,.28)}
h1{font-size:34px;margin:22px 0 4px;font-weight:650;letter-spacing:-.02em}
h1 span{background:linear-gradient(100deg,var(--brass2),var(--brass) 55%,#c3b7ff);-webkit-background-clip:text;background-clip:text;color:transparent}
.sub{color:var(--muted);font-size:14px}
.meta{display:flex;flex-wrap:wrap;gap:8px;margin:18px 0 34px}
.chip{border:1px solid var(--line);background:#ffffff08;padding:5px 12px;border-radius:999px;font-size:12px;color:#cdd4e4}
.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:26px}
.card{background:linear-gradient(180deg,#141722,#0f1117);border:1px solid var(--line);border-radius:16px;padding:18px 18px 16px;position:relative;overflow:hidden}
.card:before{content:'';position:absolute;inset:0 0 auto 0;height:1px;background:linear-gradient(90deg,transparent,var(--brass),transparent);opacity:.5}
.card .k{color:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:.14em}
.card .v{font-size:25px;font-weight:600;margin-top:8px;letter-spacing:-.02em}
.card .s{color:#79839a;font-size:11px;margin-top:4px}
.panel{background:linear-gradient(180deg,#111420,#0d1016);border:1px solid var(--line);border-radius:18px;padding:22px 24px;margin-bottom:22px}
.panel h2{font-size:15px;margin:0 0 4px;letter-spacing:.01em}
.panel .hint{color:#77819a;font-size:12px;margin-bottom:16px}
.grid2{display:grid;grid-template-columns:1.55fr 1fr;gap:22px}
table{width:100%;border-collapse:collapse;font-size:12.5px}
th{text-align:left;color:#8d97ae;font-weight:500;font-size:10.5px;letter-spacing:.12em;text-transform:uppercase;padding:8px 10px;border-bottom:1px solid var(--line)}
td{padding:8px 10px;border-bottom:1px solid #1b1f2a;vertical-align:top}
tr:last-child td{border-bottom:none}
td.num{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
.mono{font-family:'Cascadia Mono',Consolas,monospace;font-size:11.5px;color:#c9d2e6}
.mut{color:#7d879e}
.tag{display:inline-block;padding:2px 8px;border-radius:999px;font-size:10.5px;border:1px solid #2b3145;color:#b6c0d6;background:#ffffff06}
.tag.crit{color:#ffb3bb;border-color:#5c2a33;background:#ff7d8a14}
.tag.warn{color:#f4d9a2;border-color:#5b4722;background:#e2b56712}
.tag.ok{color:#a5f0cd;border-color:#205741;background:#48d59712}
.bar{height:6px;border-radius:999px;background:#1c2130;overflow:hidden;margin-top:6px}
.bar i{display:block;height:100%;background:linear-gradient(90deg,var(--brass),#f0d9a6);border-radius:999px}
.insight{display:flex;gap:14px;padding:12px 0;border-bottom:1px solid #1b1f2a}
.insight:last-child{border-bottom:none}
.dot{width:9px;height:9px;border-radius:50%;margin-top:6px;flex:0 0 auto}
.footer{color:#687188;font-size:12px;display:flex;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-top:30px;border-top:1px solid var(--line);padding-top:22px}
.footer strong{color:#b9c2d6;font-weight:500}
@media print{body{background:#fff;color:#111}.panel,.card{break-inside:avoid}}
");
        sb.AppendLine("</style></head><body><div class=\"wrap\">");

        sb.AppendLine("<div class=\"brand\"><div class=\"logo\">M</div><div><div style=\"font-weight:650;letter-spacing:.18em;font-size:12px;color:#9aa3b8\">MEMSCOPE DOSSIER</div><div style=\"font-size:12px;color:#6f7a92\">" + H(Branding.Tagline) + "</div></div></div>");
        sb.AppendLine($"<h1>{H(session.Metadata.Name)}</h1>");
        sb.AppendLine($"<div class=\"sub\">Target <strong style=\"color:#dfe6f5\">{H(session.Metadata.TargetProcess)}</strong> · captured {H(session.Metadata.DisplayDate)} · {H(session.Metadata.DisplayDuration)} · {session.Stacks.Count} backtraces · {session.Frames.Count} frames</div>");
        sb.AppendLine("<div class=\"meta\">");
        sb.AppendLine($"<span class=\"chip\">Session {H(session.Metadata.CaptureId[..Math.Min(10, session.Metadata.CaptureId.Length)])}</span>");
        sb.AppendLine($"<span class=\"chip\">Pointer {session.Metadata.PointerSize * 8}-bit</span>");
        sb.AppendLine($"<span class=\"chip\">{stats.Heaps} heaps · {stats.Threads} threads</span>");
        sb.AppendLine($"<span class=\"chip\">{H(session.Metadata.Origin)}</span>");
        if (session.Metadata.IsSynthetic) sb.AppendLine("<span class=\"chip\">Synthetic dataset</span>");
        sb.AppendLine("</div>");

        sb.AppendLine("<div class=\"cards\">");
        sb.AppendLine(Card("Live heap", Humanize.Bytes(stats.UsageBytes), $"{Humanize.Count(stats.LiveBlocks)} live blocks · avg {Humanize.Bytes(stats.AverageBlockSize)}"));
        sb.AppendLine(Card("Peak heap", Humanize.Bytes(stats.PeakUsageBytes), $"overhead peak {Humanize.Bytes(stats.PeakOverheadBytes)}"));
        sb.AppendLine(Card("Allocations", Humanize.Count(stats.Allocations), $"{Humanize.Count(stats.Frees)} frees · {Humanize.Count(stats.Reallocations)} reallocs"));
        sb.AppendLine(Card("Tracing overhead", Humanize.Bytes(stats.OverheadBytes), Humanize.Percent(stats.OverheadRatio) + " of live heap"));
        sb.AppendLine("</div>");

        sb.AppendLine("<div class=\"panel\"><h2>Memory timeline</h2><div class=\"hint\">Live heap and peak envelope across " + timeline.Points.Count + " snapshots.</div>");
        sb.AppendLine(BuildTimelineSvg(timeline));
        sb.AppendLine("</div>");

        sb.AppendLine("<div class=\"grid2\">");
        sb.AppendLine("<div class=\"panel\"><h2>Leading backtraces</h2><div class=\"hint\">Ranked by retained bytes at the end of the capture.</div>");
        sb.AppendLine("<table><thead><tr><th>#</th><th>Function</th><th>Module</th><th class=\"num\">Live</th><th class=\"num\">Share</th><th class=\"num\">Allocs</th></tr></thead><tbody>");
        int rank = 0;
        foreach (var row in hotspots)
        {
            rank++;
            sb.AppendLine($"<tr><td class=\"mut\">{rank}</td><td><div style=\"font-weight:500\">{H(Truncate(row.Title, 72))}</div><div class=\"mono\">{H(Shorten(row.File, 58))}{(row.Line > 0 ? ":" + row.Line : string.Empty)}</div></td><td class=\"mut\">{H(row.Module)}</td><td class=\"num\">{Humanize.Bytes(row.LiveBytes)}</td><td class=\"num\">{Humanize.Percent((double)row.LiveBytes / Math.Max(1, stats.UsageBytes))}</td><td class=\"num\">{Humanize.Count(row.Allocations)}</td></tr>");
        }
        sb.AppendLine("</tbody></table></div>");

        sb.AppendLine("<div class=\"panel\"><h2>Allocation histogram</h2><div class=\"hint\">Block-size distribution" + (histogram.Estimated ? " (statistically reconstructed)" : " (sampled operations)") + ".</div>");
        sb.AppendLine(BuildHistogramSvg(histogram));
        sb.AppendLine("<div style=\"margin-top:14px\"><table><tbody>");
        foreach (var bucket in histogram.Buckets.Where(b => b.Count > 0).OrderByDescending(b => b.Count).Take(5))
        {
            sb.AppendLine($"<tr><td class=\"mono\">{H(bucket.Label)}</td><td class=\"num\">{Humanize.Count(bucket.Count)}</td><td class=\"num mut\">{Humanize.Percent((double)bucket.Count / Math.Max(1, histogram.TotalCount))}</td></tr>");
        }
        sb.AppendLine("</tbody></table></div></div>");
        sb.AppendLine("</div>");

        sb.AppendLine("<div class=\"grid2\">");
        sb.AppendLine("<div class=\"panel\"><h2>Insights</h2><div class=\"hint\">Automatic observations produced by the MemScope rule engine.</div>");
        foreach (var insight in insights)
        {
            string color = insight.Severity switch
            {
                InsightSeverity.Critical => "var(--rose)",
                InsightSeverity.Warning => "var(--brass)",
                InsightSeverity.Positive => "var(--emerald)",
                _ => "var(--cyan)"
            };
            sb.AppendLine($"<div class=\"insight\"><span class=\"dot\" style=\"background:{color};box-shadow:0 0 10px {color}\"></span><div><div style=\"font-weight:500\">{H(insight.Title)} <span class=\"mono\" style=\"color:#8792aa\">{H(insight.Metric)}</span></div><div style=\"color:#8d97ae;font-size:12.5px\">{H(insight.Summary)}</div></div></div>");
        }
        sb.AppendLine("</div>");

        sb.AppendLine("<div class=\"panel\"><h2>Leak candidates</h2><div class=\"hint\">Retained memory with weak release behaviour.</div><table><tbody>");
        foreach (var leak in leaks)
        {
            string cls = leak.Confidence == LeakConfidence.Critical ? "crit" : leak.Confidence == LeakConfidence.Likely ? "warn" : "";
            sb.AppendLine($"<tr><td><div style=\"font-weight:500\">{H(Truncate(leak.Title, 44))}</div><div class=\"mono\">{H(leak.Module)}</div></td><td class=\"num\">{Humanize.Bytes(leak.LiveBytes)}</td><td class=\"num\"><span class=\"tag {cls}\">{leak.Confidence}</span></td></tr>");
        }
        sb.AppendLine("</tbody></table></div>");
        sb.AppendLine("</div>");

        sb.AppendLine("<div class=\"panel\"><h2>Modules by retained bytes</h2><div class=\"hint\">Leaf-frame attribution across loaded images.</div>");
        foreach (var module in moduleLive)
        {
            double share = (double)module.Bytes / Math.Max(1, stats.UsageBytes);
            sb.AppendLine($"<div style=\"margin:10px 0\"><div style=\"display:flex;justify-content:space-between;font-size:12.5px\"><span>{H(module.Name)}</span><span class=\"mut\">{Humanize.Bytes(module.Bytes)} · {Humanize.Percent(share)}</span></div><div class=\"bar\"><i style=\"width:{Math.Clamp(share * 100, 0.5, 100):0.##}%\"></i></div></div>");
        }
        sb.AppendLine("</div>");

        sb.AppendLine("<div class=\"footer\"><div><strong>" + H(Branding.ProductName) + " " + Branding.Version + "</strong> · " + H(Branding.Copyright) + "</div><div>Generated " + DateTimeOffset.Now.ToString("MMM d, yyyy · HH:mm") + " · Engineered by <strong>" + H(Branding.Author) + "</strong></div></div>");
        sb.AppendLine("</div></body></html>");
        return sb.ToString();
    }

    private static string Card(string key, string value, string subtitle) =>
        $"<div class=\"card\"><div class=\"k\">{H(key)}</div><div class=\"v\">{H(value)}</div><div class=\"s\">{H(subtitle)}</div></div>";

    private static string BuildTimelineSvg(TimelineSeries timeline)
    {
        const double width = 1060, height = 220, pad = 28;
        if (timeline.Points.Count == 0) return "<div class=\"hint\">No snapshots recorded.</div>";
        double max = Math.Max(1, timeline.MaxUsage);
        var sb = new StringBuilder();
        sb.Append($"<svg viewBox=\"0 0 {width} {height}\" width=\"100%\" style=\"display:block\">");
        sb.Append("<defs><linearGradient id=\"tl\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#e2b567\" stop-opacity=\".45\"/><stop offset=\"1\" stop-color=\"#e2b567\" stop-opacity=\"0\"/></linearGradient></defs>");
        for (int i = 0; i <= 4; i++)
        {
            double y = pad + (height - pad * 2) * i / 4.0;
            sb.Append($"<line x1=\"{pad}\" y1=\"{y:0.##}\" x2=\"{width - pad}\" y2=\"{y:0.##}\" stroke=\"#232837\" stroke-width=\"1\"/>");
            sb.Append($"<text x=\"{pad - 6}\" y=\"{y + 4:0.##}\" text-anchor=\"end\" fill=\"#69748b\" font-size=\"10\">{Humanize.BytesCompact((long)(max * (1 - i / 4.0)))}</text>");
        }
        var points = timeline.Points.Select((p, i) =>
        {
            double x = pad + (width - pad * 2) * (timeline.Points.Count == 1 ? 0 : i / (double)(timeline.Points.Count - 1));
            double y = height - pad - (height - pad * 2) * ((double)p.UsageBytes / max);
            double py = height - pad - (height - pad * 2) * Math.Min(1, (double)p.PeakBytes / max);
            return (x, y, py, p);
        }).ToList();

        var line = string.Join(" ", points.Select(p => $"{p.x:0.##},{p.y:0.##}"));
        var area = $"{pad},{height - pad} {line} {points[^1].x:0.##},{height - pad}";
        sb.Append($"<polygon points=\"{area}\" fill=\"url(#tl)\"/>");
        sb.Append($"<polyline points=\"{string.Join(" ", points.Select(p => $"{p.x:0.##},{p.py:0.##}"))}\" fill=\"none\" stroke=\"#5fd4ff\" stroke-width=\"1.2\" stroke-dasharray=\"4 4\" opacity=\".75\"/>");
        sb.Append($"<polyline points=\"{line}\" fill=\"none\" stroke=\"#f6d79a\" stroke-width=\"2\" stroke-linejoin=\"round\"/>");
        foreach (var p in points)
        {
            sb.Append($"<circle cx=\"{p.x:0.##}\" cy=\"{p.y:0.##}\" r=\"2.6\" fill=\"#0d1016\" stroke=\"#e2b567\" stroke-width=\"1.4\"><title>{H(p.p.Name)} · {Humanize.Bytes(p.p.UsageBytes)}</title></circle>");
        }
        sb.Append("</svg>");
        return sb.ToString();
    }

    private static string BuildHistogramSvg(HistogramData histogram)
    {
        const double width = 480, height = 150, pad = 10;
        var buckets = histogram.Buckets;
        long max = Math.Max(1, histogram.MaxCount);
        double barWidth = (width - pad * 2) / Math.Max(1, buckets.Count);
        var sb = new StringBuilder();
        sb.Append($"<svg viewBox=\"0 0 {width} {height}\" width=\"100%\" style=\"display:block\">");
        for (int i = 0; i < buckets.Count; i++)
        {
            var bucket = buckets[i];
            double h = (height - 26) * ((double)bucket.Count / max);
            if (h < 1 && bucket.Count > 0) h = 1;
            double x = pad + i * barWidth;
            sb.Append($"<rect x=\"{x + 1:0.##}\" y=\"{height - 20 - h:0.##}\" width=\"{Math.Max(1, barWidth - 2):0.##}\" height=\"{h:0.##}\" rx=\"2\" fill=\"url(#hg)\"><title>{H(bucket.Label)} · {Humanize.Count(bucket.Count)} allocs</title></rect>");
        }
        sb.Append("<defs><linearGradient id=\"hg\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#f6d79a\"/><stop offset=\"1\" stop-color=\"#8a6424\"/></linearGradient></defs>");
        sb.Append($"<text x=\"{pad}\" y=\"{height - 4}\" fill=\"#69748b\" font-size=\"9\">{H(buckets.First().Label)}</text>");
        sb.Append($"<text x=\"{width - pad}\" y=\"{height - 4}\" text-anchor=\"end\" fill=\"#69748b\" font-size=\"9\">{H(buckets.Last().Label)}</text>");
        sb.Append("</svg>");
        return sb.ToString();
    }

    private static string H(string? value) => WebUtility.HtmlEncode(value ?? string.Empty);
    private static string Truncate(string value, int max) => value.Length <= max ? value : value[..(max - 1)] + "…";
    private static string Shorten(string value, int max) => Humanize.Shorten(value, max);

    private static string Escape(string? value)
    {
        if (string.IsNullOrEmpty(value)) return string.Empty;
        if (!value.Contains(',') && !value.Contains('"') && !value.Contains('\n')) return value;
        return "\"" + value.Replace("\"", "\"\"") + "\"";
    }

    private static string Json(string value) =>
        value.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", string.Empty);
}
