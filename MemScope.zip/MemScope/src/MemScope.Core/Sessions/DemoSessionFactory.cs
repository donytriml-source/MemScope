using System.Text;
using MemScope.Core.Models;

namespace MemScope.Core.Sessions;

internal sealed record DemoFrame(int Module, string Function, string File, int Line);

/// <summary>
/// Builds the deterministic "Aurora Studio" walkthrough capture. The dataset is synthetic
/// (clearly flagged in metadata) but statistically shaped like a real render-pipeline capture
/// so every MemScope surface can be explored without attaching to a process.
/// </summary>
public static class DemoSessionFactory
{
    private const long TargetLiveBytes = 7_996_210;
    private const double DurationMs = 8622;
    private const int ThreadCount = 42;
    private const int SnapshotCount = 12;

    private static readonly long[] UsageCurve =
    {
        420_000, 1_163_334, 1_584_210, 2_024_980, 3_381_400, 3_302_880,
        3_902_540, 4_762_110, 5_214_600, 6_441_820, 7_182_460, TargetLiveBytes
    };

    private static readonly (int Module, string Name, string Path, string Version, long Base, long Size, bool Managed, bool System)[] ModuleSpecs =
    {
        (0, "AuroraStudio.exe", @"C:\Program Files\Aurora Studio\AuroraStudio.exe", "4.2.1.0", 0x7FF6_6C24_0000, 2_412_544, false, false),
        (1, "Aurora.Render.dll", @"C:\Program Files\Aurora Studio\Aurora.Render.dll", "4.2.1.0", 0x7FF6_2A10_0000, 1_846_272, true, false),
        (2, "Aurora.IO.dll", @"C:\Program Files\Aurora Studio\Aurora.IO.dll", "4.2.1.0", 0x7FF6_2B84_0000, 811_008, true, false),
        (3, "System.Private.CoreLib.dll", @"C:\Program Files\dotnet\shared\Microsoft.NETCore.App\8.0.14\System.Private.CoreLib.dll", "8.0.1424.17324", 0x7FF6_1C00_0000, 12_787_712, true, true),
        (4, "coreclr.dll", @"C:\Program Files\dotnet\shared\Microsoft.NETCore.App\8.0.14\coreclr.dll", "8.0.1424.17324", 0x7FF6_1200_0000, 5_308_416, false, true),
        (5, "clrjit.dll", @"C:\Program Files\dotnet\shared\Microsoft.NETCore.App\8.0.14\clrjit.dll", "8.0.1424.17324", 0x7FF6_1A00_0000, 1_372_160, false, true),
        (6, "KERNELBASE.dll", @"C:\Windows\System32\KERNELBASE.dll", "10.0.26100.3915", 0x7FFE_9C00_0000, 4_046_848, false, true),
        (7, "ntdll.dll", @"C:\Windows\System32\ntdll.dll", "10.0.26100.3915", 0x7FFE_A200_0000, 2_174_976, false, true),
        (8, "d3d11.dll", @"C:\Windows\System32\d3d11.dll", "10.0.26100.3915", 0x7FFE_7A00_0000, 3_145_728, false, true),
        (9, "Aurora.UI.dll", @"C:\Program Files\Aurora Studio\Aurora.UI.dll", "4.2.1.0", 0x7FF6_2F00_0000, 1_204_224, true, false),
        (10, "Aurora.Audio.dll", @"C:\Program Files\Aurora Studio\Aurora.Audio.dll", "4.2.1.0", 0x7FF6_3200_0000, 675_840, true, false),
        (11, "d3dcompiler_47.dll", @"C:\Windows\System32\d3dcompiler_47.dll", "10.0.26100.3915", 0x7FFE_6800_0000, 5_558_272, false, true),
        (12, "MemScope.Agent.dll", @"C:\Program Files\Aurora Studio\MemScope.Agent.dll", "1.0.0.0", 0x7FF6_3A00_0000, 98_304, true, false),
        (13, "MSVCP140.dll", @"C:\Windows\System32\MSVCP140.dll", "14.40.33810.0", 0x7FFE_5600_0000, 620_544, false, true)
    };

    public static MemSession Create()
    {
        var random = new Random(0x8AD);
        var session = new MemSession();
        var modules = ModuleSpecs.Select(m => new ModuleInfo
        {
            Name = m.Name,
            Path = m.Path,
            Version = m.Version,
            BaseAddress = m.Base,
            ImageSize = m.Size,
            IsManaged = m.Managed,
            IsSystem = m.System
        }).ToList();

        var frames = new List<FrameInfo>();
        var frameIds = new Dictionary<string, int>(StringComparer.Ordinal);

        int Intern(DemoFrame spec)
        {
            string key = $"{spec.Module}|{spec.Function}|{spec.File}|{spec.Line}";
            if (frameIds.TryGetValue(key, out int existing)) return existing;
            long address = spec.Module >= 0 && spec.Module < modules.Count
                ? modules[spec.Module].BaseAddress + 0x1000 + (Math.Abs(key.GetHashCode()) % (modules[spec.Module].ImageSize - 0x2000))
                : 0;
            var frame = new FrameInfo
            {
                Id = frames.Count,
                Address = address,
                ModuleIndex = spec.Module,
                Function = spec.Function,
                File = spec.File,
                Line = spec.Line
            };
            frames.Add(frame);
            frameIds[key] = frame.Id;
            return frame.Id;
        }

        // ── Frames ────────────────────────────────────────────────────────────
        var startup = new DemoFrame(0, "_startup", "", 0);
        var main = new DemoFrame(0, "AuroraStudio.Program.Main(string[] args)", @"C:\Projects\Aurora\src\AuroraStudio\Program.cs", 24);
        var run = new DemoFrame(0, "AuroraStudio.AppHost.Run()", @"C:\Projects\Aurora\src\AuroraStudio\AppHost.cs", 61);
        var renderLoop = new DemoFrame(0, "AuroraStudio.AppHost.RunRenderLoop()", @"C:\Projects\Aurora\src\AuroraStudio\AppHost.cs", 148);
        var renderFrame = new DemoFrame(1, "Aurora.Render.SceneRenderer.RenderFrame(Aurora.Render.FrameContext ctx)", @"C:\Projects\Aurora\src\Aurora.Render\SceneRenderer.cs", 212);
        var textureAcquire = new DemoFrame(1, "Aurora.Render.TextureCache.Acquire(string key)", @"C:\Projects\Aurora\src\Aurora.Render\TextureCache.cs", 88);
        var loadMaterial = new DemoFrame(1, "Aurora.Render.MaterialLibrary.LoadMaterial(string name)", @"C:\Projects\Aurora\src\Aurora.Render\MaterialLibrary.cs", 133);
        var compileShader = new DemoFrame(1, "Aurora.Render.ShaderCompiler.Compile(Aurora.Render.ShaderSource source)", @"C:\Projects\Aurora\src\Aurora.Render\ShaderCompiler.cs", 74);
        var geometryUpload = new DemoFrame(1, "Aurora.Render.GeometryBuffer.Upload(Aurora.Render.MeshData mesh)", @"C:\Projects\Aurora\src\Aurora.Render\GeometryBuffer.cs", 119);
        var sceneGraph = new DemoFrame(1, "Aurora.Render.SceneGraph.UpdateTransforms()", @"C:\Projects\Aurora\src\Aurora.Render\SceneGraph.cs", 305);
        var shadowResize = new DemoFrame(1, "Aurora.Render.ShadowMapAllocator.Resize(int width, int height)", @"C:\Projects\Aurora\src\Aurora.Render\ShadowMapAllocator.cs", 57);
        var frameUploader = new DemoFrame(1, "Aurora.Render.FrameUploader.Submit()", @"C:\Projects\Aurora\src\Aurora.Render\FrameUploader.cs", 88);
        var pipelineCache = new DemoFrame(1, "Aurora.Render.PipelineStateCache.Get(ulong key)", @"C:\Projects\Aurora\src\Aurora.Render\PipelineStateCache.cs", 63);
        var renderTarget = new DemoFrame(1, "Aurora.Render.RenderTargetPool.Rent(int width, int height)", @"C:\Projects\Aurora\src\Aurora.Render\RenderTargetPool.cs", 101);
        var vertexPool = new DemoFrame(1, "Aurora.Render.VertexPool.EnsureCapacity(int vertices)", @"C:\Projects\Aurora\src\Aurora.Render\VertexPool.cs", 70);
        var docSave = new DemoFrame(2, "Aurora.IO.DocumentStore.SaveSnapshot(Aurora.IO.Document doc)", @"C:\Projects\Aurora\src\Aurora.IO\DocumentStore.cs", 186);
        var serialize = new DemoFrame(2, "Aurora.IO.DocumentSerializer.Serialize(Aurora.IO.Document doc)", @"C:\Projects\Aurora\src\Aurora.IO\DocumentSerializer.cs", 95);
        var layerFlush = new DemoFrame(2, "Aurora.IO.LayerCache.Flush()", @"C:\Projects\Aurora\src\Aurora.IO\LayerCache.cs", 64);
        var assetPoll = new DemoFrame(2, "Aurora.IO.AssetWatcher.Poll()", @"C:\Projects\Aurora\src\Aurora.IO\AssetWatcher.cs", 91);
        var paint = new DemoFrame(9, "Aurora.UI.SurfacePainter.Paint(Aurora.UI.PaintContext ctx)", @"C:\Projects\Aurora\src\Aurora.UI\SurfacePainter.cs", 230);
        var glyph = new DemoFrame(9, "Aurora.UI.GlyphCache.GetGlyph(uint codepoint, float size)", @"C:\Projects\Aurora\src\Aurora.UI\GlyphCache.cs", 141);
        var themeLoad = new DemoFrame(9, "Aurora.UI.ThemeLoader.LoadTheme(string name)", @"C:\Projects\Aurora\src\Aurora.UI\ThemeLoader.cs", 72);
        var mainWindow = new DemoFrame(0, "AuroraStudio.MainWindow.OnRender(object sender, System.EventArgs e)", @"C:\Projects\Aurora\src\AuroraStudio\MainWindow.xaml.cs", 118);
        var viewportPaint = new DemoFrame(0, "AuroraStudio.EditorViewport.OnPaint(AuroraStudio.PaintEventArgs e)", @"C:\Projects\Aurora\src\AuroraStudio\EditorViewport.cs", 96);
        var profiler = new DemoFrame(0, "AuroraStudio.Diagnostics.FrameProfiler.BeginFrame()", @"C:\Projects\Aurora\src\AuroraStudio\Diagnostics\FrameProfiler.cs", 44);
        var telemetry = new DemoFrame(0, "AuroraStudio.Diagnostics.TelemetryBuffer.Flush()", @"C:\Projects\Aurora\src\AuroraStudio\Diagnostics\TelemetryBuffer.cs", 117);
        var audioMix = new DemoFrame(10, "Aurora.Audio.Mixer.RenderBlock()", @"C:\Projects\Aurora\src\Aurora.Audio\Mixer.cs", 205);
        var audioDecode = new DemoFrame(10, "Aurora.Audio.WaveBank.Decode(Aurora.Audio.WaveAsset asset)", @"C:\Projects\Aurora\src\Aurora.Audio\WaveBank.cs", 158);
        var marshalAlloc = new DemoFrame(3, "System.Runtime.InteropServices.Marshal.AllocHGlobal(nint cb)", "", 0);
        var threadStart = new DemoFrame(3, "System.Threading.Thread.Start()", "", 0);
        var timerCtor = new DemoFrame(3, "System.Threading.Timer..ctor(System.Threading.TimerCallback callback)", "", 0);
        var gcAlloc = new DemoFrame(3, "System.GC.AllocateUninitializedArray<T>(int length, bool pinned)", "", 0);
        var dictResize = new DemoFrame(3, "System.Collections.Generic.Dictionary<TKey, TValue>.Resize(int newSize, bool forceNewHashCodes)", "", 0);
        var stringConcat = new DemoFrame(3, "System.String.Concat(string str0, string str1, string str2)", "", 0);
        var jitCompile = new DemoFrame(5, "Compiler::compileMethod(ICorJitInfo*, CORINFO_METHOD_INFO*, unsigned int, unsigned char**)", "", 0);
        var rtlAlloc = new DemoFrame(7, "RtlAllocateHeap", "", 0);
        var heapAlloc = new DemoFrame(6, "HeapAlloc", "", 0);
        var d3dCreate = new DemoFrame(8, "D3D11CreateDeviceAndSwapChain", "", 0);
        var nativeCompile = new DemoFrame(11, "D3DCompile2", "", 0);
        var safeFileOpen = new DemoFrame(3, "Microsoft.Win32.SafeHandles.SafeFileHandle.Open(string path, System.IO.FileMode mode)", "", 0);
        var diagnostics = new DemoFrame(0, "AuroraStudio.Diagnostics.CaptureSession.Tick()", @"C:\Projects\Aurora\src\AuroraStudio\Diagnostics\CaptureSession.cs", 58);
        var unknown = new DemoFrame(-1, "Unknown", "", 0);

        // ── Backtraces (root → leaf) with normalised live-byte weights ────────
        var leaves = new List<(DemoFrame[] Path, double Weight, int BlockSize, double Churn, double Growth, int Start, string Heap)>
        {
            (new[] { startup, main, run, renderLoop, renderFrame, textureAcquire, loadMaterial, compileShader, pipelineCache, dictResize }, 78, 512, 0.12, 1.42, 0, "Render arena"),
            (new[] { startup, main, run, renderLoop, renderFrame, textureAcquire, loadMaterial, dictResize }, 52, 384, 0.18, 1.35, 0, "Render arena"),
            (new[] { startup, main, run, renderLoop, renderFrame, textureAcquire, loadMaterial, compileShader, nativeCompile, unknown }, 26, 2048, 0.08, 1.20, 2, "Render arena"),
            (new[] { startup, main, run, renderLoop, renderFrame, textureAcquire, dictResize }, 31, 256, 0.55, 1.12, 0, "Default process heap"),
            (new[] { startup, main, run, renderLoop, renderFrame, textureAcquire, loadMaterial, stringConcat }, 14, 96, 0.72, 1.05, 1, "GC segments"),
            (new[] { startup, main, run, renderLoop, renderFrame, geometryUpload, vertexPool, marshalAlloc }, 61, 4096, 0.26, 1.55, 0, "Render arena"),
            (new[] { startup, main, run, renderLoop, renderFrame, geometryUpload, vertexPool, d3dCreate }, 28, 8192, 0.14, 1.38, 3, "Render arena"),
            (new[] { startup, main, run, renderLoop, renderFrame, geometryUpload, stringConcat }, 9, 128, 0.80, 1.00, 0, "GC segments"),
            (new[] { startup, main, run, renderLoop, renderFrame, sceneGraph, dictResize }, 34, 320, 0.48, 1.22, 0, "Default process heap"),
            (new[] { startup, main, run, renderLoop, renderFrame, sceneGraph, gcAlloc }, 21, 1024, 0.92, 1.10, 0, "GC segments"),
            (new[] { startup, main, run, renderLoop, renderFrame, sceneGraph, marshalAlloc }, 12, 768, 0.30, 1.18, 4, "Render arena"),
            (new[] { startup, main, run, renderLoop, renderFrame, frameUploader, marshalAlloc }, 26, 4096, 0.22, 1.47, 1, "Render arena"),
            (new[] { startup, main, run, renderLoop, renderFrame, frameUploader, d3dCreate }, 14, 16384, 0.10, 1.30, 4, "Render arena"),
            (new[] { startup, main, run, renderLoop, renderFrame, renderTarget, d3dCreate }, 24, 32768, 0.18, 1.42, 2, "Render arena"),
            (new[] { startup, main, run, renderLoop, renderFrame, renderTarget, marshalAlloc }, 13, 2048, 0.35, 1.24, 2, "Default process heap"),
            (new[] { startup, main, run, renderLoop, renderFrame, shadowResize, marshalAlloc }, 18, 8192, 0.25, 1.60, 3, "Render arena"),
            (new[] { startup, main, run, renderLoop, renderFrame, shadowResize, gcAlloc }, 7, 512, 0.86, 1.15, 0, "GC segments"),
            (new[] { startup, main, run, renderLoop, renderFrame, renderTarget, unknown }, 11, 1536, 0.40, 1.10, 5, "Render arena"),
            (new[] { startup, main, run, renderLoop, paint, glyph, dictResize }, 58, 192, 0.42, 1.28, 0, "UI arena"),
            (new[] { startup, main, run, renderLoop, paint, glyph, stringConcat }, 21, 80, 0.88, 1.04, 0, "GC segments"),
            (new[] { startup, main, run, renderLoop, paint, glyph, gcAlloc }, 13, 256, 0.95, 0.98, 0, "GC segments"),
            (new[] { startup, main, run, renderLoop, paint, themeLoad, safeFileOpen }, 23, 4096, 0.36, 1.15, 1, "IO staging"),
            (new[] { startup, main, run, renderLoop, paint, themeLoad, gcAlloc }, 6, 1024, 0.90, 1.02, 0, "GC segments"),
            (new[] { startup, main, run, renderLoop, paint, mainWindow, viewportPaint, gcAlloc }, 15, 2048, 0.88, 1.06, 0, "GC segments"),
            (new[] { startup, main, run, renderLoop, docSave, serialize, stringConcat }, 48, 160, 0.78, 1.32, 0, "GC segments"),
            (new[] { startup, main, run, renderLoop, docSave, serialize, layerFlush, dictResize }, 27, 512, 0.44, 1.26, 1, "IO staging"),
            (new[] { startup, main, run, renderLoop, docSave, serialize, layerFlush, gcAlloc }, 12, 1024, 0.91, 1.18, 0, "GC segments"),
            (new[] { startup, main, run, renderLoop, docSave, safeFileOpen }, 12, 8192, 0.28, 1.20, 2, "IO staging"),
            (new[] { startup, main, run, renderLoop, audioMix, audioDecode, marshalAlloc }, 21, 4096, 0.34, 1.11, 0, "Audio arena"),
            (new[] { startup, main, run, renderLoop, audioMix, audioDecode, gcAlloc }, 5, 512, 0.93, 1.03, 0, "GC segments"),
            (new[] { startup, main, run, renderLoop, audioMix, gcAlloc }, 9, 768, 0.90, 1.08, 0, "GC segments"),
            (new[] { startup, main, run, renderLoop, assetPoll, safeFileOpen }, 11, 2048, 0.62, 1.14, 0, "IO staging"),
            (new[] { startup, main, run, diagnostics, profiler, stringConcat }, 14, 96, 0.84, 1.21, 0, "GC segments"),
            (new[] { startup, main, run, diagnostics, profiler, gcAlloc }, 7, 384, 0.92, 1.14, 0, "GC segments"),
            (new[] { startup, main, run, diagnostics, telemetry, stringConcat }, 17, 128, 0.76, 1.38, 0, "GC segments"),
            (new[] { startup, main, run, diagnostics, telemetry, dictResize }, 8, 256, 0.52, 1.30, 1, "Default process heap"),
            (new[] { startup, main, run, timerCtor, gcAlloc }, 9, 512, 0.87, 1.17, 0, "GC segments"),
            (new[] { startup, main, run, threadStart, gcAlloc }, 5, 1024, 0.90, 1.12, 0, "GC segments"),
            (new[] { startup, main, run, renderLoop, renderFrame, renderFrame, unknown }, 8, 1024, 0.32, 1.08, 6, "Render arena"),
            (new[] { startup, main, run, jitCompile, unknown }, 6, 4096, 0.60, 1.00, 5, "Default process heap"),
            (new[] { unknown, unknown, unknown }, 49, 512, 0.42, 0.90, 0, "Default process heap"),
            (new[] { unknown, unknown }, 12, 96, 0.66, 0.95, 0, "Default process heap"),
            (new[] { threadStart, gcAlloc }, 12, 256, 0.88, 1.08, 6, "GC segments"),
            (new[] { rtlAlloc, heapAlloc, marshalAlloc }, 11, 1024, 0.20, 1.30, 0, "Default process heap"),
            (new[] { d3dCreate, unknown }, 8, 16384, 0.25, 1.10, 1, "Render arena"),
            (new[] { main, run, renderLoop, paint, themeLoad, safeFileOpen }, 6, 4096, 0.40, 1.06, 3, "IO staging"),
            (new[] { main, run, renderLoop, paint, glyph, gcAlloc }, 5, 384, 0.94, 1.00, 0, "GC segments")
        };

        double totalWeight = leaves.Sum(l => l.Weight);
        var rng = new Random(0x5AFE);
        var stacks = new List<StackRecord>();

        // Build per-stack trajectories first, then normalise each snapshot column to the usage curve.
        var raw = new double[leaves.Count, SnapshotCount];
        for (int s = 0; s < leaves.Count; s++)
        {
            var leaf = leaves[s];
            double live = TargetLiveBytes * (leaf.Weight / totalWeight);
            for (int i = 0; i < SnapshotCount; i++)
            {
                if (i < leaf.Start)
                {
                    raw[s, i] = 0;
                    continue;
                }
                double t = (i - leaf.Start) / (double)Math.Max(1, SnapshotCount - 1 - leaf.Start);
                double curve = 0.35 + 0.65 * Math.Pow(t, 1.15);
                double factor = 1 + (leaf.Growth - 1) * curve;
                raw[s, i] = live * factor * (0.96 + rng.NextDouble() * 0.08);
            }
        }

        // Normalise every snapshot column so totals equal the authored usage curve.
        var scale = new double[SnapshotCount];
        for (int i = 0; i < SnapshotCount; i++)
        {
            double sum = 0;
            for (int s = 0; s < leaves.Count; s++) sum += raw[s, i];
            scale[i] = sum <= 0 ? 0 : UsageCurve[i] / sum;
        }

        for (int s = 0; s < leaves.Count; s++)
        {
            var leaf = leaves[s];
            var liveSeries = new long[SnapshotCount];
            for (int i = 0; i < SnapshotCount; i++) liveSeries[i] = (long)Math.Round(raw[s, i] * scale[i]);
            liveSeries[^1] = Math.Max(0, liveSeries[^1]);

            long liveBytes = liveSeries[^1];
            if (liveBytes == 0)
            {
                liveBytes = (long)Math.Round(TargetLiveBytes * leaf.Weight / totalWeight);
                liveSeries[^1] = liveBytes;
            }
            long liveBlocks = Math.Max(1, liveBytes / Math.Max(1, leaf.BlockSize));
            long frees = (long)Math.Round(liveBlocks * leaf.Churn * (1.2 + rng.NextDouble() * 0.9));
            long allocations = liveBlocks + frees;
            long totalBytes = allocations * leaf.BlockSize + liveBlocks * (leaf.BlockSize / 3);
            long peakBytes = (long)(liveBytes * (1.02 + rng.NextDouble() * 0.28));

            var framesForStack = ((IEnumerable<DemoFrame>)leaf.Path).Reverse().Select(Intern).ToArray();
            stacks.Add(new StackRecord
            {
                Id = stacks.Count,
                Frames = framesForStack,
                Allocations = allocations,
                Frees = frees,
                Reallocations = Math.Max(1, (long)(allocations * (0.012 + rng.NextDouble() * 0.014))),
                LiveBytes = liveBytes,
                PeakBytes = peakBytes,
                TotalBytes = totalBytes,
                ThreadId = 4 + (s % 9),
                Heap = leaf.Heap,
                LiveBySnapshot = liveSeries,
                FirstSequence = s * 137L,
                LastSequence = 250_000 + s * 173L
            });
        }

        // ── Snapshot timeline ────────────────────────────────────────────────
        long totalAllocations = stacks.Sum(s => s.Allocations);
        long totalFrees = stacks.Sum(s => s.Frees);
        long totalReallocations = stacks.Sum(s => s.Reallocations);
        long actualLive = stacks.Sum(s => s.LiveBytes);
        long blocksAtEnd = stacks.Sum(s => Math.Max(1, s.LiveBytes / Math.Max(1, s.TotalBytes / Math.Max(1, s.Allocations))));
        var snapshots = new List<MemorySnapshot>(SnapshotCount);
        long runningPeak = 0;

        for (int i = 0; i < SnapshotCount; i++)
        {
            double t = i / (double)(SnapshotCount - 1);
            double progress = Math.Pow(t, 0.92);
            long usage = i == SnapshotCount - 1 ? actualLive : UsageCurve[i];
            long liveBlocks = Math.Max(1, (long)Math.Round(blocksAtEnd * (usage / (double)TargetLiveBytes)));
            liveBlocks = Math.Min(liveBlocks, totalAllocations);
            long frees = Math.Min(totalFrees, (long)Math.Round(totalFrees * Math.Pow(t, 1.08)));
            long allocs = Math.Max(liveBlocks, liveBlocks + frees);
            long reallocs = Math.Min(totalReallocations, (long)Math.Round(totalReallocations * progress));
            long overhead = (long)(usage * (0.0138 + 0.0016 * Math.Sin(i * 1.2)));
            runningPeak = Math.Max(runningPeak, (long)(usage * (1.46 - 0.36 * t)));
            snapshots.Add(new MemorySnapshot
            {
                Name = $"S{i + 1:00}",
                TimestampMs = (long)Math.Round(DurationMs * (i / (double)(SnapshotCount - 1))),
                UsageBytes = usage,
                PeakBytes = Math.Max(usage, runningPeak),
                OverheadBytes = overhead,
                PeakOverheadBytes = (long)(overhead * 1.12),
                Allocations = allocs,
                Reallocations = reallocs,
                Frees = frees,
                Operations = allocs + reallocs + frees,
                LiveBlocks = liveBlocks,
                HeapCount = 6,
                ThreadCount = ThreadCount,
                Note = i == 0 ? "Trace armed" : i == SnapshotCount - 1 ? "Capture finalised" : null
            });
        }

        // ── Heaps ────────────────────────────────────────────────────────────
        var heaps = stacks
            .GroupBy(s => s.Heap)
            .Select((g, i) => new HeapInfo
            {
                Id = 0x0130000 + i * 0x10000,
                Name = g.Key,
                BlockCount = g.Sum(s => s.LiveBytes / 140),
                CommittedBytes = g.Sum(s => s.LiveBytes),
                IsDefault = g.Key.Contains("Default", StringComparison.OrdinalIgnoreCase),
                IsShared = g.Key.Contains("segments", StringComparison.OrdinalIgnoreCase)
            })
            .OrderByDescending(h => h.CommittedBytes)
            .ToList();

        // ── Recent operations (sampled) ──────────────────────────────────────
        var events = new List<AllocationEvent>();
        var operationRng = new Random(0x4F2A);
        long addressSeed = 0x0000_0200_0000_0000;
        int targetEventCount = 18_000;
        foreach (var stack in stacks.OrderByDescending(s => s.Allocations))
        {
            double share = (double)stack.Allocations / Math.Max(1, totalAllocations);
            int count = Math.Max(4, (int)Math.Round(targetEventCount * share));
            int avgSize = Math.Max(8, (int)(stack.TotalBytes / Math.Max(1, stack.Allocations)));
            for (int i = 0; i < count && events.Count < 40_000; i++)
            {
                bool free = operationRng.NextDouble() < stack.FreeRatio * 0.35;
                int size = free
                    ? avgSize
                    : Math.Max(8, (int)(avgSize * (0.35 + operationRng.NextDouble() * 1.8)));
                size = (size + 15) & ~15;
                long timestamp = (long)(operationRng.NextDouble() * DurationMs);
                addressSeed += 0x10 + (operationRng.Next(64) * 0x10);
                events.Add(new AllocationEvent(
                    addressSeed,
                    size,
                    free ? AllocationEventKind.Free : operationRng.NextDouble() < 0.02 ? AllocationEventKind.Reallocate : AllocationEventKind.Allocate,
                    timestamp,
                    stack.Id,
                    4 + (stack.Id % 9)));
            }
        }

        events.Sort((a, b) => a.TimestampMs.CompareTo(b.TimestampMs));

        session.Frames = frames;
        session.Modules = modules;
        session.Stacks = stacks;
        session.Snapshots = snapshots;
        session.Heaps = heaps;
        session.Events = events;
        session.Metadata = new SessionMetadata
        {
            Name = "Aurora Studio · frame capture",
            TargetProcess = "AuroraStudio.exe",
            TargetPath = @"C:\Program Files\Aurora Studio\AuroraStudio.exe",
            CapturedAt = DateTimeOffset.Now.AddMinutes(-4),
            DurationMs = DurationMs,
            SamplingIntervalMs = 250,
            PointerSize = 8,
            ThreadCount = ThreadCount,
            HeapCount = heaps.Count,
            Origin = "Demo capture",
            IsSynthetic = true,
            Notes = "Deterministic walkthrough capture generated by MemScope. Symbol names, modules and source lines are synthetic and exist purely to exercise the analysis surface.",
            Tags = { "render-loop", "retained-textures", "demo" }
        };

        session.SourceFiles = DemoSourceLibrary.Build(frames);
        return session;
    }

    /// <summary>
    /// Builds an "earlier capture" of the same walkthrough so the Compare workspace has a
    /// believable baseline: lower retention, fewer allocations and three backtraces that do
    /// not exist yet. Everything else (frames, modules, heaps, source) is shared.
    /// </summary>
    public static MemSession CreateBaseline()
    {
        var session = Create();
        var random = new Random(0x5EED);

        // The three smallest backtraces had not appeared when the baseline was captured.
        var dropped = new HashSet<int>(session.Stacks
            .OrderByDescending(s => s.LiveBytes)
            .TakeLast(3)
            .Select(s => s.Id));
        session.Stacks = session.Stacks.Where(s => !dropped.Contains(s.Id)).ToList();

        int index = 0;
        foreach (var stack in session.Stacks)
        {
            // A handful of paths retained slightly more back then, so the demo diff has
            // both growth and shrinkage instead of a uniform wall of positive deltas.
            double retention = index++ % 7 == 3
                ? 1.04 + random.NextDouble() * 0.26              // 104 % – 130 %
                : 0.62 + random.NextDouble() * 0.28;             // 62 % – 90 %
            stack.LiveBytes = (long)(stack.LiveBytes * retention);
            stack.PeakBytes = (long)(stack.PeakBytes * retention);
            stack.TotalBytes = (long)(stack.TotalBytes * (0.55 + random.NextDouble() * 0.2));
            stack.Allocations = (long)(stack.Allocations * (retention > 1 ? 0.94 : 0.72));
            stack.Frees = (long)(stack.Frees * (retention > 1 ? 1.02 : 0.74));
            stack.Reallocations = (long)(stack.Reallocations * 0.70);

            if (stack.LiveBySnapshot is { } series && series.Length > 1)
            {
                long end = stack.LiveBytes;
                for (int i = 0; i < series.Length; i++)
                    series[i] = (long)(end * Math.Pow(i / (double)(series.Length - 1), 0.92));
            }
        }

        long live = session.Stacks.Sum(s => s.LiveBytes);
        int snapshots = session.Snapshots.Count;
        long runningPeak = 0;
        for (int i = 0; i < snapshots; i++)
        {
            var snapshot = session.Snapshots[i];
            double t = snapshots == 1 ? 1 : i / (double)(snapshots - 1);
            long usage = i == snapshots - 1 ? live : (long)(live * (0.12 + 0.88 * Math.Pow(t, 0.92)));
            snapshot.TimestampMs = (long)(snapshot.TimestampMs * 0.72);
            snapshot.UsageBytes = usage;
            snapshot.OverheadBytes = (long)(usage * 0.014);
            snapshot.PeakOverheadBytes = (long)(snapshot.OverheadBytes * 1.1);
            snapshot.LiveBlocks = Math.Max(1, (long)(snapshot.LiveBlocks * 0.70));
            snapshot.Allocations = (long)(snapshot.Allocations * 0.72);
            snapshot.Frees = (long)(snapshot.Frees * 0.74);
            snapshot.Reallocations = (long)(snapshot.Reallocations * 0.70);
            snapshot.Operations = snapshot.Allocations + snapshot.Frees + snapshot.Reallocations;
            runningPeak = Math.Max(runningPeak, (long)(usage * 1.20));
            snapshot.PeakBytes = runningPeak;
        }

        session.Heaps = session.Stacks
            .GroupBy(s => s.Heap)
            .Select((group, i) => new HeapInfo
            {
                Id = 0x0130000 + i * 0x10000,
                Name = group.Key,
                BlockCount = group.Sum(s => s.LiveBytes / 140),
                CommittedBytes = group.Sum(s => s.LiveBytes),
                IsDefault = group.Key.Contains("Default", StringComparison.OrdinalIgnoreCase),
                IsShared = group.Key.Contains("segments", StringComparison.OrdinalIgnoreCase)
            })
            .OrderByDescending(h => h.CommittedBytes)
            .ToList();

        const double timeScale = 0.72;
        session.Events = session.Events
            .Where(e => !dropped.Contains(e.StackId))
            .Select(e => e with { TimestampMs = (long)(e.TimestampMs * timeScale) })
            .ToList();

        var metadata = session.Metadata;
        metadata.CaptureId = Guid.NewGuid().ToString("N");
        metadata.Name = "Aurora Studio · earlier capture";
        metadata.CapturedAt = metadata.CapturedAt.AddMinutes(-3);
        metadata.DurationMs = DurationMs * timeScale;
        metadata.Notes = "Earlier Aurora Studio capture kept with the walkthrough so the comparison workspace has a " +
                         "meaningful baseline. Live bytes are lower and three backtraces have not appeared yet.";
        metadata.Tags = new List<string> { "render-loop", "baseline", "demo" };
        return session;
    }
}
