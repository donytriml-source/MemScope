using MemScope.Core.Models;
using MemScope.Core.Util;

namespace MemScope.Core.Analysis;

public enum InsightSeverity { Positive, Info, Warning, Critical }

public sealed record Insight(string Title, string Summary, string Metric, InsightSeverity Severity, string Category);

/// <summary>Produces the human-readable observations shown on the overview surface.</summary>
public static class InsightAnalyzer
{
    public static IReadOnlyList<Insight> Analyze(MemSession session)
    {
        var list = new List<Insight>();
        var stats = session.ComputeStatistics();
        var leaks = LeakAnalyzer.Analyze(session, 10);
        var hotspots = HotspotAnalyzer.Analyze(session, HotspotMode.Churn, 10);

        if (session.Snapshots.Count > 1)
        {
            long first = session.Snapshots[0].UsageBytes;
            long last = session.Snapshots[^1].UsageBytes;
            double growth = first > 0 ? (double)(last - first) / first : 0;
            var firstTime = session.Snapshots[0].TimestampMs;
            var lastTime = session.Snapshots[^1].TimestampMs;
            double seconds = Math.Max(0.001, (lastTime - firstTime) / 1000.0);
            double rate = (last - first) / seconds;
            list.Add(new Insight(
                growth > 0.2 ? "Heap is expanding quickly" : growth > 0.02 ? "Heap is expanding" : "Heap is stable",
                growth > 0.02
                    ? $"Live heap grew {Humanize.Percent(growth)} across the capture, roughly {Humanize.Bytes((long)rate)} per second."
                    : "Live heap stayed within a tight band for the whole capture.",
                Humanize.SignedBytes(last - first),
                growth > 0.4 ? InsightSeverity.Critical : growth > 0.15 ? InsightSeverity.Warning : InsightSeverity.Positive,
                "Growth"));
        }

        var topLeak = leaks.FirstOrDefault();
        if (topLeak is not null)
        {
            list.Add(new Insight(
                "Probable leak hotspot",
                $"{topLeak.Title} retains {Humanize.Bytes(topLeak.LiveBytes)} and frees only {Humanize.Percent(topLeak.FreeRatio)} of its allocations.",
                Humanize.Bytes(topLeak.LiveBytes),
                topLeak.Confidence == LeakConfidence.Critical ? InsightSeverity.Critical : InsightSeverity.Warning,
                "Leaks"));
        }

        var churn = hotspots.FirstOrDefault();
        if (churn is not null)
        {
            list.Add(new Insight(
                "Allocation churn",
                $"{churn.Title} performed {Humanize.Count(churn.Allocations)} allocations with {Humanize.Percent(churn.ChurnRatio)} recycle ratio.",
                Humanize.Count(churn.Allocations),
                churn.ChurnRatio > 0.6 ? InsightSeverity.Positive : InsightSeverity.Info,
                "Churn"));
        }

        long overhead = stats.OverheadBytes;
        if (overhead > 0)
        {
            double ratio = stats.OverheadRatio;
            list.Add(new Insight(
                ratio > 0.15 ? "Tracing overhead is elevated" : "Tracing overhead is healthy",
                $"Capture overhead reached {Humanize.Bytes(overhead)} ({Humanize.Percent(ratio)} of live heap).",
                Humanize.Bytes(overhead),
                ratio > 0.15 ? InsightSeverity.Warning : InsightSeverity.Positive,
                "Overhead"));
        }

        var biggest = session.Stacks.OrderByDescending(s => s.LiveBytes).FirstOrDefault();
        if (biggest is not null && stats.UsageBytes > 0)
        {
            double share = (double)biggest.LiveBytes / Math.Max(1, stats.UsageBytes);
            list.Add(new Insight(
                "Largest single backtrace",
                $"{session.TitleOf(biggest, 3)} accounts for {Humanize.Percent(share)} of the live heap.",
                Humanize.Bytes(biggest.LiveBytes),
                share > 0.3 ? InsightSeverity.Warning : InsightSeverity.Info,
                "Composition"));
        }

        if (stats.Heaps > 1)
        {
            list.Add(new Insight(
                "Multiple allocators in play",
                $"{stats.Heaps} heaps were observed. Fragmentation risk rises when many heaps compete for large blocks.",
                stats.Heaps.ToString(),
                InsightSeverity.Info,
                "Fragmentation"));
        }

        return list;
    }
}
