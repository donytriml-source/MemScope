using MemScope.Core.Models;

namespace MemScope.Core.Analysis;

/// <summary>A node inside the aggregated backtrace tree.</summary>
public sealed class CallTreeNode
{
    public string Name { get; set; } = "All allocations";
    public string Module { get; set; } = string.Empty;
    public string File { get; set; } = string.Empty;
    public int Line { get; set; }
    public long Address { get; set; }
    public int FrameId { get; set; } = -1;
    public int Depth { get; set; }
    public bool IsGroup { get; set; }
    public bool IsUnknown { get; set; }
    public CallTreeNode? Parent { get; set; }
    public List<CallTreeNode> Children { get; } = new();

    public long Usage { get; set; }
    public long PeakUsage { get; set; }
    public long Allocations { get; set; }
    public long Frees { get; set; }
    public long Reallocations { get; set; }
    public long TotalBytes { get; set; }
    public int StackCount { get; set; }
    public double Share { get; set; }

    /// <summary>Identifiers of the backtraces that flow through this node (bounded).</summary>
    public List<int> StackIds { get; } = new();

    public bool HasChildren => Children.Count > 0;
    public long SelfBytes => Math.Max(0, Usage - Children.Sum(c => c.Usage));
    public string DisplayName => Name;
    public string Location => string.IsNullOrEmpty(File) ? "—" : $"{System.IO.Path.GetFileName(File)}:{Line}";
    public string UsageShareLabel => Share <= 0 ? "—" : $"{Share * 100:0.##}%";

    internal void AddStackId(int id)
    {
        if (StackIds.Count < 2500 && !StackIds.Contains(id)) StackIds.Add(id);
    }

    public IEnumerable<CallTreeNode> Ancestors()
    {
        var node = Parent;
        while (node is not null)
        {
            yield return node;
            node = node.Parent;
        }
    }

    public override string ToString() => $"{DisplayName} · {Module} · {Usage}";
}

public sealed class CallTreeOptions
{
    public bool GroupByModule { get; set; }
    public long MinBytes { get; set; }
    public string? Search { get; set; }
    public string? ModuleFilter { get; set; }
    public bool HideUnknown { get; set; }
    public int MaxDepth { get; set; } = 96;
    public bool PruneEmptyStacks { get; set; } = true;
}

/// <summary>Builds an inclusive call tree from interned aggregation records.</summary>
public static class CallTreeBuilder
{
    public static CallTreeNode Build(MemSession session, CallTreeOptions? options = null)
    {
        options ??= new CallTreeOptions();
        var root = new CallTreeNode
        {
            Name = "All allocations",
            IsGroup = true,
            Module = session.Metadata.TargetProcess,
            Share = 1
        };

        var map = new Dictionary<long, CallTreeNode>();

        foreach (var stack in session.Stacks)
        {
            if (options.PruneEmptyStacks && stack.Allocations == 0 && stack.LiveBytes == 0) continue;

            long usage = stack.LiveBytes;
            if (usage < options.MinBytes && options.MinBytes > 0) continue;

            var node = root;
            // Frames are stored leaf → root, the tree grows root → leaf.
            for (int i = stack.Frames.Length - 1; i >= 0; i--)
            {
                if (node.Depth >= options.MaxDepth) break;
                var frame = session.GetFrame(stack.Frames[i]);
                if (frame is null) continue;
                if (options.HideUnknown && frame.IsUnknown) continue;

                var module = session.ModuleOf(frame);
                string name = frame.DisplayFunction;
                int frameId = frame.Id;
                string moduleName = module?.Name ?? "Unknown";

                if (options.GroupByModule)
                {
                    var child = GetOrAdd(node, -1000 - frame.ModuleIndex, moduleName, module, null, session);
                    child.IsGroup = true;
                    Accumulate(child, stack, usage);
                    child.AddStackId(stack.Id);
                    node = child;
                }

                var leaf = GetOrAdd(node, frameId, name, module, frame, session);
                Accumulate(leaf, stack, usage);
                leaf.AddStackId(stack.Id);
                node = leaf;
            }

            Accumulate(root, stack, usage);
            root.AddStackId(stack.Id);
        }

        root.Usage = session.Stacks.Sum(s => s.LiveBytes);
        root.Allocations = session.Stacks.Sum(s => s.Allocations);
        root.Frees = session.Stacks.Sum(s => s.Frees);
        root.Reallocations = session.Stacks.Sum(s => s.Reallocations);
        root.PeakUsage = session.Stacks.Sum(s => s.PeakBytes);
        root.TotalBytes = session.Stacks.Sum(s => s.TotalBytes);

        SortRecursive(root);
        AssignShares(root, Math.Max(1, root.Usage));
        ApplyFilters(root, options);
        return root;
    }

    private static CallTreeNode GetOrAdd(CallTreeNode parent, int key, string name, ModuleInfo? module, FrameInfo? frame, MemSession? session)
    {
        foreach (var child in parent.Children)
        {
            if (child.FrameId == key) return child;
        }

        var node = new CallTreeNode
        {
            Name = name,
            Module = module?.Name ?? "Unknown",
            File = frame?.File ?? string.Empty,
            Line = frame?.Line ?? 0,
            Address = frame?.Address ?? 0,
            FrameId = key,
            Depth = parent.Depth + 1,
            Parent = parent,
            IsUnknown = string.Equals(name, "Unknown", StringComparison.OrdinalIgnoreCase)
        };
        parent.Children.Add(node);
        return node;
    }

    private static void Accumulate(CallTreeNode node, StackRecord stack, long usage)
    {
        node.Usage += usage;
        node.PeakUsage += stack.PeakBytes;
        node.Allocations += stack.Allocations;
        node.Frees += stack.Frees;
        node.Reallocations += stack.Reallocations;
        node.TotalBytes += stack.TotalBytes;
        node.StackCount++;
    }

    public static void SortRecursive(CallTreeNode node, int depth = 0)
    {
        node.Children.Sort((a, b) =>
        {
            int cmp = b.Usage.CompareTo(a.Usage);
            if (cmp != 0) return cmp;
            cmp = b.Allocations.CompareTo(a.Allocations);
            return cmp != 0 ? cmp : string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase);
        });
        foreach (var child in node.Children) SortRecursive(child, depth + 1);
    }

    public static void AssignShares(CallTreeNode node, long total)
    {
        node.Share = total <= 0 ? 0 : (double)node.Usage / total;
        foreach (var child in node.Children) AssignShares(child, total);
    }

    public static CallTreeNode? FindByFrameId(CallTreeNode node, int frameId)
    {
        if (node.FrameId == frameId) return node;
        foreach (var child in node.Children)
        {
            var found = FindByFrameId(child, frameId);
            if (found is not null) return found;
        }
        return null;
    }

    private static void ApplyFilters(CallTreeNode root, CallTreeOptions options)
    {
        string? search = string.IsNullOrWhiteSpace(options.Search) ? null : options.Search.Trim();
        string? module = string.IsNullOrWhiteSpace(options.ModuleFilter) ? null : options.ModuleFilter.Trim();
        FilterNode(root, search, module, options.MinBytes, isRoot: true);
        SortRecursive(root);
    }

    private static bool FilterNode(CallTreeNode node, string? search, string? module, long minBytes, bool isRoot)
    {
        for (int i = node.Children.Count - 1; i >= 0; i--)
        {
            if (!FilterNode(node.Children[i], search, module, minBytes, false))
                node.Children.RemoveAt(i);
        }

        bool matchesText = search is null || Contains(node.Name, search) || Contains(node.Module, search) || Contains(node.File, search);
        bool matchesModule = module is null || string.Equals(node.Module, module, StringComparison.OrdinalIgnoreCase);
        bool matchesSize = node.Usage >= minBytes;
        bool matches = matchesText && matchesModule && matchesSize;

        if (isRoot) return true;
        if (node.Children.Count > 0) return true;
        return matches;
    }

    private static bool Contains(string? value, string needle) =>
        !string.IsNullOrEmpty(value) && value.Contains(needle, StringComparison.OrdinalIgnoreCase);

    /// <summary>Flattens the tree for virtualized rendering.</summary>
    public static IEnumerable<(CallTreeNode Node, int Depth)> Flatten(CallTreeNode root, HashSet<CallTreeNode> collapsed, int depth = 0)
    {
        foreach (var child in root.Children)
        {
            yield return (child, depth);
            if (!collapsed.Contains(child))
            {
                foreach (var nested in Flatten(child, collapsed, depth + 1))
                    yield return nested;
            }
        }
    }
}
