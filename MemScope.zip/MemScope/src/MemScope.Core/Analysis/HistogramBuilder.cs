using MemScope.Core.Models;
using MemScope.Core.Util;

namespace MemScope.Core.Analysis;

public sealed record HistogramBucket(
    string Label,
    long MinSize,
    long MaxSize,
    long Count,
    long Bytes)
{
    public long Total => Count;
}

public sealed class HistogramData
{
    public IReadOnlyList<HistogramBucket> Buckets { get; init; } = Array.Empty<HistogramBucket>();
    public long TotalCount { get; init; }
    public long TotalBytes { get; init; }
    public bool Estimated { get; init; }
    public long MaxCount => Buckets.Count == 0 ? 0 : Buckets.Max(b => b.Count);
    public long ModeBucketBytes => Buckets.Count == 0 ? 0 : Buckets.OrderByDescending(b => b.Count).First().MinSize;
}

public static class HistogramBuilder
{
    public static readonly (long Min, long Max)[] Ranges =
    {
        (0, 16), (16, 32), (32, 64), (64, 128), (128, 256), (256, 512),
        (512, 1024), (1024, 2048), (2048, 4096), (4096, 8192), (8192, 16384),
        (16384, 65536), (65536, 262144), (262144, 1048576), (1048576, 4194304),
        (4194304, long.MaxValue)
    };

    public static string LabelFor(long min, long max)
    {
        if (max == long.MaxValue) return $"{Humanize.BytesCompact(min)}+";
        if (min == 0) return $"<{Humanize.BytesCompact(max)}";
        return $"{Humanize.BytesCompact(min)}–{Humanize.BytesCompact(max)}";
    }

    public static int BucketIndex(long size)
    {
        for (int i = 0; i < Ranges.Length; i++)
        {
            if (size >= Ranges[i].Min && size < Ranges[i].Max) return i;
        }
        return Ranges.Length - 1;
    }

    public static HistogramData Build(MemSession session)
    {
        var counts = new long[Ranges.Length];
        var bytes = new long[Ranges.Length];
        long totalCount = 0, totalBytes = 0;
        bool estimated = true;

        var allocations = session.Events.Where(e => e.Kind != AllocationEventKind.Free && e.Size > 0).ToList();
        if (allocations.Count >= 50)
        {
            estimated = false;
            foreach (var evt in allocations)
            {
                int idx = BucketIndex(evt.Size);
                counts[idx]++;
                bytes[idx] += evt.Size;
                totalCount++;
                totalBytes += evt.Size;
            }
        }
        else
        {
            // Statistically distribute each backtrace's allocations around its mean block size.
            foreach (var stack in session.Stacks)
            {
                if (stack.Allocations <= 0) continue;
                double mean = stack.Allocations > 0 ? (double)stack.TotalBytes / stack.Allocations : 32;
                int center = BucketIndex((long)Math.Max(1, mean));
                for (int offset = -2; offset <= 2; offset++)
                {
                    int idx = Math.Clamp(center + offset, 0, Ranges.Length - 1);
                    double weight = offset switch
                    {
                        0 => 0.44,
                        1 or -1 => 0.19,
                        _ => 0.09
                    };
                    long addCount = (long)Math.Round(stack.Allocations * weight);
                    if (addCount <= 0) continue;
                    counts[idx] += addCount;
                    bytes[idx] += addCount * Math.Max(Ranges[idx].Min, (long)mean);
                    totalCount += addCount;
                    totalBytes += addCount * Math.Max(Ranges[idx].Min, (long)mean);
                }
            }
        }

        var buckets = new List<HistogramBucket>(Ranges.Length);
        for (int i = 0; i < Ranges.Length; i++)
        {
            buckets.Add(new HistogramBucket(LabelFor(Ranges[i].Min, Ranges[i].Max), Ranges[i].Min, Ranges[i].Max, counts[i], bytes[i]));
        }

        return new HistogramData
        {
            Buckets = buckets,
            TotalCount = totalCount,
            TotalBytes = totalBytes,
            Estimated = estimated
        };
    }

    public static HistogramData FromSizes(IEnumerable<long> sizes)
    {
        var counts = new long[Ranges.Length];
        var bytes = new long[Ranges.Length];
        long total = 0, totalBytes = 0;
        foreach (var size in sizes)
        {
            if (size <= 0) continue;
            int idx = BucketIndex(size);
            counts[idx]++;
            bytes[idx] += size;
            total++;
            totalBytes += size;
        }
        var buckets = new List<HistogramBucket>(Ranges.Length);
        for (int i = 0; i < Ranges.Length; i++)
            buckets.Add(new HistogramBucket(LabelFor(Ranges[i].Min, Ranges[i].Max), Ranges[i].Min, Ranges[i].Max, counts[i], bytes[i]));
        return new HistogramData { Buckets = buckets, TotalCount = total, TotalBytes = totalBytes, Estimated = false };
    }
}
