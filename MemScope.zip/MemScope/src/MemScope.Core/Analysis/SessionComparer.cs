using MemScope.Core.Models;
using MemScope.Core.Util;

namespace MemScope.Core.Analysis;

public sealed record DiffEntry(
    string Path,
    string Title,
    string Module,
    long LiveA,
    long LiveB,
    long Delta,
    long AllocationsA,
    long AllocationsB,
    long FreesA,
    long FreesB,
    string Status)
{
    public double DeltaRatio => LiveA <= 0 ? (LiveB > 0 ? 1 : 0) : (double)(LiveB - LiveA) / LiveA;
    public string DeltaLabel => (Delta >= 0 ? "+" : "-") + Humanize.Bytes(Math.Abs(Delta));
}

public sealed record DiffSummary(
    IReadOnlyList<DiffEntry> Entries,
    long LiveA,
    long LiveB,
    int NewCount,
    int ResolvedCount,
    int GrownCount,
    int ShrunkCount)
{
    public long Delta => LiveB - LiveA;
    public double DeltaRatio => LiveA <= 0 ? (LiveB > 0 ? 1 : 0) : (double)Delta / LiveA;
}

/// <summary>Compares two captures (or two snapshots) by canonical backtrace identity.</summary>
public static class SessionComparer
{
    private const char Separator = '\u001F';

    public static string CanonicalPath(MemSession session, StackRecord stack)
    {
        var frames = new List<string>(stack.Frames.Length);
        for (int i = stack.Frames.Length - 1; i >= 0; i--)
        {
            var frame = session.GetFrame(stack.Frames[i]);
            if (frame is null) continue;
            frames.Add(frame.DisplayFunction);
        }
        return string.Join(Separator, frames);
    }

    public static DiffSummary Compare(MemSession left, MemSession right, int take = 1000)
    {
        var a = Aggregate(left);
        var b = Aggregate(right);
        var entries = new List<DiffEntry>(a.Count + b.Count);

        foreach (var key in a.Keys.Union(b.Keys, StringComparer.Ordinal))
        {
            a.TryGetValue(key, out var leftRow);
            b.TryGetValue(key, out var rightRow);
            var title = (rightRow?.Title ?? leftRow?.Title) ?? "Unknown";
            var module = (rightRow?.Module ?? leftRow?.Module) ?? "Unknown";
            long liveA = leftRow?.Live ?? 0;
            long liveB = rightRow?.Live ?? 0;
            long delta = liveB - liveA;
            string status = liveA == 0 ? "New" : liveB == 0 ? "Resolved" : delta > 0 ? "Grown" : delta < 0 ? "Shrunk" : "Stable";
            entries.Add(new DiffEntry(
                key.Replace(Separator, '›'),
                title,
                module,
                liveA,
                liveB,
                delta,
                leftRow?.Allocations ?? 0,
                rightRow?.Allocations ?? 0,
                leftRow?.Frees ?? 0,
                rightRow?.Frees ?? 0,
                status));
        }

        entries.Sort((x, y) => Math.Abs(y.Delta).CompareTo(Math.Abs(x.Delta)));
        var trimmed = entries.Take(take).ToList();
        return new DiffSummary(
            trimmed,
            left.TotalLiveBytes,
            right.TotalLiveBytes,
            entries.Count(e => e.Status == "New"),
            entries.Count(e => e.Status == "Resolved"),
            entries.Count(e => e.Status == "Grown"),
            entries.Count(e => e.Status == "Shrunk"));
    }

    private sealed record Row(string Title, string Module, long Live, long Allocations, long Frees);

    private static Dictionary<string, Row> Aggregate(MemSession session)
    {
        var map = new Dictionary<string, Row>(StringComparer.Ordinal);
        foreach (var stack in session.Stacks)
        {
            string key = CanonicalPath(session, stack);
            if (map.TryGetValue(key, out var existing))
            {
                map[key] = existing with
                {
                    Live = existing.Live + stack.LiveBytes,
                    Allocations = existing.Allocations + stack.Allocations,
                    Frees = existing.Frees + stack.Frees
                };
            }
            else
            {
                var leaf = session.LeafFrame(stack);
                map[key] = new Row(
                    session.TitleOf(stack, 3),
                    session.ModuleNameOf(leaf),
                    stack.LiveBytes,
                    stack.Allocations,
                    stack.Frees);
            }
        }
        return map;
    }
}
