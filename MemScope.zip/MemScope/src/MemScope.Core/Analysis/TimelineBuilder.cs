using MemScope.Core.Models;
using MemScope.Core.Util;

namespace MemScope.Core.Analysis;

public sealed record TimelinePoint(
    string Name,
    long TimestampMs,
    long UsageBytes,
    long PeakBytes,
    long OverheadBytes,
    long LiveBlocks,
    long Allocations,
    long Frees);

public sealed class TimelineSeries
{
    public IReadOnlyList<TimelinePoint> Points { get; init; } = Array.Empty<TimelinePoint>();
    public long MaxUsage { get; init; }
    public long MaxLiveBlocks { get; init; }
    public double DurationMs { get; init; }
    public long StartUsage => Points.Count > 0 ? Points[0].UsageBytes : 0;
    public long EndUsage => Points.Count > 0 ? Points[^1].UsageBytes : 0;
    public long Delta => EndUsage - StartUsage;
    public double GrowthRatio => StartUsage <= 0 ? 0 : (double)Delta / StartUsage;
    public long MaxAllocations => Points.Count == 0 ? 0 : Points.Max(p => p.Allocations);
    public long MinUsage => Points.Count == 0 ? 0 : Points.Min(p => p.UsageBytes);
}

public static class TimelineBuilder
{
    public static TimelineSeries Build(MemSession session)
    {
        var points = session.Snapshots
            .Select((s, i) => new TimelinePoint(
                string.IsNullOrWhiteSpace(s.Name) ? $"S{i + 1}" : s.Name,
                s.TimestampMs,
                s.UsageBytes,
                s.PeakBytes,
                s.OverheadBytes,
                s.LiveBlocks,
                s.Allocations,
                s.Frees))
            .ToList();

        return new TimelineSeries
        {
            Points = points,
            MaxUsage = points.Count == 0 ? 0 : points.Max(p => p.UsageBytes),
            MaxLiveBlocks = points.Count == 0 ? 0 : points.Max(p => p.LiveBlocks),
            DurationMs = points.Count == 0 ? 0 : points[^1].TimestampMs - points[0].TimestampMs
        };
    }

    /// <summary>Builds a synthetic series from a live monitor window for the realtime chart.</summary>
    public static TimelineSeries FromSamples(IEnumerable<(long Timestamp, long Usage, long Peak, long Overhead, long LiveBlocks, long Allocations, long Frees)> samples)
    {
        var points = new List<TimelinePoint>();
        int i = 0;
        foreach (var s in samples)
        {
            points.Add(new TimelinePoint($"#{++i}", s.Timestamp, s.Usage, s.Peak, s.Overhead, s.LiveBlocks, s.Allocations, s.Frees));
        }
        return new TimelineSeries
        {
            Points = points,
            MaxUsage = points.Count == 0 ? 1 : Math.Max(1, points.Max(p => p.UsageBytes)),
            MaxLiveBlocks = points.Count == 0 ? 0 : points.Max(p => p.LiveBlocks),
            DurationMs = points.Count < 2 ? 0 : points[^1].TimestampMs - points[0].TimestampMs
        };
    }
}
