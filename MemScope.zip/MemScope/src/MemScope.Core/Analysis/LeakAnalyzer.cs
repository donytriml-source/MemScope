using MemScope.Core.Models;
using MemScope.Core.Util;

namespace MemScope.Core.Analysis;

public enum LeakConfidence { Watch, Likely, Critical }

public sealed record LeakCandidate(
    int StackId,
    string Title,
    string Module,
    string File,
    int Line,
    long LiveBytes,
    long Allocations,
    long Frees,
    double FreeRatio,
    double GrowthRatio,
    double Score,
    LeakConfidence Confidence,
    IReadOnlyList<string> Reasons);

/// <summary>
/// Heuristic leak detection: a backtrace is suspicious when it retains a large live
/// footprint, frees very little of what it allocates and keeps growing across snapshots.
/// </summary>
public static class LeakAnalyzer
{
    public static IReadOnlyList<LeakCandidate> Analyze(MemSession session, int take = 80)
    {
        long totalLive = Math.Max(1, session.TotalLiveBytes);
        var results = new List<LeakCandidate>();
        int snapshotCount = session.Snapshots.Count;

        foreach (var stack in session.Stacks)
        {
            if (stack.LiveBytes <= 0) continue;
            var leaf = session.LeafFrame(stack);
            if (leaf is null) continue;
            var module = session.ModuleOf(leaf);

            double freeRatio = stack.FreeRatio;
            double growth = 0;
            if (stack.LiveBySnapshot is { Length: > 1 } series)
            {
                int mid = Math.Max(0, series.Length / 2);
                long first = series[mid];
                long last = series[^1];
                if (first > 0) growth = (double)(last - first) / first;
                else if (last > 0) growth = 1;
            }

            double share = (double)stack.LiveBytes / totalLive;
            double score = share * 60
                         + (1 - freeRatio) * 30
                         + Math.Clamp(growth, 0, 1.5) * 25
                         + (stack.LiveBytes > 512 * 1024 ? 8 : 0);

            var reasons = new List<string>();
            if (share >= 0.08) reasons.Add($"{Humanize.Percent(share)} of live heap");
            if (freeRatio <= 0.15) reasons.Add(freeRatio <= 0.02 ? "effectively never freed" : "frees only " + Humanize.Percent(freeRatio));
            if (growth >= 0.25) reasons.Add("growing " + Humanize.Percent(growth) + " since midpoint");
            if (stack.LiveBytes >= 512 * 1024) reasons.Add(Humanize.Bytes(stack.LiveBytes) + " retained");
            if (snapshotCount < 3) reasons.Add("short capture — confidence limited");

            if (share < 0.015 && growth < 0.2 && stack.LiveBytes < 128 * 1024) continue;

            var confidence = score >= 55 && growth > 0.2 ? LeakConfidence.Critical
                : score >= 30 ? LeakConfidence.Likely
                : LeakConfidence.Watch;

            results.Add(new LeakCandidate(
                stack.Id,
                session.TitleOf(stack, 3),
                module?.Name ?? "Unknown",
                leaf.File,
                leaf.Line,
                stack.LiveBytes,
                stack.Allocations,
                stack.Frees,
                freeRatio,
                growth,
                score,
                confidence,
                reasons));
        }

        results.Sort((a, b) => b.Score.CompareTo(a.Score));
        return results.Take(take).ToList();
    }
}
