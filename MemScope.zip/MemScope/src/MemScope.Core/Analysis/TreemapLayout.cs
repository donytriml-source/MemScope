using MemScope.Core.Models;

namespace MemScope.Core.Analysis;

public readonly record struct RectD(double X, double Y, double Width, double Height)
{
    public double Area => Width * Height;
    public double Right => X + Width;
    public double Bottom => Y + Height;
    public RectD Inset(double amount) => new(X + amount, Y + amount, Math.Max(0, Width - amount * 2), Math.Max(0, Height - amount * 2));
}

public sealed class TreemapTile
{
    public double X { get; init; }
    public double Y { get; init; }
    public double Width { get; init; }
    public double Height { get; init; }
    public string Label { get; init; } = string.Empty;
    public string Module { get; init; } = string.Empty;
    public long Bytes { get; init; }
    public int Depth { get; init; }
    public int FrameId { get; init; }
    public CallTreeNode? Node { get; init; }
    public string Path { get; init; } = string.Empty;

    public RectD Bounds => new(X, Y, Width, Height);
    public double Area => Width * Height;
    public bool Contains(double x, double y) => x >= X && x <= X + Width && y >= Y && y <= Y + Height;
}

/// <summary>Squarified treemap layout (Bruls, Huizing &amp; van Wijk) tuned for heap composition.</summary>
public static class TreemapLayout
{
    public static IReadOnlyList<TreemapTile> Build(
        CallTreeNode root,
        double width,
        double height,
        int maxDepth = 4,
        double padding = 2.0,
        int maxChildren = 28,
        long minAreaPixels = 5)
    {
        var tiles = new List<TreemapTile>();
        if (width <= 4 || height <= 4 || root.Children.Count == 0) return tiles;

        LayoutNode(root, new RectD(0, 0, width, height), 0, maxDepth, padding, maxChildren, minAreaPixels, tiles, string.Empty);
        return tiles;
    }

    private static void LayoutNode(
        CallTreeNode node,
        RectD rect,
        int depth,
        int maxDepth,
        double padding,
        int maxChildren,
        long minAreaPixels,
        List<TreemapTile> output,
        string parentPath)
    {
        if (depth >= maxDepth || rect.Width < 8 || rect.Height < 8) return;

        var children = node.Children
            .Where(c => c.Usage > 0)
            .OrderByDescending(c => c.Usage)
            .Take(maxChildren)
            .ToList();
        if (children.Count == 0) return;

        var inner = rect.Inset(padding);
        if (inner.Width < 4 || inner.Height < 4) return;

        var items = children.Select(c => (Node: c, Bytes: (double)c.Usage)).ToList();
        var areas = Squarify(items, inner);

        for (int i = 0; i < children.Count && i < areas.Count; i++)
        {
            var child = children[i];
            var area = areas[i];
            if (area.Width <= 0 || area.Height <= 0) continue;
            if (area.Area < minAreaPixels) continue;

            string path = string.IsNullOrEmpty(parentPath) ? child.Name : parentPath + " › " + child.Name;
            output.Add(new TreemapTile
            {
                X = area.X,
                Y = area.Y,
                Width = area.Width,
                Height = area.Height,
                Label = child.Name,
                Module = child.Module,
                Bytes = child.Usage,
                Depth = depth,
                FrameId = child.FrameId,
                Node = child,
                Path = path
            });

            if (depth + 1 < maxDepth && child.Children.Count > 0 && area.Width > 34 && area.Height > 26)
                LayoutNode(child, area, depth + 1, maxDepth, 1.5, maxChildren, minAreaPixels, output, path);
        }
    }

    private static List<RectD> Squarify(IReadOnlyList<(CallTreeNode Node, double Bytes)> items, RectD rect)
    {
        var results = new List<RectD>(items.Count);
        double total = items.Sum(i => i.Bytes);
        if (total <= 0) return results;

        double scale = rect.Width * rect.Height / total;
        var areas = items.Select(i => Math.Max(0.0001, i.Bytes * scale)).ToList();

        int index = 0;
        double x = rect.X, y = rect.Y, w = rect.Width, h = rect.Height;

        while (index < areas.Count && w > 0.5 && h > 0.5)
        {
            double side = Math.Min(w, h);
            int start = index;
            int end = index + 1;
            double worst = Worst(side, areas, start, end);

            while (end < areas.Count)
            {
                double candidate = Worst(side, areas, start, end + 1);
                if (candidate > worst) break;
                worst = candidate;
                end++;
            }

            double rowArea = 0;
            for (int k = start; k < end; k++) rowArea += areas[k];

            if (w >= h)
            {
                double stripWidth = Math.Min(w, rowArea / Math.Max(0.0001, h));
                double cy = y;
                for (int k = start; k < end; k++)
                {
                    double tileHeight = stripWidth <= 0 ? 0 : areas[k] / stripWidth;
                    results.Add(new RectD(x, cy, stripWidth, tileHeight));
                    cy += tileHeight;
                }
                x += stripWidth;
                w -= stripWidth;
            }
            else
            {
                double stripHeight = Math.Min(h, rowArea / Math.Max(0.0001, w));
                double cx = x;
                for (int k = start; k < end; k++)
                {
                    double tileWidth = stripHeight <= 0 ? 0 : areas[k] / stripHeight;
                    results.Add(new RectD(cx, y, tileWidth, stripHeight));
                    cx += tileWidth;
                }
                y += stripHeight;
                h -= stripHeight;
            }

            index = end;
        }

        return results;
    }

    private static double Worst(double side, IReadOnlyList<double> areas, int start, int end)
    {
        double sum = 0, min = double.MaxValue, max = 0;
        for (int i = start; i < end; i++)
        {
            double a = areas[i];
            sum += a;
            if (a < min) min = a;
            if (a > max) max = a;
        }
        if (sum <= 0 || min <= 0) return double.MaxValue;
        double sideSq = side * side;
        return Math.Max(sideSq * max / (sum * sum), sum * sum / (sideSq * min));
    }
}
