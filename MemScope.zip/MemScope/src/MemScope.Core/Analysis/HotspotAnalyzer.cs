using MemScope.Core.Models;

namespace MemScope.Core.Analysis;

public sealed record Hotspot(
    int StackId,
    string Title,
    string Function,
    string Module,
    string File,
    int Line,
    long LiveBytes,
    long Allocations,
    long Frees,
    long Reallocations,
    double ChurnRatio,
    double Score,
    string Path)
{
    public long LiveBlocks => Allocations <= 0 ? 0 : (long)Math.Max(1, LiveBytes / Math.Max(1, (double)(LiveBytes + Frees) / Allocations));
}

public enum HotspotMode
{
    LiveBytes,
    Allocations,
    Churn,
    AverageSize
}

/// <summary>Ranks individual backtraces by pressure, churn or size.</summary>
public static class HotspotAnalyzer
{
    public static IReadOnlyList<Hotspot> Analyze(MemSession session, HotspotMode mode = HotspotMode.LiveBytes, int take = 200)
    {
        double totalLive = Math.Max(1, session.TotalLiveBytes);
        var list = new List<Hotspot>(session.Stacks.Count);

        foreach (var stack in session.Stacks)
        {
            var leaf = session.LeafFrame(stack);
            if (leaf is null) continue;
            var module = session.ModuleOf(leaf);
            string title = session.TitleOf(stack, 4);
            double churn = stack.Allocations > 0 ? (double)stack.Frees / stack.Allocations : 0;
            double share = stack.LiveBytes / totalLive;
            double score = mode switch
            {
                HotspotMode.Allocations => stack.Allocations * (1 + Math.Max(0, 0.4 - churn)),
                HotspotMode.Churn => stack.Allocations + stack.Frees * 0.6,
                HotspotMode.AverageSize => stack.Allocations == 0 ? 0 : (double)stack.LiveBytes / stack.Allocations,
                _ => stack.LiveBytes * (1 + Math.Max(0, 0.35 - churn))
            };

            list.Add(new Hotspot(
                stack.Id,
                title,
                leaf.DisplayFunction,
                module?.Name ?? "Unknown",
                leaf.File,
                leaf.Line,
                stack.LiveBytes,
                stack.Allocations,
                stack.Frees,
                stack.Reallocations,
                churn,
                score,
                session.PathOf(stack, 6))
            { });
        }

        list.Sort((a, b) => b.Score.CompareTo(a.Score));
        return list.Take(Math.Max(1, take)).ToList();
    }
}
