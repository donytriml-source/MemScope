namespace MemScope.Core.Models;

/// <summary>A point-in-time memory reading captured by the profiler.</summary>
public sealed class MemorySnapshot
{
    public string Name { get; set; } = "Snapshot";
    public long TimestampMs { get; set; }
    public long UsageBytes { get; set; }
    public long PeakBytes { get; set; }
    public long OverheadBytes { get; set; }
    public long PeakOverheadBytes { get; set; }
    public long Operations { get; set; }
    public long Allocations { get; set; }
    public long Reallocations { get; set; }
    public long Frees { get; set; }
    public long LiveBlocks { get; set; }
    public int HeapCount { get; set; }
    public int ThreadCount { get; set; }
    public string? Note { get; set; }
}

public sealed class SessionMetadata
{
    public string CaptureId { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "Untitled capture";
    public string TargetProcess { get; set; } = "Unknown";
    public string TargetPath { get; set; } = string.Empty;
    public string MachineName { get; set; } = Environment.MachineName;
    public string OperatingSystem { get; set; } = Environment.OSVersion.VersionString;
    public DateTimeOffset CapturedAt { get; set; } = DateTimeOffset.Now;
    public double DurationMs { get; set; }
    public double SamplingIntervalMs { get; set; } = 250;
    public int PointerSize { get; set; } = Environment.Is64BitProcess ? 8 : 4;
    public int ThreadCount { get; set; }
    public int HeapCount { get; set; }
    public int ProcessorCount { get; set; } = Environment.ProcessorCount;
    public string Origin { get; set; } = "Capture";
    public string ToolVersion { get; set; } = Branding.Version;
    public string Notes { get; set; } = string.Empty;
    public bool IsSynthetic { get; set; }
    public List<string> Tags { get; set; } = new();

    public string DisplayDate => CapturedAt.LocalDateTime.ToString("MMM d, yyyy · HH:mm:ss");
    public string DisplayDuration => Util.Humanize.Duration(DurationMs);
}
