namespace MemScope.Core.Models;

public enum MemoryRegionState : uint
{
    Free = 0x10000,
    Reserve = 0x2000,
    Commit = 0x1000
}

public enum MemoryRegionType : uint
{
    Private = 0x20000,
    Mapped = 0x40000,
    Image = 0x1000000,
    Unknown = 0
}

public sealed class MemoryRegionInfo
{
    public long BaseAddress { get; init; }
    public long Size { get; init; }
    public MemoryRegionState State { get; init; }
    public MemoryRegionType Type { get; init; }
    public uint Protection { get; init; }
    public string Detail { get; init; } = string.Empty;

    public long End => BaseAddress + Size;
    public string StateLabel => State switch
    {
        MemoryRegionState.Commit => "Commit",
        MemoryRegionState.Reserve => "Reserve",
        _ => "Free"
    };

    public string TypeLabel => Type switch
    {
        MemoryRegionType.Image => "Image",
        MemoryRegionType.Mapped => "Mapped",
        MemoryRegionType.Private => "Private",
        _ => "—"
    };

    public string ProtectionLabel => (Protection & 0xFF) switch
    {
        0x01 => "No access",
        0x02 => "Read-only",
        0x04 => "Read/write",
        0x08 => "Writecopy",
        0x10 => "Execute",
        0x20 => "Execute/read",
        0x40 => "Execute/read/write",
        0x80 => "Execute/writecopy",
        _ => "—"
    };
}

public sealed class LiveHeap
{
    public long Id { get; init; }
    public long BlockCount { get; init; }
    public long Bytes { get; init; }
    public bool IsDefault { get; init; }
    public bool IsShared { get; init; }
    public string FlagsLabel => (IsDefault ? "default" : "private") + (IsShared ? " · shared" : string.Empty);
    public string Name => IsDefault ? "Default process heap" : $"Heap 0x{Id:X}";
}

public sealed class LiveModule
{
    public string Name { get; init; } = string.Empty;
    public string Path { get; init; } = string.Empty;
    public long BaseAddress { get; init; }
    public long Size { get; init; }
    public string Version { get; init; } = string.Empty;
    public bool IsManaged { get; init; }
}

/// <summary>A realtime observation of a target process, produced by the native sampler.</summary>
public sealed class LiveSample
{
    public DateTimeOffset Timestamp { get; init; } = DateTimeOffset.Now;
    public long WorkingSetBytes { get; init; }
    public long PeakWorkingSetBytes { get; init; }
    public long PrivateBytes { get; init; }
    public long PeakPrivateBytes { get; init; }
    public long PagefileBytes { get; init; }
    public long PagedPoolBytes { get; init; }
    public long NonPagedPoolBytes { get; init; }
    public long CommittedBytes { get; init; }
    public long ReservedBytes { get; init; }
    public int RegionCount { get; init; }
    public int Threads { get; init; }
    public int Handles { get; init; }
    public double CpuPercent { get; init; }
    public TimeSpan CpuTime { get; init; }
    public long HeapBytes { get; init; }
    public long HeapBlocks { get; init; }
    public IReadOnlyList<LiveHeap> Heaps { get; init; } = Array.Empty<LiveHeap>();
    public IReadOnlyList<LiveModule> Modules { get; init; } = Array.Empty<LiveModule>();
    public IReadOnlyList<MemoryRegionInfo> Regions { get; init; } = Array.Empty<MemoryRegionInfo>();
    public IReadOnlyList<(long Size, int Count)> BlockSizeHistogram { get; init; } = Array.Empty<(long, int)>();
    public string? Warning { get; init; }
    public string? Error { get; init; }
    public bool IsDeep { get; init; }

    public long VirtualBytes => CommittedBytes + ReservedBytes;
    public long FreeRegionBytes { get; init; }
}

public sealed record ProcessDescriptor(
    int Id,
    string Name,
    string? Path,
    long WorkingSetBytes,
    long PrivateBytes,
    int ThreadCount,
    bool HasWindow,
    bool IsElevated,
    DateTime? StartedAt)
{
    public string Title => $"{Name}  ·  PID {Id}";
    public string Subtitle => $"{Util.Humanize.Bytes(WorkingSetBytes)} working set · {ThreadCount} threads";
}
