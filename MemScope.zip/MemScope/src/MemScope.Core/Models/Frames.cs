namespace MemScope.Core.Models;

/// <summary>A loaded image (executable or DLL) that owns one or more frames.</summary>
public sealed class ModuleInfo
{
    public string Name { get; set; } = "Unknown";
    public string Path { get; set; } = string.Empty;
    public string Version { get; set; } = string.Empty;
    public long BaseAddress { get; set; }
    public long ImageSize { get; set; }
    public bool IsManaged { get; set; }
    public bool IsSystem { get; set; }
    public string? PdbPath { get; set; }

    public override string ToString() => Name;
}

/// <summary>One symbolized stack frame. Frames are interned and shared between stacks.</summary>
public sealed class FrameInfo
{
    public int Id { get; set; }
    public long Address { get; set; }
    public int ModuleIndex { get; set; } = -1;
    public string Function { get; set; } = "Unknown";
    public string File { get; set; } = string.Empty;
    public int Line { get; set; }
    public bool IsUnknown => string.IsNullOrEmpty(Function) || Function == "Unknown";

    public string DisplayFunction => string.IsNullOrWhiteSpace(Function) ? "Unknown" : Function;

    public override string ToString() => $"{Function} [{ModuleIndex}:{Line}]";
}

/// <summary>A native heap as reported by the toolhelp heap walker.</summary>
public sealed class HeapInfo
{
    public long Id { get; set; }
    public string Name { get; set; } = "Allocator";
    public long BlockCount { get; set; }
    public long CommittedBytes { get; set; }
    public bool IsDefault { get; set; }
    public bool IsShared { get; set; }
}
