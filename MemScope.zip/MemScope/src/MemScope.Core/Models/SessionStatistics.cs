namespace MemScope.Core.Models;

/// <summary>The headline counters rendered in the statistics rail.</summary>
public sealed class SessionStatistics
{
    public long UsageBytes { get; init; }
    public long PeakUsageBytes { get; init; }
    public long Operations { get; init; }
    public long Allocations { get; init; }
    public long Reallocations { get; init; }
    public long Frees { get; init; }
    public long LiveBlocks { get; init; }
    public long OverheadBytes { get; init; }
    public long PeakOverheadBytes { get; init; }
    public long TotalAllocatedBytes { get; init; }
    public int Heaps { get; init; }
    public int Threads { get; init; }
    public int Snapshots { get; init; }
    public double DurationMs { get; init; }
    public bool IsSnapshotScoped { get; init; }

    public double LiveRatio => Allocations <= 0 ? 0 : Math.Clamp((double)LiveBlocks / Allocations, 0, 1);
    public double OverheadRatio => UsageBytes <= 0 ? 0 : (double)OverheadBytes / UsageBytes;
    public long AverageBlockSize => LiveBlocks <= 0 ? 0 : UsageBytes / LiveBlocks;
}
