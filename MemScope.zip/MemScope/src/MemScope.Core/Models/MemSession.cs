using MemScope.Core.Util;

namespace MemScope.Core.Models;

/// <summary>
/// A complete MemScope capture: metadata, interned frames, aggregated backtraces,
/// recent operations and the snapshot timeline.
/// </summary>
public sealed class MemSession
{
    public SessionMetadata Metadata { get; set; } = new();
    public List<ModuleInfo> Modules { get; set; } = new();
    public List<FrameInfo> Frames { get; set; } = new();
    public List<StackRecord> Stacks { get; set; } = new();
    public List<AllocationEvent> Events { get; set; } = new();
    public List<MemorySnapshot> Snapshots { get; set; } = new();
    public List<HeapInfo> Heaps { get; set; } = new();
    public Dictionary<string, string> SourceFiles { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    private Dictionary<int, FrameInfo>? _frameIndex;

    public FrameInfo? GetFrame(int id)
    {
        if (_frameIndex is null || _frameIndex.Count != Frames.Count)
        {
            _frameIndex = new Dictionary<int, FrameInfo>(Frames.Count);
            foreach (var frame in Frames) _frameIndex[frame.Id] = frame;
        }
        return _frameIndex.TryGetValue(id, out var f) ? f : null;
    }

    public ModuleInfo? ModuleOf(FrameInfo? frame)
    {
        if (frame is null) return null;
        return frame.ModuleIndex >= 0 && frame.ModuleIndex < Modules.Count ? Modules[frame.ModuleIndex] : null;
    }

    public string ModuleNameOf(FrameInfo? frame) => ModuleOf(frame)?.Name ?? "Unknown";

    public FrameInfo? LeafFrame(StackRecord stack)
    {
        for (int i = 0; i < stack.Frames.Length; i++)
        {
            var f = GetFrame(stack.Frames[i]);
            if (f is not null) return f;
        }
        return null;
    }

    public string TitleOf(StackRecord stack, int maxFrames = 3)
    {
        var parts = new List<string>(maxFrames);
        foreach (var id in stack.Frames)
        {
            var f = GetFrame(id);
            if (f is null) continue;
            parts.Add(CleanName(f.Function));
            if (parts.Count >= maxFrames) break;
        }
        return parts.Count == 0 ? "Unknown" : string.Join(" › ", parts);
    }

    public string PathOf(StackRecord stack, int maxFrames = 8)
    {
        var parts = new List<string>(maxFrames);
        for (int i = Math.Min(stack.Frames.Length, maxFrames) - 1; i >= 0; i--)
        {
            var f = GetFrame(stack.Frames[i]);
            if (f is null) continue;
            parts.Add(CleanName(f.Function));
        }
        return parts.Count == 0 ? "Unknown" : string.Join(" › ", parts);
    }

    public static string CleanName(string? function)
    {
        if (string.IsNullOrWhiteSpace(function)) return "Unknown";
        var name = function.Trim();
        int paren = name.IndexOf('(');
        return paren > 0 ? name[..paren] : name;
    }

    public long TotalLiveBytes => Stacks.Sum(s => s.LiveBytes);
    public int FrameCount => Frames.Count;

    public SessionStatistics ComputeStatistics(int? snapshotIndex = null)
    {
        var last = Snapshots.Count > 0 ? Snapshots[^1] : null;
        long allocs = Stacks.Sum(s => s.Allocations);
        long frees = Stacks.Sum(s => s.Frees);
        long reallocs = Stacks.Sum(s => s.Reallocations);
        long totalBytes = Stacks.Sum(s => s.TotalBytes);
        long totalLive = Stacks.Sum(s => s.LiveBytes);
        long peak = Snapshots.Count > 0 ? Snapshots.Max(s => s.PeakBytes) : Stacks.Sum(s => s.PeakBytes);

        if (snapshotIndex is int index && index >= 0 && index < Snapshots.Count)
        {
            var snap = Snapshots[index];
            return new SessionStatistics
            {
                UsageBytes = snap.UsageBytes,
                PeakUsageBytes = snap.PeakBytes,
                Operations = snap.Operations,
                Allocations = snap.Allocations,
                Reallocations = snap.Reallocations,
                Frees = snap.Frees,
                LiveBlocks = snap.LiveBlocks,
                OverheadBytes = snap.OverheadBytes,
                PeakOverheadBytes = snap.PeakOverheadBytes,
                TotalAllocatedBytes = snap.Allocations > 0 ? snap.UsageBytes + snap.Frees * (snap.UsageBytes / Math.Max(1, Snapshots[0].LiveBlocks)) : totalBytes,
                Heaps = snap.HeapCount,
                Threads = snap.ThreadCount > 0 ? snap.ThreadCount : Metadata.ThreadCount,
                Snapshots = Snapshots.Count,
                DurationMs = snap.TimestampMs,
                IsSnapshotScoped = true
            };
        }

        long liveBlocks = last?.LiveBlocks ?? (allocs - frees);
        long overhead = last?.OverheadBytes ?? 0;
        long peakOverhead = Snapshots.Count > 0 ? Snapshots.Max(s => s.PeakOverheadBytes) : 0;
        return new SessionStatistics
        {
            UsageBytes = last?.UsageBytes ?? totalLive,
            PeakUsageBytes = peak,
            Operations = allocs + frees + reallocs,
            Allocations = allocs,
            Reallocations = reallocs,
            Frees = frees,
            LiveBlocks = Math.Max(liveBlocks, 0),
            OverheadBytes = overhead,
            PeakOverheadBytes = peakOverhead,
            TotalAllocatedBytes = totalBytes,
            Heaps = last?.HeapCount ?? Metadata.HeapCount,
            Threads = last?.ThreadCount ?? Metadata.ThreadCount,
            Snapshots = Snapshots.Count,
            DurationMs = Metadata.DurationMs,
            IsSnapshotScoped = false
        };
    }

    /// <summary>Statistics scoped to a single backtrace selection, used by the inspector.</summary>
    public SessionStatistics StatsForStacks(IEnumerable<StackRecord> stacks)
    {
        var list = stacks as IList<StackRecord> ?? stacks.ToList();
        long allocs = list.Sum(s => s.Allocations);
        long frees = list.Sum(s => s.Frees);
        long reallocs = list.Sum(s => s.Reallocations);
        long live = list.Sum(s => s.LiveBytes);
        long peak = list.Sum(s => s.PeakBytes);
        double avg = allocs > 0 ? (double)list.Sum(s => s.TotalBytes) / allocs : 0;
        return new SessionStatistics
        {
            UsageBytes = live,
            PeakUsageBytes = peak,
            Allocations = allocs,
            Frees = frees,
            Reallocations = reallocs,
            Operations = allocs + frees + reallocs,
            LiveBlocks = avg > 0 ? (long)(live / avg) : 0,
            TotalAllocatedBytes = list.Sum(s => s.TotalBytes),
            OverheadBytes = 0,
            PeakOverheadBytes = 0,
            Heaps = Metadata.HeapCount,
            Threads = Metadata.ThreadCount,
            Snapshots = Snapshots.Count,
            DurationMs = Metadata.DurationMs
        };
    }

    public string Describe() =>
        $"{Metadata.Name} · {Metadata.TargetProcess} · {Humanize.Bytes(ComputeStatistics().UsageBytes)} live";
}
