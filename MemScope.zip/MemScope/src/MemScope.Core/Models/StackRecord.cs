namespace MemScope.Core.Models;

public enum AllocationEventKind : byte
{
    Allocate = 0,
    Reallocate = 1,
    Free = 2
}

/// <summary>A single allocation, reallocation or free observed by the capture engine.</summary>
public readonly record struct AllocationEvent(
    long Address,
    int Size,
    AllocationEventKind Kind,
    long TimestampMs,
    int StackId,
    int ThreadId)
{
    public string KindLabel => Kind switch
    {
        AllocationEventKind.Allocate => "alloc",
        AllocationEventKind.Reallocate => "realloc",
        _ => "free"
    };
}

/// <summary>Aggregated per-backtrace activity. MemScope keeps one record per unique call path.</summary>
public sealed class StackRecord
{
    public int Id { get; set; }

    /// <summary>Frame identifiers ordered leaf → root.</summary>
    public int[] Frames { get; set; } = Array.Empty<int>();

    public long Allocations { get; set; }
    public long Frees { get; set; }
    public long Reallocations { get; set; }
    public long LiveBytes { get; set; }
    public long PeakBytes { get; set; }
    public long TotalBytes { get; set; }
    public int ThreadId { get; set; }
    public long FirstSequence { get; set; }
    public long LastSequence { get; set; }
    public string Heap { get; set; } = "Process heap";

    /// <summary>Live byte footprint of this backtrace at every collected snapshot (optional).</summary>
    public long[]? LiveBySnapshot { get; set; }

    public long LiveBlocks
    {
        get
        {
            long avg = Allocations > 0 ? LiveBytes / Math.Max(1, Allocations) : 0;
            return avg <= 0 ? 0 : LiveBytes / Math.Max(1, avg);
        }
    }

    public double FreeRatio => Allocations <= 0 ? 0 : Math.Clamp((double)Frees / Allocations, 0, 1);
}
