using System.Diagnostics;
using System.Runtime.InteropServices;
using MemScope.Core.Analysis;
using MemScope.Core.Models;

namespace MemScope.Core.Native;

/// <summary>
/// Attaches to a Windows process and samples its real memory state: working set,
/// private bytes, every native heap (toolhelp heap walk), committed regions and modules.
/// No code is injected and no profiler DLL is loaded into the target.
/// </summary>
public sealed class LiveTarget : IDisposable
{
    private const uint ProcessQueryInformation = 0x0400;
    private const uint ProcessVmRead = 0x0010;
    private const uint Th32CsSnapHeapList = 0x00000001;
    private const uint Th32CsSnapModule = 0x00000008;
    private const uint Lf32Free = 0x0002;
    private const uint Hf32Default = 0x0001;
    private const uint Hf32Shared = 0x0002;
    private const long MaxUserAddress = 0x7FFF_FFFE_FFFF;

    private readonly Process _process;
    private readonly IntPtr _handle;
    private TimeSpan _lastCpuTime;
    private DateTime _lastCpuSampleAt = DateTime.MinValue;
    private List<LiveModule> _modules = new();
    private DateTime _modulesAt = DateTime.MinValue;
    private LiveSample? _lastDeep;

    public int ProcessId { get; }
    public string ProcessName { get; }
    public string? ImagePath { get; }
    public bool CanReadMemory => _handle != IntPtr.Zero;
    public string? AccessWarning { get; }
    public bool IsAlive
    {
        get
        {
            try { return !_process.HasExited; } catch { return false; }
        }
    }

    public LiveTarget(int processId)
    {
        ProcessId = processId;
        _process = Process.GetProcessById(processId);
        ProcessName = _process.ProcessName;
        try { ImagePath = _process.MainModule?.FileName; } catch { ImagePath = null; }

        _handle = OpenProcess(ProcessQueryInformation | ProcessVmRead, false, processId);
        if (_handle == IntPtr.Zero)
        {
            AccessWarning = "Memory inspection is limited. Run MemScope elevated to walk heaps and regions of this process.";
        }

        try
        {
            _lastCpuTime = _process.TotalProcessorTime;
            _lastCpuSampleAt = DateTime.UtcNow;
        }
        catch
        {
            // Protected process; CPU timing stays unavailable.
        }
    }

    public LiveSample Sample(bool deep)
    {
        if (!IsAlive)
        {
            return new LiveSample { Error = "The target process has exited.", IsDeep = deep };
        }

        string? warning = AccessWarning;
        long workingSet = 0, peakWorkingSet = 0, privateBytes = 0, peakPrivate = 0, pagefile = 0;
        long pagedPool = 0, nonPaged = 0;
        int threads = 0, handles = 0;

        try
        {
            _process.Refresh();
            threads = _process.Threads.Count;
            handles = _process.HandleCount;
        }
        catch
        {
            // ignore
        }

        if (_handle != IntPtr.Zero)
        {
            var counters = new ProcessMemoryCountersEx { cb = (uint)Marshal.SizeOf<ProcessMemoryCountersEx>() };
            if (GetProcessMemoryInfo(_handle, ref counters, counters.cb))
            {
                workingSet = (long)counters.WorkingSetSize.ToUInt64();
                peakWorkingSet = (long)counters.PeakWorkingSetSize.ToUInt64();
                privateBytes = (long)counters.PrivateUsage.ToUInt64();
                peakPrivate = (long)counters.PeakPagefileUsage.ToUInt64();
                pagefile = (long)counters.PagefileUsage.ToUInt64();
                pagedPool = (long)counters.QuotaPagedPoolUsage.ToUInt64();
                nonPaged = (long)counters.QuotaNonPagedPoolUsage.ToUInt64();
            }
            else
            {
                warning ??= LastError("GetProcessMemoryInfo");
            }
        }

        if (workingSet == 0)
        {
            try { workingSet = _process.WorkingSet64; } catch { }
            try { privateBytes = _process.PrivateMemorySize64; } catch { }
            try { peakWorkingSet = _process.PeakWorkingSet64; } catch { }
        }

        double cpuPercent = 0;
        TimeSpan cpuTime = TimeSpan.Zero;
        try
        {
            cpuTime = _process.TotalProcessorTime;
            var now = DateTime.UtcNow;
            if (_lastCpuSampleAt != DateTime.MinValue)
            {
                double elapsed = Math.Max(0.001, (now - _lastCpuSampleAt).TotalSeconds);
                double used = (cpuTime - _lastCpuTime).TotalSeconds;
                cpuPercent = Math.Clamp(used / (elapsed * Math.Max(1, Environment.ProcessorCount)) * 100, 0, 100 * Math.Max(1, Environment.ProcessorCount));
            }
            _lastCpuTime = cpuTime;
            _lastCpuSampleAt = now;
        }
        catch
        {
            // ignore
        }

        LiveHeap[] heaps;
        long heapBytes;
        long heapBlocks;
        (long Size, int Count)[] histogram;
        if (deep)
        {
            heaps = ReadHeaps(out heapBytes, out heapBlocks, out histogram, out string? heapWarning);
            warning ??= heapWarning;
        }
        else
        {
            heaps = Array.Empty<LiveHeap>();
            heapBytes = _lastDeep?.HeapBytes ?? 0;
            heapBlocks = _lastDeep?.HeapBlocks ?? 0;
            histogram = _lastDeep?.BlockSizeHistogram.ToArray() ?? Array.Empty<(long, int)>();
        }

        long committed = 0, reserved = 0, freeBytes = 0;
        var regions = Array.Empty<MemoryRegionInfo>();
        if (deep && _handle != IntPtr.Zero)
        {
            regions = ReadRegions(ref committed, ref reserved, ref freeBytes, out string? regionWarning);
            warning ??= regionWarning;
        }
        else if (_lastDeep is not null)
        {
            committed = _lastDeep.CommittedBytes;
            reserved = _lastDeep.ReservedBytes;
            freeBytes = _lastDeep.FreeRegionBytes;
        }

        var modules = ReadModules();

        var sample = new LiveSample
        {
            Timestamp = DateTimeOffset.Now,
            WorkingSetBytes = workingSet,
            PeakWorkingSetBytes = peakWorkingSet,
            PrivateBytes = privateBytes,
            PeakPrivateBytes = peakPrivate,
            PagefileBytes = pagefile,
            PagedPoolBytes = pagedPool,
            NonPagedPoolBytes = nonPaged,
            CommittedBytes = committed,
            ReservedBytes = reserved,
            FreeRegionBytes = freeBytes,
            RegionCount = regions.Length,
            Threads = threads,
            Handles = handles,
            CpuPercent = cpuPercent,
            CpuTime = cpuTime,
            HeapBytes = heapBytes,
            HeapBlocks = heapBlocks,
            Heaps = heaps,
            Modules = modules,
            Regions = regions,
            BlockSizeHistogram = histogram ?? Array.Empty<(long, int)>(),
            Warning = warning,
            IsDeep = deep
        };

        if (deep) _lastDeep = sample;
        return sample;
    }

    private LiveHeap[] ReadHeaps(out long totalBytes, out long totalBlocks, out (long Size, int Count)[] histogram, out string? warning)
    {
        totalBytes = 0;
        totalBlocks = 0;
        histogram = Array.Empty<(long, int)>();
        warning = null;
        if (_handle == IntPtr.Zero)
        {
            warning = "Heap walking requires PROCESS_VM_READ access.";
            return Array.Empty<LiveHeap>();
        }

        IntPtr snapshot = CreateToolhelp32Snapshot(Th32CsSnapHeapList, (uint)ProcessId);
        if (snapshot == IntPtr.Zero || snapshot == new IntPtr(-1))
        {
            warning = LastError("CreateToolhelp32Snapshot(heap)");
            return Array.Empty<LiveHeap>();
        }

        var heaps = new List<LiveHeap>();
        var histogramCounts = new int[HistogramBuilder.Ranges.Length];
        var budget = Stopwatch.StartNew();
        const long maxBlocks = 240_000;
        const int blockBudgetMs = 200;
        int entrySize = Marshal.SizeOf<HeapEntry32>();
        bool stopped = false;

        try
        {
            var heapList = new HeapList32 { dwSize = (UIntPtr)Marshal.SizeOf<HeapList32>() };
            if (!Heap32ListFirst(snapshot, ref heapList))
            {
                warning = LastError("Heap32ListFirst");
                return Array.Empty<LiveHeap>();
            }

            do
            {
                long blocks = 0, bytes = 0;
                var entry = new HeapEntry32 { dwSize = (UIntPtr)entrySize };
                if (Heap32First(ref entry, (uint)ProcessId, heapList.th32HeapId))
                {
                    // Heap32Next is slow on large heaps, so the time budget is checked
                    // inside the block loop rather than only between heaps.
                    int sinceCheck = 0;
                    do
                    {
                        if ((entry.dwFlags & Lf32Free) == 0)
                        {
                            long size = (long)entry.dwBlockSize.ToUInt64();
                            blocks++;
                            bytes += size;
                            if (size > 0)
                            {
                                int idx = HistogramBuilder.BucketIndex(size);
                                histogramCounts[idx]++;
                            }
                        }

                        if (sinceCheck++ >= 1024)
                        {
                            sinceCheck = 0;
                            if (budget.ElapsedMilliseconds > blockBudgetMs)
                            {
                                stopped = true;
                                break;
                            }
                        }

                        entry.dwSize = (UIntPtr)entrySize;
                    }
                    while (totalBlocks + blocks < maxBlocks && Heap32Next(ref entry));
                }

                heaps.Add(new LiveHeap
                {
                    Id = (long)heapList.th32HeapId.ToUInt64(),
                    BlockCount = blocks,
                    Bytes = bytes,
                    IsDefault = (heapList.dwFlags & Hf32Default) != 0,
                    IsShared = (heapList.dwFlags & Hf32Shared) != 0
                });

                totalBytes += bytes;
                totalBlocks += blocks;
                if (stopped || budget.ElapsedMilliseconds > blockBudgetMs || totalBlocks >= maxBlocks) break;
                heapList.dwSize = (UIntPtr)Marshal.SizeOf<HeapList32>();
            }
            while (Heap32ListNext(snapshot, ref heapList));
        }
        finally
        {
            CloseHandle(snapshot);
        }

        histogram = HistogramBuilder.Ranges
            .Select((range, i) => (range.Min, histogramCounts[i]))
            .Where(x => x.Item2 > 0)
            .Select(x => (x.Min, x.Item2))
            .ToArray();

        // The heap walk is intentionally bounded (time and block count) so the Live
        // monitor stays responsive; hitting the bound is normal, not a warning.
        return heaps.OrderByDescending(h => h.Bytes).ToArray();
    }

    private MemoryRegionInfo[] ReadRegions(ref long committed, ref long reserved, ref long freeBytes, out string? warning)
    {
        warning = null;
        var regions = new List<MemoryRegionInfo>(2048);
        var budget = Stopwatch.StartNew();
        const int maxRegions = 9000;
        long address = 0;

        while (address < MaxUserAddress)
        {
            UIntPtr query = VirtualQueryEx(_handle, (IntPtr)address, out MemoryBasicInformation info, (UIntPtr)Marshal.SizeOf<MemoryBasicInformation>());
            if (query == UIntPtr.Zero)
            {
                warning ??= LastError("VirtualQueryEx");
                break;
            }

            long size = (long)info.RegionSize.ToUInt64();
            if (size <= 0) break;
            long baseAddress = (long)info.BaseAddress;

            switch (info.State)
            {
                case 0x1000:
                    committed += size;
                    break;
                case 0x2000:
                    reserved += size;
                    break;
                default:
                    freeBytes += size;
                    break;
            }

            if (info.State != 0x10000 && regions.Count < maxRegions)
            {
                regions.Add(new MemoryRegionInfo
                {
                    BaseAddress = baseAddress,
                    Size = size,
                    State = (MemoryRegionState)info.State,
                    Type = (MemoryRegionType)info.Type,
                    Protection = info.Protect,
                    Detail = string.Empty
                });
            }

            address = baseAddress + size;
            if (address <= 0) break;
            if (budget.ElapsedMilliseconds > 140 || regions.Count >= maxRegions)
            {
                // Bounded scan keeps the Live monitor responsive; not a warning.
                break;
            }
        }

        return regions.ToArray();
    }

    private List<LiveModule> ReadModules()
    {
        if (DateTime.UtcNow - _modulesAt < TimeSpan.FromSeconds(4) && _modules.Count > 0) return _modules;
        var modules = new List<LiveModule>();
        try
        {
            foreach (ProcessModule module in _process.Modules)
            {
                try
                {
                    string name = module.ModuleName ?? string.Empty;
                    modules.Add(new LiveModule
                    {
                        Name = name,
                        Path = module.FileName ?? string.Empty,
                        BaseAddress = module.BaseAddress.ToInt64(),
                        Size = module.ModuleMemorySize,
                        Version = module.FileVersionInfo?.FileVersion ?? string.Empty,
                        IsManaged = name.Equals("coreclr.dll", StringComparison.OrdinalIgnoreCase)
                                    || name.StartsWith("System.", StringComparison.OrdinalIgnoreCase)
                                    || name.Equals("clrjit.dll", StringComparison.OrdinalIgnoreCase)
                    });
                }
                catch
                {
                    // module vanished
                }
            }
        }
        catch
        {
            // Process modules unavailable (32/64-bit mismatch or access denied).
        }

        _modules = modules.OrderBy(m => m.Name, StringComparer.OrdinalIgnoreCase).ToList();
        _modulesAt = DateTime.UtcNow;
        return _modules;
    }

    private static string LastError(string operation)
    {
        int code = Marshal.GetLastWin32Error();
        return code == 0 ? string.Empty : $"{operation} failed (Win32 error {code}).";
    }

    public void Dispose()
    {
        if (_handle != IntPtr.Zero) CloseHandle(_handle);
        _process.Dispose();
    }

    // ── Interop ───────────────────────────────────────────────────────────────
    [StructLayout(LayoutKind.Sequential)]
    private struct ProcessMemoryCountersEx
    {
        public uint cb;
        public uint PageFaultCount;
        public UIntPtr PeakWorkingSetSize;
        public UIntPtr WorkingSetSize;
        public UIntPtr QuotaPeakPagedPoolUsage;
        public UIntPtr QuotaPagedPoolUsage;
        public UIntPtr QuotaPeakNonPagedPoolUsage;
        public UIntPtr QuotaNonPagedPoolUsage;
        public UIntPtr PagefileUsage;
        public UIntPtr PeakPagefileUsage;
        public UIntPtr PrivateUsage;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct HeapList32
    {
        public UIntPtr dwSize;
        public uint th32ProcessID;
        public UIntPtr th32HeapId;
        public uint dwFlags;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct HeapEntry32
    {
        public UIntPtr dwSize;
        public IntPtr hHandle;
        public UIntPtr dwAddress;
        public UIntPtr dwBlockSize;
        public uint dwFlags;
        public uint dwLockCount;
        public uint dwReserved;
        public uint th32ProcessID;
        public UIntPtr th32HeapId;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct MemoryBasicInformation
    {
        public IntPtr BaseAddress;
        public IntPtr AllocationBase;
        public uint AllocationProtect;
        public uint Alignment1;
        public UIntPtr RegionSize;
        public uint State;
        public uint Protect;
        public uint Type;
        public uint Alignment2;
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr OpenProcess(uint access, bool inheritHandle, int processId);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool CloseHandle(IntPtr handle);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr CreateToolhelp32Snapshot(uint flags, uint processId);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool Heap32ListFirst(IntPtr snapshot, ref HeapList32 heapList);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool Heap32ListNext(IntPtr snapshot, ref HeapList32 heapList);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool Heap32First(ref HeapEntry32 entry, uint processId, UIntPtr heapId);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool Heap32Next(ref HeapEntry32 entry);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern UIntPtr VirtualQueryEx(IntPtr process, IntPtr address, out MemoryBasicInformation info, UIntPtr length);

    [DllImport("psapi.dll", SetLastError = true)]
    private static extern bool GetProcessMemoryInfo(IntPtr process, ref ProcessMemoryCountersEx counters, uint size);
}
