using System.Diagnostics;
using MemScope.Core.Models;

namespace MemScope.Core.Native;

/// <summary>Enumerates running processes for the live attach surface.</summary>
public static class ProcessCatalog
{
    public static IReadOnlyList<ProcessDescriptor> List()
    {
        var list = new List<ProcessDescriptor>();
        foreach (var process in Process.GetProcesses())
        {
            try
            {
                string? path = null;
                try { path = process.MainModule?.FileName; } catch { /* access denied */ }
                DateTime? started = null;
                try { started = process.StartTime; } catch { /* access denied */ }
                bool hasWindow = false;
                try { hasWindow = process.MainWindowHandle != IntPtr.Zero; } catch { /* ignore */ }

                list.Add(new ProcessDescriptor(
                    process.Id,
                    process.ProcessName,
                    path,
                    SafeRead(() => process.WorkingSet64),
                    SafeRead(() => process.PrivateMemorySize64),
                    SafeReadInt(() => process.Threads.Count),
                    hasWindow,
                    false,
                    started));
            }
            catch
            {
                // Target vanished or is protected — skip silently.
            }
            finally
            {
                process.Dispose();
            }
        }

        return list
            .OrderByDescending(p => p.HasWindow)
            .ThenByDescending(p => p.WorkingSetBytes)
            .ToList();
    }

    private static long SafeRead(Func<long> read)
    {
        try { return read(); } catch { return 0; }
    }

    private static int SafeReadInt(Func<int> read)
    {
        try { return read(); } catch { return 0; }
    }
}
