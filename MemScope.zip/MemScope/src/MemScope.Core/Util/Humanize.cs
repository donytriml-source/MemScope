namespace MemScope.Core.Util;

/// <summary>Human friendly formatting used across every MemScope surface.</summary>
public static class Humanize
{
    private static readonly string[] ByteUnits = { "B", "KB", "MB", "GB", "TB" };
    private static readonly string[] CountUnits = { "", "K", "M", "B", "T" };

    public static string Bytes(long value)
    {
        if (value < 0) return "-" + Bytes(-value);
        double v = value;
        int unit = 0;
        while (v >= 1024 && unit < ByteUnits.Length - 1)
        {
            v /= 1024;
            unit++;
        }
        return unit == 0 ? $"{value:N0} B" : $"{v:0.##} {ByteUnits[unit]}";
    }

    public static string BytesCompact(long value)
    {
        if (value < 0) return "-" + BytesCompact(-value);
        double v = value;
        int unit = 0;
        while (v >= 1024 && unit < ByteUnits.Length - 1)
        {
            v /= 1024;
            unit++;
        }
        return unit == 0 ? $"{value}B" : $"{v:0.#}{ByteUnits[unit]}";
    }

    public static string Count(long value)
    {
        if (value < 0) return "-" + Count(-value);
        if (value < 1000) return value.ToString("N0");
        double v = value;
        int unit = 0;
        while (v >= 1000 && unit < CountUnits.Length - 1)
        {
            v /= 1000;
            unit++;
        }
        return $"{v:0.#}{CountUnits[unit]}";
    }

    public static string Percent(double fraction, int decimals = 1)
    {
        if (double.IsNaN(fraction) || double.IsInfinity(fraction)) return "—";
        string pattern = decimals > 0 ? "0." + new string('#', Math.Clamp(decimals, 1, 6)) : "0";
        return (fraction * 100).ToString(pattern, System.Globalization.CultureInfo.InvariantCulture) + "%";
    }

    public static string PercentOf(long value, long total) => total <= 0 ? "0%" : Percent((double)value / total);

    public static string Duration(double milliseconds)
    {
        if (milliseconds < 1) return $"{milliseconds:0.##} ms";
        if (milliseconds < 1000) return $"{milliseconds:0.#} ms";
        if (milliseconds < 60_000) return $"{milliseconds / 1000:0.##} s";
        return $"{milliseconds / 60_000:0.##} min";
    }

    public static string Elapsed(TimeSpan span)
    {
        if (span.TotalSeconds < 60) return $"{span.TotalSeconds:0.0}s";
        if (span.TotalMinutes < 60) return $"{(int)span.TotalMinutes}m {span.Seconds:00}s";
        if (span.TotalHours < 24) return $"{(int)span.TotalHours}h {span.Minutes:00}m";
        return $"{(int)span.TotalDays}d {span.Hours:00}h";
    }

    public static string FileName(string? path)
    {
        if (string.IsNullOrWhiteSpace(path)) return "Unknown";
        int i = path.LastIndexOfAny(new[] { '\\', '/' });
        return i >= 0 && i + 1 < path.Length ? path[(i + 1)..] : path;
    }

    public static string Shorten(string? text, int maxChars)
    {
        if (string.IsNullOrEmpty(text) || text.Length <= maxChars) return text ?? string.Empty;
        return text[..Math.Max(0, maxChars - 1)] + "…";
    }

    public static string ShortPath(string? path, int maxChars = 64)
    {
        if (string.IsNullOrWhiteSpace(path)) return "Unknown";
        if (path.Length <= maxChars) return path;
        int keep = maxChars - 3;
        int slash = path.IndexOf('\\', path.Length - keep);
        return "…" + path[(slash >= 0 ? slash : path.Length - keep)..];
    }

    public static string Address(long address) => $"0x{address:X}";

    public static string SignedBytes(long delta) => delta switch
    {
        > 0 => "+" + Bytes(delta),
        < 0 => "-" + Bytes(-delta),
        _ => "0 B"
    };
}
