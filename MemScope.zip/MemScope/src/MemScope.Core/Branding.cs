namespace MemScope.Core;

/// <summary>
/// Product identity. MemScope is designed and engineered by MR8AD AL-Tmimi.
/// </summary>
public static class Branding
{
    public const string ProductName = "MemScope";
    public const string Wordmark = "MEMSCØPE";
    public const string Tagline = "Memory intelligence, engineered.";
    public const string Subtitle = "Precision heap & allocation intelligence for Windows processes";
    public const string Author = "MR8AD AL-Tmimi";
    public const string AuthorArabic = "مرقاد التميمي";
    public const string Copyright = "© 2026 MR8AD AL-Tmimi. All rights reserved.";
    public const string ShortCopyright = "© 2026 MR8AD AL-Tmimi";
    public const string License = "Proprietary — all rights reserved.";
    public const string Version = "1.0.0";
    public const string Codename = "Obsidian";
    public const string BuildChannel = "Release";
    public const string SessionExtension = ".msc";
    public const string SessionFormat = "MemScope.Capture";
    public const int SessionFormatVersion = 1;
    public const string ReportExtension = ".html";
    public const string GitHub = "https://github.com/MR8AD-AL-Tmimi/MemScope";

    public static string VersionLine => $"{ProductName} {Version} · {Codename} · {BuildChannel}";
    public static string FullCredit => $"{ProductName} {Version} — crafted by {Author}";
}
