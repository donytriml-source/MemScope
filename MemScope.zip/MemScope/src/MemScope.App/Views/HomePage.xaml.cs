using System.Windows.Controls;

namespace MemScope.App.Views;

public partial class HomePage : UserControl
{
    public HomePage()
    {
        InitializeComponent();
    }
}
