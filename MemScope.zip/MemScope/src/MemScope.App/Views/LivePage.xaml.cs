using System.Windows.Controls;

namespace MemScope.App.Views;

public partial class LivePage : UserControl
{
    public LivePage()
    {
        InitializeComponent();
    }
}
