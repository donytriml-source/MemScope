using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using MemScope.App.ViewModels;
using MemScope.Core.Analysis;

namespace MemScope.App.Views;

public partial class AnalysisPage : UserControl
{
    public AnalysisPage()
    {
        InitializeComponent();
    }

    private AnalysisViewModel? Vm => DataContext as AnalysisViewModel;

    private void Hotspots_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (HotspotsList.SelectedItem is not Hotspot hotspot) return;
        Vm?.SelectHotspotCommand.Execute(hotspot);
        HotspotsList.SelectedItem = null;
    }

    private void Treemap_TileActivated(object? sender, CallTreeNode node)
    {
        var vm = Vm;
        if (vm is null) return;
        vm.SelectedNode = node;
    }

    private void TreeList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
        if (e.OriginalSource is not DependencyObject source) return;
        var container = ItemsControl.ContainerFromElement((ItemsControl)sender, source) as ListBoxItem;
        if (container?.DataContext is CallTreeRow row)
            Vm?.ToggleRowCommand.Execute(row);
    }
}
