using System.Windows;

namespace MemScope.App.Views;

public partial class SplashWindow : Window
{
    public SplashWindow()
    {
        InitializeComponent();
    }

    public void SetStatus(string text, double progress)
    {
        StatusText.Text = text;
        Progress.Value = Math.Clamp(progress, 0, 1);
        ProgressText.Text = $"{Math.Clamp(progress, 0, 1) * 100:0}%";
    }
}
