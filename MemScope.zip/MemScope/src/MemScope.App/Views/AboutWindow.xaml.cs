using System.Diagnostics;
using System.Windows;
using System.Windows.Input;
using MemScope.Core;

namespace MemScope.App.Views;

public partial class AboutWindow : Window
{
    public AboutWindow()
    {
        InitializeComponent();
        AuthorArabicText.Text = Branding.AuthorArabic;
        PreviewKeyDown += (_, e) =>
        {
            if (e.Key == Key.Escape) Close();
        };
    }

    private void Close_Click(object sender, RoutedEventArgs e) => Close();

    private void Project_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            Process.Start(new ProcessStartInfo(Branding.GitHub) { UseShellExecute = true });
        }
        catch
        {
            // A missing browser must not break the dialog.
        }
    }

    private void Root_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ButtonState == MouseButtonState.Pressed)
        {
            try { DragMove(); } catch { /* ignore */ }
        }
    }
}
