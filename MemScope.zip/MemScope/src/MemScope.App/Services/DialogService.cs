using System.Diagnostics;
using System.Globalization;
using MemScope.App.ViewModels;

namespace MemScope.App.Services;

public interface IDialogService
{
    string? OpenFile(string title, string filter);
    string? SaveFile(string title, string filter, string defaultFileName);
    void ShowMessage(string title, string message);
    void OpenInShell(string path);
}

public sealed class DialogService : IDialogService
{
    public string? OpenFile(string title, string filter)
    {
        var dialog = new Microsoft.Win32.OpenFileDialog
        {
            Title = title,
            Filter = filter,
            CheckFileExists = true,
            Multiselect = false
        };
        return dialog.ShowDialog() == true ? dialog.FileName : null;
    }

    public string? SaveFile(string title, string filter, string defaultFileName)
    {
        var dialog = new Microsoft.Win32.SaveFileDialog
        {
            Title = title,
            Filter = filter,
            FileName = defaultFileName,
            AddExtension = true,
            OverwritePrompt = true
        };
        return dialog.ShowDialog() == true ? dialog.FileName : null;
    }

    public void ShowMessage(string title, string message) =>
        System.Windows.MessageBox.Show(message, title, System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);

    public void OpenInShell(string path)
    {
        try
        {
            Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{path}\"") { UseShellExecute = true });
        }
        catch
        {
            try { Process.Start(new ProcessStartInfo(path) { UseShellExecute = true }); } catch { /* ignore */ }
        }
    }
}

public sealed class ToastService
{
    public event Action<ToastMessage>? Raised;

    public void Show(string title, string message, ToastKind kind = ToastKind.Info) =>
        Raised?.Invoke(new ToastMessage(title, message, kind));

    public void Success(string title, string message) => Show(title, message, ToastKind.Success);
    public void Warn(string title, string message) => Show(title, message, ToastKind.Warning);
    public void Error(string title, string message) => Show(title, message, ToastKind.Error);
}

public static class Locale
{
    public static string N(long value) => value.ToString("N0", CultureInfo.InvariantCulture);
    public static string B(long value) => MemScope.Core.Util.Humanize.Bytes(value);
    public static string P(double value) => value.ToString("0.#", CultureInfo.InvariantCulture) + "%";
}
