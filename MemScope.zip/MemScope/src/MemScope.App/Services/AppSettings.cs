using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace MemScope.App.Services;

public sealed class AppSettings
{
    public string Accent { get; set; } = "Brass";
    public string LastPage { get; set; } = "Home";
    public List<string> RecentCaptures { get; set; } = new();
    public string? LastCapturePath { get; set; }
    public double WindowWidth { get; set; } = 1440;
    public double WindowHeight { get; set; } = 900;
    public double WindowLeft { get; set; } = double.NaN;
    public double WindowTop { get; set; } = double.NaN;
    public bool WindowMaximized { get; set; }
    public bool ShowSplash { get; set; } = true;
    public int SamplingIntervalMs { get; set; } = 300;
    public bool DeepSampling { get; set; } = true;
}

public static class SettingsStore
{
    private static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = true,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };

    public static string DirectoryPath { get; } =
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "MemScope");

    public static string FilePath { get; } = Path.Combine(DirectoryPath, "settings.json");

    public static AppSettings Load()
    {
        try
        {
            if (File.Exists(FilePath))
            {
                var settings = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(FilePath), Options);
                if (settings is not null) return settings;
            }
        }
        catch
        {
            // Corrupt settings should never block the application.
        }
        return new AppSettings();
    }

    public static void Save(AppSettings settings)
    {
        // Screenshot/preview runs must never rewrite the user's saved workspace.
        if (MemScope.App.App.CaptureMode) return;
        try
        {
            Directory.CreateDirectory(DirectoryPath);
            File.WriteAllText(FilePath, JsonSerializer.Serialize(settings, Options));
        }
        catch
        {
            // Persistence is best effort.
        }
    }
}
