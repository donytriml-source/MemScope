using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using MemScope.Core.Util;

namespace MemScope.App.Services;

/// <summary>Accent presets. The palette is applied at runtime through dynamic resources.</summary>
public static class AccentManager
{
    public sealed record Accent(string Name, string Label, Color Primary, Color Light, Color Deep);

    public static IReadOnlyList<Accent> Presets { get; } = new[]
    {
        new Accent("Brass", "Obsidian brass", Color.FromRgb(0xE3, 0xB6, 0x67), Color.FromRgb(0xF8, 0xE0, 0xA6), Color.FromRgb(0x9A, 0x6A, 0x22)),
        new Accent("Emerald", "Emerald ink", Color.FromRgb(0x4B, 0xD6, 0xA0), Color.FromRgb(0xB9, 0xF7, 0xDE), Color.FromRgb(0x1E, 0x7A, 0x57)),
        new Accent("Violet", "Iris", Color.FromRgb(0xA9, 0x98, 0xFF), Color.FromRgb(0xDE, 0xD8, 0xFF), Color.FromRgb(0x5C, 0x4B, 0xC4)),
        new Accent("Cyan", "Glacier", Color.FromRgb(0x5F, 0xD4, 0xFF), Color.FromRgb(0xC9, 0xF2, 0xFF), Color.FromRgb(0x1C, 0x6C, 0x8C)),
        new Accent("Rose", "Ember", Color.FromRgb(0xFF, 0x8F, 0x9C), Color.FromRgb(0xFF, 0xD6, 0xDB), Color.FromRgb(0xA6, 0x3B, 0x48))
    };

    public static string Current { get; private set; } = "Brass";

    public static Accent Get(string? name) =>
        Presets.FirstOrDefault(p => string.Equals(p.Name, name, StringComparison.OrdinalIgnoreCase)) ?? Presets[0];

    public static void Apply(string? name)
    {
        var accent = Get(name);
        Current = accent.Name;
        var resources = Application.Current?.Resources;
        if (resources is null) return;

        resources["AccentColor"] = accent.Primary;
        resources["AccentLightColor"] = accent.Light;
        resources["AccentDeepColor"] = accent.Deep;
        resources["AccentBrush"] = Freeze(new SolidColorBrush(accent.Primary));
        resources["AccentLightBrush"] = Freeze(new SolidColorBrush(accent.Light));
        resources["AccentDeepBrush"] = Freeze(new SolidColorBrush(accent.Deep));
        resources["AccentSoftBrush"] = Freeze(new SolidColorBrush(WithAlpha(accent.Primary, 0x26)));
        resources["AccentGhostBrush"] = Freeze(new SolidColorBrush(WithAlpha(accent.Primary, 0x12)));
        resources["AccentGlowBrush"] = Freeze(new SolidColorBrush(WithAlpha(accent.Primary, 0x55)));
        resources["AccentGradient"] = Freeze(new LinearGradientBrush(accent.Light, accent.Deep, new Point(0, 0), new Point(1, 1)));
        resources["AccentGradientHorizontal"] = Freeze(new LinearGradientBrush(accent.Deep, accent.Primary, new Point(0, 0), new Point(1, 0)));

        var bar = new LinearGradientBrush { StartPoint = new Point(0, 0), EndPoint = new Point(1, 0) };
        bar.GradientStops.Add(new GradientStop(accent.Deep, 0));
        bar.GradientStops.Add(new GradientStop(accent.Primary, 0.65));
        bar.GradientStops.Add(new GradientStop(accent.Light, 1));
        resources["BarGradientBrush"] = Freeze(bar);

        var row = new LinearGradientBrush { StartPoint = new Point(0, 0), EndPoint = new Point(1, 0) };
        row.GradientStops.Add(new GradientStop(WithAlpha(accent.Primary, 0x2E), 0));
        row.GradientStops.Add(new GradientStop(WithAlpha(accent.Primary, 0x0C), 1));
        resources["RowSelectionBrush"] = Freeze(row);

        var hero = new RadialGradientBrush
        {
            Center = new Point(0.18, 0.15),
            GradientOrigin = new Point(0.18, 0.15),
            RadiusX = 0.85,
            RadiusY = 1.1
        };
        hero.GradientStops.Add(new GradientStop(WithAlpha(accent.Primary, 0x4D), 0));
        hero.GradientStops.Add(new GradientStop(WithAlpha(accent.Primary, 0x14), 0.45));
        hero.GradientStops.Add(new GradientStop(WithAlpha(accent.Primary, 0x00), 1));
        resources["HeroGlowBrush"] = Freeze(hero);

        var glow = new System.Windows.Media.Effects.DropShadowEffect
        {
            BlurRadius = 26,
            ShadowDepth = 0,
            Opacity = 0.4,
            Direction = 270,
            Color = accent.Primary
        };
        glow.Freeze();
        resources["AccentGlow"] = glow;
    }

    public static Color WithAlpha(Color color, byte alpha) => Color.FromArgb(alpha, color.R, color.G, color.B);

    private static T Freeze<T>(T freezable) where T : Freezable
    {
        freezable.Freeze();
        return freezable;
    }
}

public sealed class BytesConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        value switch
        {
            long l => Humanize.Bytes(l),
            int i => Humanize.Bytes(i),
            double d => Humanize.Bytes((long)d),
            _ => "—"
        };

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

public sealed class BytesCompactConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        value is long l ? Humanize.BytesCompact(l) : value is int i ? Humanize.BytesCompact(i) : "—";

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

public sealed class CountConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        value is long l ? l.ToString("N0") : value is int i ? i.ToString("N0") : "—";

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

public sealed class CompactCountConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        value is long l ? Humanize.Count(l) : value is int i ? Humanize.Count(i) : "—";

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

public sealed class PercentConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        double fraction = value switch
        {
            double d => d,
            float f => f,
            decimal m => (double)m,
            long l => l,
            int i => i,
            _ => 0
        };
        int decimals = 1;
        if (parameter is string s && int.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out var parsed)) decimals = parsed;
        string pattern = decimals > 0 ? "0." + new string('#', decimals) : "0";
        return (fraction * 100).ToString(pattern, culture) + "%";
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

public sealed class BoolVisibilityConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        bool flag = value is true;
        if (parameter is string text && text.Equals("invert", StringComparison.OrdinalIgnoreCase)) flag = !flag;
        return flag ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

public sealed class NullVisibilityConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        bool visible = value is not null;
        if (parameter is string text && text.Equals("invert", StringComparison.OrdinalIgnoreCase)) visible = !visible;
        return visible ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

public sealed class StringVisibilityConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        bool hasText = value is string s && !string.IsNullOrWhiteSpace(s);
        if (parameter is string text && text.Equals("invert", StringComparison.OrdinalIgnoreCase)) hasText = !hasText;
        return hasText ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

public sealed class InverseBoolConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture) => value is not true;
    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) => value is not true;
}

/// <summary>Shows a placeholder when a bound collection (or count) is empty.</summary>
public sealed class EmptyVisibilityConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        bool empty = value switch
        {
            null => true,
            int i => i == 0,
            long l => l == 0,
            System.Collections.ICollection collection => collection.Count == 0,
            _ => false
        };
        if (parameter is string text && text.Equals("invert", StringComparison.OrdinalIgnoreCase)) empty = !empty;
        return empty ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

public sealed class MultiplyConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        double number = value is double d ? d : value is int i ? i : 0;
        double factor = 1;
        if (parameter is string s && double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out var parsed)) factor = parsed;
        return number * factor;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

public sealed class DeltaBrushConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        double delta = value switch
        {
            long l => l,
            int i => i,
            double d => d,
            _ => 0
        };
        return delta switch
        {
            > 0 => new SolidColorBrush(Color.FromRgb(0xFF, 0x7D, 0x8A)),
            < 0 => new SolidColorBrush(Color.FromRgb(0x4B, 0xD6, 0xA0)),
            _ => new SolidColorBrush(Color.FromRgb(0x8C, 0x96, 0xAC))
        };
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

public sealed class SeverityBrushConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        string key = value?.ToString() switch
        {
            "Critical" => "Rose",
            "Warning" or "Likely" => "Brass",
            "Positive" => "Emerald",
            _ => "Cyan"
        };
        if (Application.Current?.Resources[key + "Brush"] is Brush brush) return brush;
        return Brushes.Gray;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

public sealed class ModuleBrushConverter : IValueConverter
{
    private static readonly Color[] Palette =
    {
        Color.FromRgb(0xE3, 0xB6, 0x67), Color.FromRgb(0x5F, 0xD4, 0xFF), Color.FromRgb(0x4B, 0xD6, 0xA0),
        Color.FromRgb(0xA9, 0x98, 0xFF), Color.FromRgb(0xFF, 0x8F, 0x9C), Color.FromRgb(0x7F, 0xB8, 0xFF),
        Color.FromRgb(0xFF, 0xC4, 0x7A), Color.FromRgb(0x6F, 0xE3, 0xCE)
    };

    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        string text = value?.ToString() ?? string.Empty;
        int hash = 17;
        foreach (char c in text) hash = unchecked(hash * 31 + c);
        var color = Palette[Math.Abs(hash) % Palette.Length];
        return new SolidColorBrush(color);
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

public sealed class ColorBrushConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        var color = value switch
        {
            Color c => c,
            string s when ColorConverter.ConvertFromString(s) is Color parsed => parsed,
            _ => Colors.Gray
        };
        var brush = new SolidColorBrush(color);
        brush.Freeze();
        return brush;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}

public sealed class InitialConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        string text = value?.ToString() ?? string.Empty;
        return string.IsNullOrWhiteSpace(text) ? "•" : char.ToUpperInvariant(text[0]).ToString();
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}
