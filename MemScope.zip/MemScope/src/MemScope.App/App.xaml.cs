using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using MemScope.App.Services;
using MemScope.App.ViewModels;
using MemScope.App.Views;
using MemScope.Core;

namespace MemScope.App;

/// <summary>
/// MemScope application host. Applies the identity palette, restores the last capture
/// and hands control to the shell. Designed and engineered by MR8AD AL-Tmimi.
/// </summary>
public partial class App : Application
{
    private AppSettings _settings = new();
    private MainViewModel? _viewModel;
    private SplashWindow? _splash;

    /// <summary>True while the app is rendering a screenshot for documentation.</summary>
    public static bool CaptureMode { get; private set; }

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        DispatcherUnhandledException += OnDispatcherUnhandledException;
        AppDomain.CurrentDomain.UnhandledException += (_, args) =>
        {
            if (args.ExceptionObject is Exception ex) ShowFatal(ex);
        };

        _settings = SettingsStore.Load();
        AccentManager.Apply(_settings.Accent);
        CaptureMode = e.Args.Any(a => a.Equals("--shot", StringComparison.OrdinalIgnoreCase));

        var toasts = new ToastService();
        var dialogs = new DialogService();
        _viewModel = new MainViewModel(dialogs, toasts, _settings);

        bool noSplash = !_settings.ShowSplash || e.Args.Any(a => a.Equals("--no-splash", StringComparison.OrdinalIgnoreCase));
        if (noSplash)
        {
            Dispatcher.InvokeAsync(async () =>
            {
                try
                {
                    await _viewModel.InitializeAsync();
                }
                catch
                {
                    // Boot must never be held hostage by a slow capture.
                }
                Boot(e.Args);
            });
            return;
        }

        _splash = new SplashWindow();
        _splash.Show();
        Dispatcher.InvokeAsync(async () =>
        {
            try
            {
                _splash.SetStatus("Waking the capture engine", 0.18);
                await Task.Delay(280);
                _splash.SetStatus("Restoring your workspace", 0.42);
                await _viewModel.InitializeAsync();
                _splash.SetStatus("Engraving the interface", 0.78);
                await Task.Delay(320);
                _splash.SetStatus("Ready", 1.0);
                await Task.Delay(200);
            }
            catch
            {
                // Boot must never be held hostage by a slow capture.
            }
            Boot(e.Args);
            _splash.Close();
            _splash = null;
        });
    }

    private void Boot(string[] args)
    {
        if (_viewModel is null) return;

        if (TryArg(args, "--page", out var page))
        {
            _viewModel.SelectedNavIndex = page.ToLowerInvariant() switch
            {
                "live" => 1,
                "analysis" or "analyse" => 2,
                _ => 0
            };
        }

        if (TryArg(args, "--tab", out var tabText) && int.TryParse(tabText, out var tab))
            _viewModel.Analysis.SelectedTab = Math.Clamp(tab, 0, 4);

        if (TryArg(args, "--accent", out var accentName))
            _viewModel.PreviewAccent(accentName);

        var window = new MainWindow(_viewModel);
        MainWindow = window;
        window.Show();

        // Screenshot runs render the maximized shell and never touch the user's window settings.
        bool captureMode = TryArg(args, "--shot", out var shotPath);
        if (captureMode) window.WindowState = WindowState.Maximized;

        if (TryArg(args, "--attach", out var attachName))
        {
            _viewModel.SelectedNavIndex = 1;
            _ = _viewModel.Live.AttachToAsync(attachName);
        }

        if (args.Any(a => a.Equals("--compare", StringComparison.OrdinalIgnoreCase))
            && _viewModel.Analysis.DemoBaseline is { } demoBaseline)
        {
            _viewModel.SelectedNavIndex = 2;
            _viewModel.Analysis.UseDemoBaseline(demoBaseline);
        }

        Window captureTarget = window;
        if (TryArg(args, "--show", out var showName))
        {
            Window? extra = showName.ToLowerInvariant() switch
            {
                "about" => new AboutWindow(),
                "splash" => new SplashWindow(),
                _ => null
            };
            if (extra is not null)
            {
                if (extra is AboutWindow) extra.DataContext = _viewModel;
                extra.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                extra.Show();
                captureTarget = extra;
            }
        }

        if (captureMode)
            _ = CaptureAndExitAsync(captureTarget, shotPath, TryArg(args, "--shot-delay", out var delayText) && int.TryParse(delayText, out var delay) ? delay : 1400);
    }

    private static bool TryArg(string[] args, string name, out string value)
    {
        for (int i = 0; i < args.Length - 1; i++)
        {
            if (args[i].Equals(name, StringComparison.OrdinalIgnoreCase))
            {
                value = args[i + 1];
                return true;
            }
        }
        value = string.Empty;
        return false;
    }

    private async Task CaptureAndExitAsync(Window window, string path, int delayMs)
    {
        try
        {
            await Task.Delay(Math.Max(200, delayMs));
            await Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ApplicationIdle);
            await Task.Delay(400);

            var dpi = VisualTreeHelper.GetDpi(window);
            int width = (int)Math.Max(1, window.ActualWidth);
            int height = (int)Math.Max(1, window.ActualHeight);
            var bitmap = new RenderTargetBitmap(
                (int)(width * dpi.DpiScaleX),
                (int)(height * dpi.DpiScaleY),
                96 * dpi.DpiScaleX,
                96 * dpi.DpiScaleY,
                PixelFormats.Pbgra32);
            bitmap.Render(window);

            var encoder = new PngBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(bitmap));
            string? directory = Path.GetDirectoryName(Path.GetFullPath(path));
            if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);
            using (var stream = File.Create(path)) encoder.Save(stream);
        }
        catch
        {
            // Screenshot mode is a developer convenience only.
        }
        finally
        {
            Shutdown();
        }
    }

    private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        e.Handled = true;
        ShowFatal(e.Exception);
    }

    private void ShowFatal(Exception ex)
    {
        try
        {
            if (MainWindow?.DataContext is MainViewModel vm)
            {
                vm.RaiseExternalToast("Unexpected fault", ex.Message, ToastKind.Error);
                return;
            }
            MessageBox.Show($"{ex.Message}\n\nMemScope {Branding.Version} · {Branding.ShortCopyright}",
                "MemScope", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        catch
        {
            // Nothing sensible left to do.
        }
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _viewModel?.Dispose();
        base.OnExit(e);
    }
}
