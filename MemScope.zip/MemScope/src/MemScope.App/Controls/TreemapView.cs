using System.Globalization;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using MemScope.Core.Analysis;
using MemScope.Core.Util;

namespace MemScope.App.Controls;

/// <summary>
/// Renders a squarified heap treemap. Tiles are painted straight onto the drawing
/// context so the surface stays smooth even with hundreds of rectangles.
/// </summary>
public sealed class TreemapView : FrameworkElement
{
    public static readonly DependencyProperty RootProperty = DependencyProperty.Register(
        nameof(Root), typeof(CallTreeNode), typeof(TreemapView),
        new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender, OnLayoutInvalidated));

    public static readonly DependencyProperty SelectedNodeProperty = DependencyProperty.Register(
        nameof(SelectedNode), typeof(CallTreeNode), typeof(TreemapView),
        new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender, OnLayoutInvalidated));

    public static readonly DependencyProperty AccentBrushProperty = DependencyProperty.Register(
        nameof(AccentBrush), typeof(Brush), typeof(TreemapView),
        new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender));

    private static readonly Color[] ModulePalette =
    {
        Color.FromRgb(0xE3, 0xB6, 0x67), Color.FromRgb(0x5F, 0xD4, 0xFF), Color.FromRgb(0x4B, 0xD6, 0xA0),
        Color.FromRgb(0xA9, 0x98, 0xFF), Color.FromRgb(0xFF, 0x8F, 0x9C), Color.FromRgb(0x7F, 0xB8, 0xFF),
        Color.FromRgb(0xFF, 0xC4, 0x7A), Color.FromRgb(0x6F, 0xE3, 0xCE)
    };

    private IReadOnlyList<TreemapTile> _tiles = Array.Empty<TreemapTile>();
    private TreemapTile? _hover;
    private Size _laidOutFor;
    private CallTreeNode? _builtFor;

    public TreemapView()
    {
        SnapsToDevicePixels = true;
        ClipToBounds = true;
        Cursor = Cursors.Arrow;
    }

    public CallTreeNode? Root
    {
        get => (CallTreeNode?)GetValue(RootProperty);
        set => SetValue(RootProperty, value);
    }

    public CallTreeNode? SelectedNode
    {
        get => (CallTreeNode?)GetValue(SelectedNodeProperty);
        set => SetValue(SelectedNodeProperty, value);
    }

    public Brush? AccentBrush
    {
        get => (Brush?)GetValue(AccentBrushProperty);
        set => SetValue(AccentBrushProperty, value);
    }

    public event EventHandler<CallTreeNode>? TileActivated;

    private static void OnLayoutInvalidated(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        var view = (TreemapView)d;
        view._builtFor = null;
        view._tiles = Array.Empty<TreemapTile>();
        view.InvalidateVisual();
    }

    private void EnsureTiles(Size size)
    {
        if (Root is null || size.Width < 8 || size.Height < 8)
        {
            _tiles = Array.Empty<TreemapTile>();
            return;
        }

        if (ReferenceEquals(_builtFor, Root) && Math.Abs(_laidOutFor.Width - size.Width) < 0.6 && Math.Abs(_laidOutFor.Height - size.Height) < 0.6)
            return;

        _builtFor = Root;
        _laidOutFor = size;
        _tiles = TreemapLayout.Build(Root, size.Width, size.Height, maxDepth: 4, padding: 2.0, maxChildren: 26, minAreaPixels: 6);
    }

    protected override void OnRender(DrawingContext dc)
    {
        var size = RenderSize;
        dc.DrawRectangle(new SolidColorBrush(Color.FromRgb(0x08, 0x0A, 0x0F)), null, new Rect(size));

        EnsureTiles(size);
        if (_tiles.Count == 0)
        {
            var pixelsPerDip = VisualTreeHelper.GetDpi(this).PixelsPerDip;
            var message = new FormattedText(
                Root is null ? "Load a capture to explore its heap." : "This capture has no live heap to lay out.",
                CultureInfo.CurrentUICulture, FlowDirection.LeftToRight,
                new Typeface(new FontFamily("Segoe UI Variable Text, Segoe UI"), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal),
                12, new SolidColorBrush(Color.FromRgb(0x6A, 0x74, 0x8C)), pixelsPerDip);
            dc.DrawText(message, new Point(Math.Max(12, (size.Width - message.Width) / 2), Math.Max(12, (size.Height - message.Height) / 2)));
            return;
        }

        var accent = AccentBrush ?? (Application.Current?.TryFindResource("AccentBrush") as Brush) ?? new SolidColorBrush(Color.FromRgb(0xE3, 0xB6, 0x67));
        var labelBrush = new SolidColorBrush(Color.FromRgb(0xF2, 0xF5, 0xFB));
        var dimBrush = new SolidColorBrush(Color.FromRgb(0xDD, 0xE4, 0xF2));
        var borderPen = new Pen(new SolidColorBrush(Color.FromRgb(0x07, 0x08, 0x0C)), 1.6);
        var accentPen = new Pen(accent, 1.8);
        var dpi = VisualTreeHelper.GetDpi(this).PixelsPerDip;
        var typeface = new Typeface(new FontFamily("Segoe UI Variable Text, Segoe UI"), FontStyles.Normal, FontWeights.SemiBold, FontStretches.Normal);
        var byteTypeface = new Typeface(new FontFamily("Cascadia Mono, Consolas, Segoe UI"), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);

        foreach (var tile in _tiles)
        {
            var rect = new Rect(tile.X, tile.Y, Math.Max(0, tile.Width), Math.Max(0, tile.Height));
            if (rect.Width < 1 || rect.Height < 1) continue;

            bool hovered = ReferenceEquals(tile, _hover);
            bool selected = SelectedNode is not null && ReferenceEquals(tile.Node, SelectedNode);
            Color baseColor = ModulePalette[Math.Abs(Hash(tile.Module)) % ModulePalette.Length];
            double darken = tile.Depth switch { 0 => 0.42, 1 => 0.58, 2 => 0.68, _ => 0.74 };
            Color fill = Mix(baseColor, Color.FromRgb(0x0C, 0x0F, 0x16), darken);
            if (hovered) fill = Mix(fill, Colors.White, 0.12);
            var brush = new SolidColorBrush(fill);
            brush.Freeze();

            dc.DrawRectangle(brush, borderPen, rect);

            if (selected)
            {
                dc.DrawRectangle(null, accentPen, Rect.Inflate(rect, -1, -1));
            }
            else if (tile.Depth == 0)
            {
                dc.DrawRectangle(accent, null, new Rect(rect.X, rect.Y, rect.Width, 1.6));
            }

            if (rect.Width < 62 || rect.Height < 24) continue;

            dc.PushClip(new RectangleGeometry(Rect.Inflate(rect, -2, -2)));
            double textWidth = Math.Max(10, rect.Width - 14);
            var title = new FormattedText(
                Trim(tile.Label, rect.Width, 13),
                CultureInfo.CurrentUICulture, FlowDirection.LeftToRight, typeface, 11, selected ? labelBrush : dimBrush, dpi)
            {
                MaxTextWidth = textWidth,
                MaxTextHeight = 17,
                Trimming = TextTrimming.CharacterEllipsis
            };
            dc.DrawText(title, new Point(rect.X + 7, rect.Y + 6));

            if (rect.Height >= 42)
            {
                var bytes = new FormattedText(
                    Humanize.BytesCompact(tile.Bytes),
                    CultureInfo.CurrentUICulture, FlowDirection.LeftToRight, byteTypeface, 9.5,
                    new SolidColorBrush(Color.FromRgb(0xB8, 0xC3, 0xD8)), dpi)
                {
                    MaxTextWidth = textWidth,
                    MaxTextHeight = 14,
                    Trimming = TextTrimming.CharacterEllipsis
                };
                dc.DrawText(bytes, new Point(rect.X + 7, rect.Y + 25));
            }
            dc.Pop();
        }
    }

    private static string Trim(string text, double width, double fontSize)
    {
        int max = Math.Max(3, (int)(width / (fontSize * 0.56)));
        return text.Length <= max ? text : text[..Math.Max(1, max - 1)] + "…";
    }

    private static int Hash(string? value)
    {
        int hash = 17;
        foreach (char c in value ?? string.Empty) hash = unchecked(hash * 31 + c);
        return hash;
    }

    private static Color Mix(Color a, Color b, double t)
    {
        t = Math.Clamp(t, 0, 1);
        return Color.FromRgb(
            (byte)(a.R + (b.R - a.R) * t),
            (byte)(a.G + (b.G - a.G) * t),
            (byte)(a.B + (b.B - a.B) * t));
    }

    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo)
    {
        base.OnRenderSizeChanged(sizeInfo);
        _builtFor = null;
        _tiles = Array.Empty<TreemapTile>();
    }

    private TreemapTile? HitTest(Point point)
    {
        for (int i = _tiles.Count - 1; i >= 0; i--)
        {
            var tile = _tiles[i];
            if (tile.Contains(point.X, point.Y)) return tile;
        }
        return null;
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        var tile = HitTest(e.GetPosition(this));
        if (!ReferenceEquals(tile, _hover))
        {
            _hover = tile;
            Cursor = tile is null ? Cursors.Arrow : Cursors.Hand;
            InvalidateVisual();
        }

        if (tile is null)
        {
            ToolTip = null;
            return;
        }

        string share = Root is not null && Root.Usage > 0 ? Humanize.PercentOf(tile.Bytes, Root.Usage) : "—";
        ToolTip = $"{tile.Label}\n{tile.Path}\n{Humanize.Bytes(tile.Bytes)} live · {share} of heap\n{tile.Module}";
    }

    protected override void OnMouseLeave(MouseEventArgs e)
    {
        base.OnMouseLeave(e);
        if (_hover is not null)
        {
            _hover = null;
            Cursor = Cursors.Arrow;
            InvalidateVisual();
        }
        ToolTip = null;
    }

    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e)
    {
        base.OnMouseLeftButtonUp(e);
        var tile = HitTest(e.GetPosition(this));
        if (tile?.Node is null) return;
        SelectedNode = tile.Node;
        TileActivated?.Invoke(this, tile.Node);
        InvalidateVisual();
    }
}
