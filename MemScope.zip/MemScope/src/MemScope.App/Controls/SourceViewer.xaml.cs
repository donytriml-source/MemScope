using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace MemScope.App.Controls;

public partial class SourceViewer : UserControl
{
    public static readonly DependencyProperty SourceTextProperty = DependencyProperty.Register(
        nameof(SourceText), typeof(string), typeof(SourceViewer),
        new PropertyMetadata(string.Empty, OnSourceChanged));

    public static readonly DependencyProperty FileNameProperty = DependencyProperty.Register(
        nameof(FileName), typeof(string), typeof(SourceViewer),
        new PropertyMetadata(string.Empty, OnHeaderChanged));

    public static readonly DependencyProperty HighlightLineProperty = DependencyProperty.Register(
        nameof(HighlightLine), typeof(int), typeof(SourceViewer),
        new PropertyMetadata(0, OnHeaderChanged));

    public static readonly DependencyProperty MissingMessageProperty = DependencyProperty.Register(
        nameof(MissingMessage), typeof(string), typeof(SourceViewer),
        new PropertyMetadata("No source on disk for this frame. Build with symbols or attach to a process with PDBs."));

    private List<SourceLine> _lines = new();

    public SourceViewer()
    {
        InitializeComponent();
        UpdateView();
    }

    public string SourceText { get => (string)GetValue(SourceTextProperty); set => SetValue(SourceTextProperty, value); }
    public string FileName { get => (string)GetValue(FileNameProperty); set => SetValue(FileNameProperty, value); }
    public int HighlightLine { get => (int)GetValue(HighlightLineProperty); set => SetValue(HighlightLineProperty, value); }
    public string MissingMessage { get => (string)GetValue(MissingMessageProperty); set => SetValue(MissingMessageProperty, value); }

    private static void OnSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) =>
        ((SourceViewer)d).UpdateView();

    private static void OnHeaderChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        var viewer = (SourceViewer)d;
        viewer.UpdateHeaders();
        viewer.ScrollToHighlight();
    }

    private void UpdateView()
    {
        string text = SourceText ?? string.Empty;
        var lines = new List<SourceLine>();
        if (!string.IsNullOrEmpty(text))
        {
            var split = text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            for (int i = 0; i < split.Length; i++)
            {
                string raw = split[i];
                string trimmed = raw.TrimStart();
                bool comment = trimmed.StartsWith("//", StringComparison.Ordinal)
                               || trimmed.StartsWith("/*", StringComparison.Ordinal)
                               || trimmed.StartsWith("*", StringComparison.Ordinal)
                               || trimmed.StartsWith("#", StringComparison.Ordinal);
                lines.Add(new SourceLine(i + 1, raw, i + 1 == HighlightLine, comment));
            }
        }

        _lines = lines;
        LinesList.ItemsSource = _lines;
        LinesList.Visibility = lines.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
        EmptyText.Text = MissingMessage;
        EmptyText.Visibility = lines.Count > 0 ? Visibility.Collapsed : Visibility.Visible;
        UpdateHeaders();
        ScrollToHighlight();
    }

    private void UpdateHeaders()
    {
        FileNameText.Text = string.IsNullOrWhiteSpace(FileName) ? "reconstructed source" : FileName;
        LineText.Text = HighlightLine > 0 && _lines.Count > 0 ? $"line {HighlightLine} / {_lines.Count}" : $"{_lines.Count} lines";
    }

    private void ScrollToHighlight()
    {
        if (HighlightLine <= 0 || _lines.Count == 0) return;
        var target = _lines.FirstOrDefault(l => l.IsHighlight);
        if (target is null) return;
        Dispatcher.BeginInvoke(DispatcherPriority.Loaded, new Action(() =>
        {
            int index = _lines.IndexOf(target);
            if (index >= 0) LinesList.ScrollIntoView(_lines[index]);
            if (index > 4)
            {
                var container = LinesList.ItemContainerGenerator.ContainerFromIndex(Math.Max(0, index - 3)) as ListBoxItem;
                container?.BringIntoView();
            }
        }));
    }

    public sealed record SourceLine(int Number, string Text, bool IsHighlight, bool IsComment);
}
