using System.Globalization;
using System.Windows;
using System.Windows.Media;
using MemScope.Core.Analysis;
using MemScope.Core.Models;
using MemScope.Core.Util;

namespace MemScope.App.Controls;

/// <summary>Thin metric bar used behind call-tree rows and inside cards.</summary>
public sealed class ProportionBar : FrameworkElement
{
    public static readonly DependencyProperty ValueProperty = DependencyProperty.Register(
        nameof(Value), typeof(double), typeof(ProportionBar),
        new FrameworkPropertyMetadata(0.0, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty FillProperty = DependencyProperty.Register(
        nameof(Fill), typeof(Brush), typeof(ProportionBar),
        new FrameworkPropertyMetadata(Brushes.Goldenrod, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty TrackProperty = DependencyProperty.Register(
        nameof(Track), typeof(Brush), typeof(ProportionBar),
        new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty RadiusProperty = DependencyProperty.Register(
        nameof(Radius), typeof(double), typeof(ProportionBar),
        new FrameworkPropertyMetadata(3.0, FrameworkPropertyMetadataOptions.AffectsRender));

    public double Value { get => (double)GetValue(ValueProperty); set => SetValue(ValueProperty, value); }
    public Brush Fill { get => (Brush)GetValue(FillProperty); set => SetValue(FillProperty, value); }
    public Brush? Track { get => (Brush?)GetValue(TrackProperty); set => SetValue(TrackProperty, value); }
    public double Radius { get => (double)GetValue(RadiusProperty); set => SetValue(RadiusProperty, value); }

    protected override void OnRender(DrawingContext dc)
    {
        double width = ActualWidth, height = ActualHeight;
        if (width <= 0 || height <= 0) return;

        if (Track is not null)
            dc.DrawRoundedRectangle(Track, null, new Rect(0, 0, width, height), Radius, Radius);

        double ratio = Math.Clamp(Value, 0, 1);
        if (ratio <= 0) return;
        double barWidth = Math.Max(height, width * ratio);
        dc.DrawRoundedRectangle(Fill, null, new Rect(0, 0, Math.Min(width, barWidth), height), Radius, Radius);
    }
}

/// <summary>Compact trend line for metric cards.</summary>
public sealed class Sparkline : FrameworkElement
{
    public static readonly DependencyProperty ValuesProperty = DependencyProperty.Register(
        nameof(Values), typeof(IReadOnlyList<double>), typeof(Sparkline),
        new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty StrokeProperty = DependencyProperty.Register(
        nameof(Stroke), typeof(Brush), typeof(Sparkline),
        new FrameworkPropertyMetadata(Brushes.Goldenrod, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty FillProperty = DependencyProperty.Register(
        nameof(Fill), typeof(Brush), typeof(Sparkline),
        new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender));

    public IReadOnlyList<double>? Values { get => (IReadOnlyList<double>?)GetValue(ValuesProperty); set => SetValue(ValuesProperty, value); }
    public Brush Stroke { get => (Brush)GetValue(StrokeProperty); set => SetValue(StrokeProperty, value); }
    public Brush? Fill { get => (Brush?)GetValue(FillProperty); set => SetValue(FillProperty, value); }

    protected override void OnRender(DrawingContext dc)
    {
        var values = Values;
        double width = ActualWidth, height = ActualHeight;
        if (values is null || values.Count < 2 || width <= 2 || height <= 2) return;

        double min = values.Min();
        double max = values.Max();
        double span = Math.Max(0.0001, max - min);

        var points = new List<Point>(values.Count);
        for (int i = 0; i < values.Count; i++)
        {
            double x = width * i / (values.Count - 1);
            double y = height - 2 - (height - 4) * ((values[i] - min) / span);
            points.Add(new Point(x, y));
        }

        if (Fill is not null)
        {
            var geometry = new StreamGeometry();
            using (var ctx = geometry.Open())
            {
                ctx.BeginFigure(new Point(0, height), true, true);
                foreach (var point in points) ctx.LineTo(point, true, false);
                ctx.LineTo(new Point(width, height), true, false);
            }
            geometry.Freeze();
            dc.DrawGeometry(Fill, null, geometry);
        }

        var pen = new Pen(Stroke, 1.6) { LineJoin = PenLineJoin.Round };
        pen.Freeze();
        var line = new StreamGeometry();
        using (var ctx = line.Open())
        {
            ctx.BeginFigure(points[0], false, false);
            for (int i = 1; i < points.Count; i++) ctx.LineTo(points[i], true, false);
        }
        line.Freeze();
        dc.DrawGeometry(null, pen, line);
    }
}

/// <summary>The MemScope memory timeline: usage area, peak envelope, snapshot markers and live crosshair.</summary>
public sealed class MemoryTimeline : FrameworkElement
{
    private static readonly Typeface MonoTypeface = new(new FontFamily("Cascadia Mono, Consolas"), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
    private static readonly Typeface BodyTypeface = new(new FontFamily("Segoe UI"), FontStyles.Normal, FontWeights.SemiBold, FontStretches.Normal);
    private int _hover = -1;

    public static readonly DependencyProperty SeriesProperty = DependencyProperty.Register(
        nameof(Series), typeof(TimelineSeries), typeof(MemoryTimeline),
        new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty SelectedIndexProperty = DependencyProperty.Register(
        nameof(SelectedIndex), typeof(int), typeof(MemoryTimeline),
        new FrameworkPropertyMetadata(-1, FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

    public static readonly DependencyProperty AccentBrushProperty = DependencyProperty.Register(
        nameof(AccentBrush), typeof(Brush), typeof(MemoryTimeline),
        new FrameworkPropertyMetadata(Brushes.Goldenrod, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty PeakBrushProperty = DependencyProperty.Register(
        nameof(PeakBrush), typeof(Brush), typeof(MemoryTimeline),
        new FrameworkPropertyMetadata(Brushes.DeepSkyBlue, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty GridBrushProperty = DependencyProperty.Register(
        nameof(GridBrush), typeof(Brush), typeof(MemoryTimeline),
        new FrameworkPropertyMetadata(Brushes.DimGray, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty LabelBrushProperty = DependencyProperty.Register(
        nameof(LabelBrush), typeof(Brush), typeof(MemoryTimeline),
        new FrameworkPropertyMetadata(Brushes.Gray, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty IsLiveProperty = DependencyProperty.Register(
        nameof(IsLive), typeof(bool), typeof(MemoryTimeline),
        new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.AffectsRender));

    public TimelineSeries? Series { get => (TimelineSeries?)GetValue(SeriesProperty); set => SetValue(SeriesProperty, value); }
    public int SelectedIndex { get => (int)GetValue(SelectedIndexProperty); set => SetValue(SelectedIndexProperty, value); }
    public Brush AccentBrush { get => (Brush)GetValue(AccentBrushProperty); set => SetValue(AccentBrushProperty, value); }
    public Brush PeakBrush { get => (Brush)GetValue(PeakBrushProperty); set => SetValue(PeakBrushProperty, value); }
    public Brush GridBrush { get => (Brush)GetValue(GridBrushProperty); set => SetValue(GridBrushProperty, value); }
    public Brush LabelBrush { get => (Brush)GetValue(LabelBrushProperty); set => SetValue(LabelBrushProperty, value); }
    public bool IsLive { get => (bool)GetValue(IsLiveProperty); set => SetValue(IsLiveProperty, value); }

    public MemoryTimeline()
    {
        Cursor = System.Windows.Input.Cursors.Cross;
        ClipToBounds = true;
    }

    protected override void OnRender(DrawingContext dc)
    {
        double width = ActualWidth, height = ActualHeight;
        if (width < 20 || height < 20) return;

        var series = Series;
        double left = 52, right = 14, top = 12, bottom = 22;
        double plotWidth = width - left - right;
        double plotHeight = height - top - bottom;
        if (plotWidth <= 10 || plotHeight <= 10) return;

        var gridPen = new Pen(GridBrush, 1) { DashStyle = new DashStyle(new double[] { 2, 4 }, 0) };
        gridPen.Freeze();

        double rawMax = series?.MaxUsage ?? 0;
        bool hasScale = rawMax > 0;
        double max = hasScale ? rawMax * 1.08 : 1;

        for (int i = 0; i <= 4; i++)
        {
            double y = top + plotHeight * i / 4.0;
            dc.DrawLine(gridPen, new Point(left, y), new Point(width - right, y));
            if (hasScale && i < 4)
                DrawText(dc, Humanize.BytesCompact((long)(max * (1 - i / 4.0))), new Point(left - 8, y - 6), LabelBrush, 9, true);
            else if (!hasScale && i == 3)
                DrawText(dc, "0 B", new Point(left - 8, y - 6), LabelBrush, 9, true);
        }

        if (series is null || series.Points.Count == 0)
        {
            DrawText(dc, "Waiting for memory samples…", new Point(width / 2, height / 2 - 6), LabelBrush, 11, false, true, true);
            return;
        }

        var points = series.Points;
        double baseline = top + plotHeight;
        var coords = new List<Point>(points.Count);
        for (int i = 0; i < points.Count; i++)
        {
            double x = left + (points.Count == 1 ? 0 : plotWidth * i / (points.Count - 1));
            double y = baseline - plotHeight * Math.Clamp((double)points[i].UsageBytes / max, 0, 1);
            coords.Add(new Point(x, y));
        }

        // Area + usage line.
        var area = new StreamGeometry();
        using (var ctx = area.Open())
        {
            ctx.BeginFigure(new Point(coords[0].X, baseline), true, true);
            foreach (var point in coords) ctx.LineTo(point, true, false);
            ctx.LineTo(new Point(coords[^1].X, baseline), true, false);
        }
        area.Freeze();
        var fill = new LinearGradientBrush(
            Color.FromArgb(78, ((SolidColorBrush)AccentBrush).Color.R, ((SolidColorBrush)AccentBrush).Color.G, ((SolidColorBrush)AccentBrush).Color.B),
            Colors.Transparent, 90);
        fill.Freeze();
        dc.DrawGeometry(fill, null, area);

        var accentPen = new Pen(AccentBrush, 2) { LineJoin = PenLineJoin.Round };
        accentPen.Freeze();
        var line = new StreamGeometry();
        using (var ctx = line.Open())
        {
            ctx.BeginFigure(coords[0], false, false);
            for (int i = 1; i < coords.Count; i++) ctx.LineTo(coords[i], true, false);
        }
        line.Freeze();
        dc.DrawGeometry(null, accentPen, line);

        // Peak envelope.
        var peakPen = new Pen(PeakBrush, 1.1) { DashStyle = new DashStyle(new double[] { 4, 4 }, 0), };
        peakPen.Freeze();
        var peak = new StreamGeometry();
        using (var ctx = peak.Open())
        {
            for (int i = 0; i < points.Count; i++)
            {
                double x = left + (points.Count == 1 ? 0 : plotWidth * i / (points.Count - 1));
                double y = baseline - plotHeight * Math.Clamp((double)points[i].PeakBytes / max, 0, 1);
                if (i == 0) ctx.BeginFigure(new Point(x, y), false, false);
                else ctx.LineTo(new Point(x, y), true, false);
            }
        }
        peak.Freeze();
        dc.DrawGeometry(null, peakPen, peak);

        // Snapshot markers.
        var dotPen = new Pen(AccentBrush, 1.1);
        dotPen.Freeze();
        for (int i = 0; i < coords.Count; i++)
        {
            bool isSelected = i == SelectedIndex;
            bool isHover = i == _hover;
            if (!isSelected && !isHover && !IsLive) continue;
            double radius = isSelected ? 4.4 : 3.2;
            dc.DrawEllipse(new SolidColorBrush(Color.FromRgb(9, 11, 16)), dotPen, coords[i], radius, radius);
            if (isSelected) dc.DrawEllipse(AccentBrush, null, coords[i], 2, 2);
        }

        if (_hover >= 0 && _hover < coords.Count)
        {
            var hoverPen = new Pen(new SolidColorBrush(Color.FromArgb(120, 255, 255, 255)), 1);
            hoverPen.Freeze();
            dc.DrawLine(hoverPen, new Point(coords[_hover].X, top), new Point(coords[_hover].X, baseline));

            var point = points[_hover];
            string primary = Humanize.Bytes(point.UsageBytes);
            string secondary = $"peak {Humanize.Bytes(point.PeakBytes)}";
            string label = IsLive ? point.Name : $"{point.Name} · {TimeLabel(point.TimestampMs)}";
            double boxWidth = Math.Max(128, Math.Max(primary.Length, secondary.Length) * 6.4 + 20);
            double boxX = Math.Min(coords[_hover].X + 12, width - right - boxWidth);
            double boxY = Math.Max(top, coords[_hover].Y - 52);
            dc.DrawRoundedRectangle(new SolidColorBrush(Color.FromArgb(245, 18, 22, 32)), new Pen(GridBrush, 1), new Rect(boxX, boxY, boxWidth, 46), 8, 8);
            DrawText(dc, label, new Point(boxX + 9, boxY + 5), LabelBrush, 9);
            DrawText(dc, primary, new Point(boxX + 9, boxY + 17), AccentBrush, 13, false, true);
            DrawText(dc, secondary, new Point(boxX + 9, boxY + 31), LabelBrush, 9);
        }

        // Axis labels. Live samples grow left → right, so "now" sits on the right edge.
        string startLabel = IsLive ? $"{points.Count} samples" : "0.0 s";
        string endLabel = IsLive ? "now" : Humanize.Duration(series.DurationMs);
        DrawText(dc, startLabel, new Point(left, height - 16), LabelBrush, 9);
        DrawText(dc, endLabel, new Point(width - right, height - 16), LabelBrush, 9, true);
        if (points.Count > 2)
        {
            DrawText(dc, Humanize.BytesCompact(series.MaxUsage) + " max", new Point(width - right, top - 1), LabelBrush, 9, true, false);
        }
    }

    private static string TimeLabel(long ms) => ms < 1000 ? $"{ms} ms" : $"{ms / 1000.0:0.##} s";

    private int NearestIndex(Point position)
    {
        var series = Series;
        if (series is null || series.Points.Count == 0) return -1;
        double left = 52, right = 14;
        double plotWidth = ActualWidth - left - right;
        if (plotWidth <= 0) return -1;
        double ratio = Math.Clamp((position.X - left) / plotWidth, 0, 1);
        return (int)Math.Round(ratio * (series.Points.Count - 1));
    }

    protected override void OnMouseMove(System.Windows.Input.MouseEventArgs e)
    {
        base.OnMouseMove(e);
        int index = NearestIndex(e.GetPosition(this));
        if (index != _hover)
        {
            _hover = index;
            InvalidateVisual();
        }
    }

    protected override void OnMouseLeave(System.Windows.Input.MouseEventArgs e)
    {
        base.OnMouseLeave(e);
        if (_hover != -1)
        {
            _hover = -1;
            InvalidateVisual();
        }
    }

    protected override void OnMouseDown(System.Windows.Input.MouseButtonEventArgs e)
    {
        base.OnMouseDown(e);
        int index = NearestIndex(e.GetPosition(this));
        if (index >= 0) SelectedIndex = index;
        e.Handled = true;
    }

    private void DrawText(DrawingContext dc, string text, Point origin, Brush brush, double size,
        bool alignRight = false, bool mono = false, bool center = false)
    {
        var formatted = new FormattedText(
            text,
            CultureInfo.InvariantCulture,
            FlowDirection.LeftToRight,
            mono ? MonoTypeface : BodyTypeface,
            size,
            brush,
            VisualTreeHelper.GetDpi(this).PixelsPerDip);

        double x = origin.X;
        if (alignRight) x -= formatted.Width;
        else if (center) x -= formatted.Width / 2;
        dc.DrawText(formatted, new Point(x, origin.Y));
    }
}

/// <summary>Allocation histogram with animated hover readout.</summary>
public sealed class HistogramChart : FrameworkElement
{
    private static readonly Typeface MonoTypeface = new(new FontFamily("Cascadia Mono, Consolas"), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
    private static readonly Typeface BodyTypeface = new(new FontFamily("Segoe UI"), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
    private int _hover = -1;

    public static readonly DependencyProperty DataProperty = DependencyProperty.Register(
        nameof(Data), typeof(HistogramData), typeof(HistogramChart),
        new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty AccentBrushProperty = DependencyProperty.Register(
        nameof(AccentBrush), typeof(Brush), typeof(HistogramChart),
        new FrameworkPropertyMetadata(Brushes.Goldenrod, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty TextBrushProperty = DependencyProperty.Register(
        nameof(TextBrush), typeof(Brush), typeof(HistogramChart),
        new FrameworkPropertyMetadata(Brushes.Gray, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty GridBrushProperty = DependencyProperty.Register(
        nameof(GridBrush), typeof(Brush), typeof(HistogramChart),
        new FrameworkPropertyMetadata(Brushes.DimGray, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty ShowBytesProperty = DependencyProperty.Register(
        nameof(ShowBytes), typeof(bool), typeof(HistogramChart),
        new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.AffectsRender));

    public HistogramData? Data { get => (HistogramData?)GetValue(DataProperty); set => SetValue(DataProperty, value); }
    public Brush AccentBrush { get => (Brush)GetValue(AccentBrushProperty); set => SetValue(AccentBrushProperty, value); }
    public Brush TextBrush { get => (Brush)GetValue(TextBrushProperty); set => SetValue(TextBrushProperty, value); }
    public Brush GridBrush { get => (Brush)GetValue(GridBrushProperty); set => SetValue(GridBrushProperty, value); }
    public bool ShowBytes { get => (bool)GetValue(ShowBytesProperty); set => SetValue(ShowBytesProperty, value); }

    public HistogramChart()
    {
        ClipToBounds = true;
    }

    protected override void OnRender(DrawingContext dc)
    {
        double width = ActualWidth, height = ActualHeight;
        if (width < 20 || height < 20) return;

        double left = 10, right = 10, top = 12, bottom = 26;
        double plotWidth = width - left - right;
        double plotHeight = height - top - bottom;
        var data = Data;
        if (data is null || data.Buckets.Count == 0 || data.TotalCount == 0)
        {
            DrawText(dc, "No allocations recorded", new Point(width / 2, height / 2 - 6), TextBrush, 10, center: true);
            return;
        }

        var gridPen = new Pen(GridBrush, 1) { DashStyle = new DashStyle(new double[] { 2, 5 }, 0) };
        gridPen.Freeze();
        for (int i = 0; i <= 3; i++)
        {
            double y = top + plotHeight * i / 3.0;
            dc.DrawLine(gridPen, new Point(left, y), new Point(width - right, y));
        }

        long max = ShowBytes
            ? Math.Max(1, data.Buckets.Max(b => b.Bytes))
            : Math.Max(1, data.TotalCount);

        double barGap = 3;
        double barWidth = Math.Max(2, plotWidth / data.Buckets.Count - barGap);
        var accentColor = ((SolidColorBrush)AccentBrush).Color;
        var fill = new LinearGradientBrush(
            Color.FromArgb(255, accentColor.R, accentColor.G, accentColor.B),
            Color.FromArgb(60, accentColor.R, accentColor.G, accentColor.B), 90);
        fill.Freeze();

        for (int i = 0; i < data.Buckets.Count; i++)
        {
            var bucket = data.Buckets[i];
            double value = ShowBytes ? bucket.Bytes : bucket.Count;
            double ratio = (double)value / max;
            double h = Math.Max(value > 0 ? 2 : 1, plotHeight * ratio);
            if (value == 0) h = 1;
            double x = left + i * (barWidth + barGap) + barGap / 2;
            double y = top + plotHeight - h;

            var brush = value == 0 ? GridBrush : (Brush)fill;
            dc.DrawRoundedRectangle(brush, null, new Rect(x, y, barWidth, h), 2, 2);

            if (i == _hover && value > 0)
            {
                var outline = new Pen(AccentBrush, 1.2);
                outline.Freeze();
                dc.DrawRoundedRectangle(null, outline, new Rect(x - 1, y - 1, barWidth + 2, h + 2), 3, 3);
            }
        }

        if (_hover >= 0 && _hover < data.Buckets.Count)
        {
            var bucket = data.Buckets[_hover];
            string line1 = bucket.Label;
            string line2 = ShowBytes
                ? $"{Humanize.Bytes(bucket.Bytes)} · {Humanize.Count(bucket.Count)} allocs"
                : $"{Humanize.Count(bucket.Count)} allocs · {Humanize.Bytes(bucket.Bytes)}";
            double boxWidth = Math.Max(150, line2.Length * 5.8 + 20);
            double boxX = Math.Clamp(left + _hover * (barWidth + barGap) - boxWidth / 2 + barWidth / 2, left, width - right - boxWidth);
            double boxY = top + 2;
            dc.DrawRoundedRectangle(new SolidColorBrush(Color.FromArgb(242, 18, 22, 32)), new Pen(GridBrush, 1), new Rect(boxX, boxY, boxWidth, 38), 8, 8);
            DrawText(dc, line1, new Point(boxX + 9, boxY + 5), TextBrush, 9);
            DrawText(dc, line2, new Point(boxX + 9, boxY + 19), AccentBrush, 9.5, mono: true);
        }

        DrawText(dc, data.Buckets[0].Label, new Point(left, height - 17), TextBrush, 8.5);
        DrawText(dc, data.Buckets[data.Buckets.Count / 2].Label, new Point(width / 2, height - 17), TextBrush, 8.5, center: true);
        DrawText(dc, data.Buckets[^1].Label, new Point(width - right, height - 17), TextBrush, 8.5, alignRight: true);
        string summary = data.Estimated ? "modelled distribution" : "sampled operations";
        DrawText(dc, summary, new Point(width - right, top + 1), TextBrush, 8.5, alignRight: true);
    }

    protected override void OnMouseMove(System.Windows.Input.MouseEventArgs e)
    {
        base.OnMouseMove(e);
        var data = Data;
        if (data is null || data.Buckets.Count == 0) return;
        double left = 10, right = 10;
        double plotWidth = ActualWidth - left - right;
        double barWidth = plotWidth / data.Buckets.Count;
        int index = (int)Math.Floor((e.GetPosition(this).X - left) / Math.Max(1, barWidth));
        index = Math.Clamp(index, 0, data.Buckets.Count - 1);
        if (index != _hover)
        {
            _hover = index;
            InvalidateVisual();
        }
    }

    protected override void OnMouseLeave(System.Windows.Input.MouseEventArgs e)
    {
        base.OnMouseLeave(e);
        if (_hover != -1)
        {
            _hover = -1;
            InvalidateVisual();
        }
    }

    private void DrawText(DrawingContext dc, string text, Point origin, Brush brush, double size,
        bool alignRight = false, bool center = false, bool mono = false)
    {
        var formatted = new FormattedText(text, CultureInfo.InvariantCulture, FlowDirection.LeftToRight,
            mono ? MonoTypeface : BodyTypeface, size, brush, VisualTreeHelper.GetDpi(this).PixelsPerDip);
        double x = origin.X;
        if (alignRight) x -= formatted.Width;
        else if (center) x -= formatted.Width / 2;
        dc.DrawText(formatted, new Point(x, origin.Y));
    }
}

/// <summary>Vertical map of the target's virtual memory regions.</summary>
public sealed class MemoryMapStrip : FrameworkElement
{
    private static readonly Typeface MonoTypeface = new(new FontFamily("Cascadia Mono, Consolas"), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
    private int _hover = -1;
    private List<(MemoryRegionInfo Region, double X, double Width)> _bars = new();

    public static readonly DependencyProperty RegionsProperty = DependencyProperty.Register(
        nameof(Regions), typeof(IReadOnlyList<MemoryRegionInfo>), typeof(MemoryMapStrip),
        new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty AccentBrushProperty = DependencyProperty.Register(
        nameof(AccentBrush), typeof(Brush), typeof(MemoryMapStrip),
        new FrameworkPropertyMetadata(Brushes.Goldenrod, FrameworkPropertyMetadataOptions.AffectsRender));

    public IReadOnlyList<MemoryRegionInfo>? Regions { get => (IReadOnlyList<MemoryRegionInfo>?)GetValue(RegionsProperty); set => SetValue(RegionsProperty, value); }
    public Brush AccentBrush { get => (Brush)GetValue(AccentBrushProperty); set => SetValue(AccentBrushProperty, value); }

    public MemoryMapStrip()
    {
        ClipToBounds = true;
    }

    protected override void OnRender(DrawingContext dc)
    {
        double width = ActualWidth, height = ActualHeight;
        if (width < 20 || height < 12) return;
        _bars.Clear();

        var regions = Regions;
        if (regions is null || regions.Count == 0)
        {
            dc.DrawRoundedRectangle(new SolidColorBrush(Color.FromArgb(255, 20, 24, 34)), null, new Rect(0, 10, width, 6), 3, 3);
            return;
        }

        // Keep the largest regions, preserve address order, scale by sqrt so small arenas remain visible.
        var visible = regions
            .Where(r => r.Size > 0)
            .OrderByDescending(r => r.Size)
            .Take(420)
            .OrderBy(r => r.BaseAddress)
            .ToList();

        var weights = visible.Select(r => Math.Sqrt(r.Size)).ToList();
        double total = weights.Sum();
        if (total <= 0) return;

        double x = 0;
        for (int i = 0; i < visible.Count; i++)
        {
            double barWidth = Math.Max(0.7, width * weights[i] / total);
            if (x >= width) break;
            barWidth = Math.Min(barWidth, width - x);
            var region = visible[i];
            Color color = region.State switch
            {
                MemoryRegionState.Commit => region.Type switch
                {
                    MemoryRegionType.Image => Color.FromRgb(0x5F, 0xD4, 0xFF),
                    MemoryRegionType.Mapped => Color.FromRgb(0xA9, 0x98, 0xFF),
                    _ => ((SolidColorBrush)AccentBrush).Color
                },
                MemoryRegionState.Reserve => Color.FromRgb(0x5B, 0x66, 0x82),
                _ => Color.FromRgb(0x28, 0x2E, 0x3E)
            };
            if (i == _hover) color = Color.FromRgb(0xFF, 0xFF, 0xFF);
            dc.DrawRectangle(new SolidColorBrush(color), null, new Rect(x, _hover == i ? 6 : 9, Math.Max(0.6, barWidth - 0.6), _hover == i ? height - 12 : height - 18));
            _bars.Add((region, x, barWidth));
            x += barWidth;
        }

        if (_hover >= 0 && _hover < _bars.Count)
        {
            var (region, _, _) = _bars[_hover];
            string text = $"{Humanize.Bytes(region.Size)} · {region.StateLabel} · {region.TypeLabel} · {region.ProtectionLabel}";
            double boxWidth = Math.Min(width, text.Length * 6 + 18);
            double boxX = Math.Clamp(_bars[_hover].X, 0, width - boxWidth);
            dc.DrawRoundedRectangle(new SolidColorBrush(Color.FromArgb(242, 18, 22, 32)), new Pen(new SolidColorBrush(Color.FromRgb(0x23, 0x28, 0x37)), 1), new Rect(boxX, -2, boxWidth, 22), 6, 6);
            var formatted = new FormattedText(text, CultureInfo.InvariantCulture, FlowDirection.LeftToRight,
                MonoTypeface, 9, new SolidColorBrush(Color.FromRgb(0xE6, 0xEC, 0xF9)), VisualTreeHelper.GetDpi(this).PixelsPerDip);
            dc.DrawText(formatted, new Point(boxX + 8, 3));
        }
    }

    protected override void OnMouseMove(System.Windows.Input.MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (_bars.Count == 0) return;
        double x = e.GetPosition(this).X;
        int index = _bars.FindIndex(b => x >= b.X && x <= b.X + b.Width);
        if (index != _hover)
        {
            _hover = index;
            InvalidateVisual();
        }
    }

    protected override void OnMouseLeave(System.Windows.Input.MouseEventArgs e)
    {
        base.OnMouseLeave(e);
        if (_hover != -1)
        {
            _hover = -1;
            InvalidateVisual();
        }
    }
}

/// <summary>Circular gauge for CPU / overhead style percentages.</summary>
public sealed class RingGauge : FrameworkElement
{
    public static readonly DependencyProperty ValueProperty = DependencyProperty.Register(
        nameof(Value), typeof(double), typeof(RingGauge),
        new FrameworkPropertyMetadata(0.0, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty AccentBrushProperty = DependencyProperty.Register(
        nameof(AccentBrush), typeof(Brush), typeof(RingGauge),
        new FrameworkPropertyMetadata(Brushes.Goldenrod, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty TrackBrushProperty = DependencyProperty.Register(
        nameof(TrackBrush), typeof(Brush), typeof(RingGauge),
        new FrameworkPropertyMetadata(Brushes.DimGray, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty TextBrushProperty = DependencyProperty.Register(
        nameof(TextBrush), typeof(Brush), typeof(RingGauge),
        new FrameworkPropertyMetadata(Brushes.White, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty CenterTextProperty = DependencyProperty.Register(
        nameof(CenterText), typeof(string), typeof(RingGauge),
        new FrameworkPropertyMetadata("0%", FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty SubTextProperty = DependencyProperty.Register(
        nameof(SubText), typeof(string), typeof(RingGauge),
        new FrameworkPropertyMetadata("CPU", FrameworkPropertyMetadataOptions.AffectsRender));

    public double Value { get => (double)GetValue(ValueProperty); set => SetValue(ValueProperty, value); }
    public Brush AccentBrush { get => (Brush)GetValue(AccentBrushProperty); set => SetValue(AccentBrushProperty, value); }
    public Brush TrackBrush { get => (Brush)GetValue(TrackBrushProperty); set => SetValue(TrackBrushProperty, value); }
    public Brush TextBrush { get => (Brush)GetValue(TextBrushProperty); set => SetValue(TextBrushProperty, value); }
    public string CenterText { get => (string)GetValue(CenterTextProperty); set => SetValue(CenterTextProperty, value); }
    public string SubText { get => (string)GetValue(SubTextProperty); set => SetValue(SubTextProperty, value); }

    protected override void OnRender(DrawingContext dc)
    {
        double size = Math.Min(ActualWidth, ActualHeight);
        if (size < 20) return;
        double thickness = Math.Max(4, size * 0.075);
        double radius = (size - thickness) / 2;
        var center = new Point(ActualWidth / 2, ActualHeight / 2);

        var trackPen = new Pen(TrackBrush, thickness) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round };
        trackPen.Freeze();
        dc.DrawEllipse(null, trackPen, center, radius, radius);

        double ratio = Math.Clamp(Value / 100.0, 0, 1);
        if (ratio > 0)
        {
            var accentPen = new Pen(AccentBrush, thickness) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round };
            accentPen.Freeze();
            double angle = ratio * 359.9;
            var start = PointOnCircle(center, radius, -90);
            var end = PointOnCircle(center, radius, -90 + angle);
            var geometry = new StreamGeometry();
            using (var ctx = geometry.Open())
            {
                ctx.BeginFigure(start, false, false);
                ctx.ArcTo(end, new Size(radius, radius), 0, angle > 180, SweepDirection.Clockwise, true, false);
            }
            geometry.Freeze();
            dc.DrawGeometry(null, accentPen, geometry);
        }

        DrawCentered(dc, CenterText, center.Y - 9, 17, TextBrush, bold: true);
        DrawCentered(dc, SubText, center.Y + 10, 8.5, new SolidColorBrush(Color.FromRgb(0x8C, 0x96, 0xAC)));
    }

    private static Point PointOnCircle(Point center, double radius, double angleDegrees)
    {
        double radians = angleDegrees * Math.PI / 180.0;
        return new Point(center.X + radius * Math.Cos(radians), center.Y + radius * Math.Sin(radians));
    }

    private void DrawCentered(DrawingContext dc, string text, double y, double size, Brush brush, bool bold = false)
    {
        var typeface = new Typeface(new FontFamily("Segoe UI"), FontStyles.Normal, bold ? FontWeights.SemiBold : FontWeights.Normal, FontStretches.Normal);
        var formatted = new FormattedText(text, CultureInfo.InvariantCulture, FlowDirection.LeftToRight,
            typeface, size, brush, VisualTreeHelper.GetDpi(this).PixelsPerDip);
        dc.DrawText(formatted, new Point((ActualWidth - formatted.Width) / 2, y));
    }
}

/// <summary>Elegant scope motif for the command centre hero.</summary>
public sealed class ScopeMotif : FrameworkElement
{
    public static readonly DependencyProperty AccentBrushProperty = DependencyProperty.Register(
        nameof(AccentBrush), typeof(Brush), typeof(ScopeMotif),
        new FrameworkPropertyMetadata(Brushes.Goldenrod, FrameworkPropertyMetadataOptions.AffectsRender));

    public Brush AccentBrush { get => (Brush)GetValue(AccentBrushProperty); set => SetValue(AccentBrushProperty, value); }

    public ScopeMotif()
    {
        IsHitTestVisible = false;
    }

    protected override void OnRender(DrawingContext dc)
    {
        double size = Math.Min(ActualWidth, ActualHeight);
        if (size < 40) return;
        var center = new Point(ActualWidth / 2, ActualHeight / 2);
        var accent = (SolidColorBrush)AccentBrush;
        double radius = size * 0.42;

        for (int i = 0; i < 4; i++)
        {
            double r = radius * (1 - i * 0.18);
            var pen = new Pen(new SolidColorBrush(Color.FromArgb((byte)(70 - i * 12), accent.Color.R, accent.Color.G, accent.Color.B)), 1);
            pen.Freeze();
            dc.DrawEllipse(null, pen, center, r, r);
        }

        var crossPen = new Pen(new SolidColorBrush(Color.FromArgb(36, 255, 255, 255)), 1) { DashStyle = new DashStyle(new double[] { 2, 6 }, 0) };
        crossPen.Freeze();
        dc.DrawLine(crossPen, new Point(center.X - radius, center.Y), new Point(center.X + radius, center.Y));
        dc.DrawLine(crossPen, new Point(center.X, center.Y - radius), new Point(center.X, center.Y + radius));

        var arcPen = new Pen(accent, 2.4) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round };
        arcPen.Freeze();
        dc.DrawGeometry(null, arcPen, Arc(center, radius * 0.9, 200, 290));
        dc.DrawGeometry(null, arcPen, Arc(center, radius * 0.68, 25, 90));

        var dotPen = new Pen(new SolidColorBrush(Color.FromArgb(120, accent.Color.R, accent.Color.G, accent.Color.B)), 1);
        dotPen.Freeze();
        var rnd = new Random(8);
        for (int i = 0; i < 34; i++)
        {
            double angle = rnd.NextDouble() * Math.PI * 2;
            double dist = radius * (0.15 + rnd.NextDouble() * 0.78);
            var point = new Point(center.X + Math.Cos(angle) * dist, center.Y + Math.Sin(angle) * dist);
            double dotSize = rnd.NextDouble() > 0.85 ? 2.4 : 1.1;
            dc.DrawEllipse(new SolidColorBrush(Color.FromArgb((byte)(70 + rnd.Next(120)), accent.Color.R, accent.Color.G, accent.Color.B)), null, point, dotSize, dotSize);
        }

        var glow = new RadialGradientBrush(Color.FromArgb(90, accent.Color.R, accent.Color.G, accent.Color.B), Colors.Transparent);
        glow.Freeze();
        dc.DrawEllipse(glow, null, center, radius * 0.22, radius * 0.22);
        dc.DrawEllipse(accent, null, center, 3.4, 3.4);
    }

    private static StreamGeometry Arc(Point center, double radius, double startAngle, double endAngle)
    {
        var start = new Point(center.X + radius * Math.Cos(startAngle * Math.PI / 180), center.Y + radius * Math.Sin(startAngle * Math.PI / 180));
        var end = new Point(center.X + radius * Math.Cos(endAngle * Math.PI / 180), center.Y + radius * Math.Sin(endAngle * Math.PI / 180));
        var geometry = new StreamGeometry();
        using (var ctx = geometry.Open())
        {
            ctx.BeginFigure(start, false, false);
            ctx.ArcTo(end, new Size(radius, radius), 0, false, SweepDirection.Clockwise, true, false);
        }
        geometry.Freeze();
        return geometry;
    }
}
