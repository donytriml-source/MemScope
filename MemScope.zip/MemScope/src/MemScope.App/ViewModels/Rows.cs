using System.Windows.Media;
using MemScope.App.Mvvm;
using MemScope.Core.Analysis;
using MemScope.Core.Models;
using MemScope.Core.Util;

namespace MemScope.App.ViewModels;

public enum CapturePage
{
    Home = 0,
    Live = 1,
    Analysis = 2
}

public sealed class CallTreeRow : ObservableObject
{
    private bool _isExpanded;

    public CallTreeRow(CallTreeNode node, int depth, bool isExpanded)
    {
        Node = node;
        Depth = depth;
        _isExpanded = isExpanded;
        Indent = depth * 15.0;
    }

    public CallTreeNode Node { get; }
    public int Depth { get; }
    public double Indent { get; }
    public string Name => Node.Name;
    public string Module => Node.Module;
    public string FileLabel => string.IsNullOrEmpty(Node.File) ? "—" : System.IO.Path.GetFileName(Node.File);
    public string LineLabel => Node.Line > 0 ? Node.Line.ToString() : "—";
    public long Usage => Node.Usage;
    public long Peak => Node.PeakUsage;
    public long Allocations => Node.Allocations;
    public long Frees => Node.Frees;
    public long Reallocations => Node.Reallocations;
    public double Share => Node.Share;
    public bool HasChildren => Node.HasChildren;
    public bool IsUnknown => Node.IsUnknown;
    public bool IsGroup => Node.IsGroup;
    public string ShareLabel => Node.UsageShareLabel;
    public string Tooltip => $"{Node.Name}\n{Node.Module} · {Node.Location}\n{Humanize.Bytes(Node.Usage)} live · {Humanize.Count(Node.Allocations)} allocations · {Node.Children.Count} children";

    public bool IsExpanded
    {
        get => _isExpanded;
        set
        {
            if (Set(ref _isExpanded, value)) OnPropertyChanged(nameof(ChevronOpacity));
        }
    }

    public double ChevronOpacity => HasChildren ? 1 : 0;
}

public sealed record HeapRow(string Name, string IdLabel, long Blocks, long Bytes, double Share, bool IsDefault);

public sealed record StatRow(string Label, string GlobalValue, string SnapshotValue, double Ratio, bool Accent = false);

public sealed class StackFrameRow
{
    public int Index { get; init; }
    public string IndexLabel => Index.ToString("00");
    public string Function { get; init; } = string.Empty;
    public string Module { get; init; } = string.Empty;
    public string Location { get; init; } = string.Empty;
    public string AddressLabel { get; init; } = string.Empty;
    public string File { get; init; } = string.Empty;
    public int Line { get; init; }
    public bool IsLeaf { get; init; }
    public bool IsUnknown { get; init; }
}

public sealed record ContributorRow(string Title, string Module, long Bytes, long Allocations, double Share);

public sealed record SnapshotOption(int Index, string Label)
{
    public override string ToString() => Label;
}

public sealed record RecentCaptureItem(string Name, string Path, string DateLabel, string SizeLabel, bool Exists)
{
    public string Subtitle => Exists ? $"{DateLabel} · {SizeLabel}" : "File not found — it may have been moved";
}

public sealed record ToastMessage(string Title, string Message, ToastKind Kind);

public enum ToastKind
{
    Info,
    Success,
    Warning,
    Error
}

public sealed record PaletteCommand(string Group, string Title, string Hint, string Shortcut, Action Execute);
