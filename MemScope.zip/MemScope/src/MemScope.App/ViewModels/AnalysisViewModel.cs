using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Threading;
using MemScope.App.Mvvm;
using MemScope.App.Services;
using MemScope.Core.Analysis;
using MemScope.Core.Models;
using MemScope.Core.Sessions;
using MemScope.Core.Util;

namespace MemScope.App.ViewModels;

public sealed class AnalysisViewModel : ObservableObject
{
    private readonly IDialogService _dialogs;
    private readonly ToastService _toasts;
    private readonly DispatcherTimer _searchDebounce;
    private readonly Dictionary<string, string?> _sourceCache = new(StringComparer.OrdinalIgnoreCase);

    private MemSession? _session;
    private CallTreeNode? _root;
    private readonly HashSet<string> _expandedPaths = new(StringComparer.Ordinal);
    private CallTreeNode? _selectedNode;
    private CallTreeRow? _selectedRow;
    private StackRecord? _inspectedStack;
    private string _searchText = string.Empty;
    private double _minSizeValue;
    private string _moduleFilter = "All modules";
    private bool _groupByModule;
    private bool _hideUnknown;
    private int _selectedSnapshot;
    private int _timelineSelectedIndex = -1;
    private int _selectedTab;
    private bool _suppressFilter;
    private string _baselineName = string.Empty;
    private DiffSummary? _diff;

    public AnalysisViewModel(IDialogService dialogs, ToastService toasts)
    {
        _dialogs = dialogs;
        _toasts = toasts;
        _searchDebounce = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(280) };
        _searchDebounce.Tick += (_, _) =>
        {
            _searchDebounce.Stop();
            RebuildTree();
        };

        ToggleRowCommand = new RelayCommand(parameter =>
        {
            if (parameter is CallTreeRow row) ToggleRow(row);
        });
        ExpandAllCommand = new RelayCommand(ExpandAll);
        CollapseAllCommand = new RelayCommand(CollapseAll);
        ResetFiltersCommand = new RelayCommand(ResetFilters);
        SelectHotspotCommand = new RelayCommand(parameter =>
        {
            if (parameter is Hotspot hotspot) SelectStack(hotspot.StackId);
        });
        SelectLeakCommand = new RelayCommand(parameter =>
        {
            if (parameter is LeakCandidate leak) SelectStack(leak.StackId);
        });
        CopyStackCommand = new RelayCommand(CopyStack);
        FilterToFunctionCommand = new RelayCommand(FilterToFunction);
        OpenSourceCommand = new RelayCommand(OpenSource);
        CompareDemoCommand = new RelayCommand(CompareWithDemo);
        CompareFileCommand = new RelayCommand(ChooseBaseline);
        ClearSelectionCommand = new RelayCommand(ClearSelection);

        StatRows = new ObservableCollection<StatRow>();
        Rows = new ObservableCollection<CallTreeRow>();
        Heaps = new ObservableCollection<HeapRow>();
        Insights = new ObservableCollection<Insight>();
        Hotspots = new ObservableCollection<Hotspot>();
        Leaks = new ObservableCollection<LeakCandidate>();
        StackFrames = new ObservableCollection<StackFrameRow>();
        Contributors = new ObservableCollection<ContributorRow>();
        DiffEntries = new ObservableCollection<DiffEntry>();
        Modules = new ObservableCollection<string> { "All modules" };
        SnapshotOptions = new ObservableCollection<SnapshotOption>();
    }

    public ObservableCollection<StatRow> StatRows { get; }
    public ObservableCollection<CallTreeRow> Rows { get; }
    public ObservableCollection<HeapRow> Heaps { get; }
    public ObservableCollection<Insight> Insights { get; }
    public ObservableCollection<Hotspot> Hotspots { get; }
    public ObservableCollection<LeakCandidate> Leaks { get; }
    public ObservableCollection<StackFrameRow> StackFrames { get; }
    public ObservableCollection<ContributorRow> Contributors { get; }
    public ObservableCollection<DiffEntry> DiffEntries { get; }
    public ObservableCollection<string> Modules { get; }
    public ObservableCollection<SnapshotOption> SnapshotOptions { get; }

    public RelayCommand ToggleRowCommand { get; }
    public RelayCommand ExpandAllCommand { get; }
    public RelayCommand CollapseAllCommand { get; }
    public RelayCommand ResetFiltersCommand { get; }
    public RelayCommand SelectHotspotCommand { get; }
    public RelayCommand SelectLeakCommand { get; }
    public RelayCommand CopyStackCommand { get; }
    public RelayCommand FilterToFunctionCommand { get; }
    public RelayCommand OpenSourceCommand { get; }
    public RelayCommand CompareDemoCommand { get; }
    public RelayCommand CompareFileCommand { get; }
    public RelayCommand ClearSelectionCommand { get; }

    public MemSession? Session => _session;
    public bool HasSession => _session is not null;
    public SessionStatistics Stats { get; private set; } = new();
    public SessionStatistics SnapshotStats { get; private set; } = new();
    public TimelineSeries? Timeline { get; private set; }
    public HistogramData? Histogram { get; private set; }
    public CallTreeNode? TreemapRoot => _root;
    public string SessionName => _session?.Metadata.Name ?? "No capture loaded";
    public string SessionSubtitle => _session is null
        ? "Open a capture or explore the walkthrough dataset"
        : $"{_session.Metadata.TargetProcess} · {_session.Metadata.DisplayDate} · {_session.Metadata.DisplayDuration}";
    public string SessionTarget => _session?.Metadata.TargetProcess ?? "—";
    public bool IsSynthetic => _session?.Metadata.IsSynthetic ?? false;
    public string Origin => _session?.Metadata.Origin ?? string.Empty;
    public string CaptureIdLabel => _session is null ? "—" : "#" + _session.Metadata.CaptureId[..Math.Min(8, _session.Metadata.CaptureId.Length)];
    public int BacktraceCount => _session?.Stacks.Count ?? 0;
    public int FrameCount => _session?.Frames.Count ?? 0;
    public string GrowthLabel => Timeline is null ? "—" : Humanize.SignedBytes(Timeline.Delta);
    public double GrowthRatio => Timeline?.GrowthRatio ?? 0;
    public string LeakCountLabel => Leaks.Count(l => l.Confidence != LeakConfidence.Watch).ToString();
    public string HeaderTitle => _selectedTab switch
    {
        1 => "Hotspots",
        2 => "Leak candidates",
        3 => "Heap treemap",
        4 => "Capture comparison",
        _ => "Call tree"
    };
    public string HeaderHint => _selectedTab switch
    {
        1 => "Backtraces ranked by retention, churn and block pressure.",
        2 => "Backtraces that retain memory far beyond their release behaviour.",
        3 => "Squarified composition of the live heap — click a tile to inspect it.",
        4 => "Retained bytes per backtrace versus the selected baseline.",
        _ => "Every allocation path in the capture, aggregated inclusively. Select a node to inspect its stack."
    };
    public string SnapshotLabel => _selectedSnapshot <= 0 ? "Global" : SnapshotOptions.FirstOrDefault(o => o.Index == _selectedSnapshot)?.Label ?? "Global";
    public bool HasSnapshotScope => _selectedSnapshot > 0;

    public bool HasSelection => _selectedNode is not null || _inspectedStack is not null;
    public string InspectorTitle => _selectedNode?.Name ?? (LeafOfStack(_inspectedStack)?.DisplayFunction ?? "Nothing selected");
    public string InspectorModule => _selectedNode?.Module ?? _session?.ModuleNameOf(LeafOfStack(_inspectedStack)) ?? "—";
    public string InspectorLocation => _selectedNode is { Line: > 0 }
        ? $"{_selectedNode.File}:{_selectedNode.Line}"
        : LeafOfStack(_inspectedStack) is { Line: > 0 } leaf ? $"{leaf.File}:{leaf.Line}" : "Source unavailable";
    public string InspectorFile => _selectedNode?.File ?? LeafOfStack(_inspectedStack)?.File ?? string.Empty;
    public int InspectorLine => _selectedNode?.Line ?? LeafOfStack(_inspectedStack)?.Line ?? 0;
    public string InspectedSource { get; private set; } = string.Empty;
    public string InspectedSourceName { get; private set; } = string.Empty;
    public SessionStatistics InspectorStats { get; private set; } = new();
    public string InspectorPath { get; private set; } = string.Empty;
    public bool HasSource => !string.IsNullOrEmpty(InspectedSource);
    public string SourceButtonLabel => string.IsNullOrEmpty(InspectorFile) || !File.Exists(InspectorFile) ? "Source not on disk" : "Reveal in explorer";
    public bool CanRevealSource => !string.IsNullOrEmpty(InspectorFile) && File.Exists(InspectorFile);
    public string SelectionShareLabel => InspectorStats.UsageBytes == 0 || Stats.UsageBytes == 0 ? "—" : Humanize.Percent((double)InspectorStats.UsageBytes / Stats.UsageBytes);

    public string SearchText
    {
        get => _searchText;
        set
        {
            if (!Set(ref _searchText, value)) return;
            _searchDebounce.Stop();
            _searchDebounce.Start();
        }
    }

    public double MinSizeValue
    {
        get => _minSizeValue;
        set
        {
            if (!Set(ref _minSizeValue, value)) return;
            OnPropertyChanged(nameof(MinSizeLabel));
            RebuildTree();
        }
    }

    public string MinSizeLabel => _minSizeValue <= 0.5 ? "Any size" : "≥ " + Humanize.Bytes(MinBytes);

    private long MinBytes => _minSizeValue <= 0.5 ? 0 : (long)Math.Pow(2, _minSizeValue / 10.0);

    public string ModuleFilter
    {
        get => _moduleFilter;
        set
        {
            if (!Set(ref _moduleFilter, value)) return;
            RebuildTree();
        }
    }

    public bool GroupByModule
    {
        get => _groupByModule;
        set
        {
            if (!Set(ref _groupByModule, value)) return;
            RebuildTree();
        }
    }

    public bool HideUnknown
    {
        get => _hideUnknown;
        set
        {
            if (!Set(ref _hideUnknown, value)) return;
            RebuildTree();
        }
    }

    public int SelectedSnapshot
    {
        get => _selectedSnapshot;
        set
        {
            if (!Set(ref _selectedSnapshot, value)) return;
            UpdateSnapshotStats();
            _timelineSelectedIndex = value - 1;
            OnPropertyChanged(nameof(TimelineSelectedIndex));
            OnPropertyChanged(nameof(SnapshotLabel));
            OnPropertyChanged(nameof(HasSnapshotScope));
        }
    }

    public int TimelineSelectedIndex
    {
        get => _timelineSelectedIndex;
        set
        {
            if (!Set(ref _timelineSelectedIndex, value)) return;
            int mapped = value + 1;
            if (mapped >= 0 && mapped < SnapshotOptions.Count && mapped != _selectedSnapshot)
            {
                _selectedSnapshot = mapped;
                OnPropertyChanged(nameof(SelectedSnapshot));
                OnPropertyChanged(nameof(SnapshotLabel));
                OnPropertyChanged(nameof(HasSnapshotScope));
                UpdateSnapshotStats();
            }
        }
    }

    public int SelectedTab
    {
        get => _selectedTab;
        set
        {
            if (!Set(ref _selectedTab, value)) return;
            Raise(nameof(HeaderTitle), nameof(HeaderHint));
        }
    }

    public CallTreeRow? SelectedRow
    {
        get => _selectedRow;
        set
        {
            if (!Set(ref _selectedRow, value)) return;
            if (value is not null) SelectNode(value.Node, updateTreemap: true);
        }
    }

    public CallTreeNode? SelectedNode
    {
        get => _selectedNode;
        set
        {
            if (ReferenceEquals(_selectedNode, value)) return;
            _selectedNode = value;
            _inspectedStack = null;
            OnPropertyChanged();
            UpdateInspector();
        }
    }

    public string BaselineName
    {
        get => _baselineName;
        private set
        {
            if (!Set(ref _baselineName, value)) return;
            OnPropertyChanged(nameof(BaselineLabel));
        }
    }

    public string BaselineLabel => string.IsNullOrWhiteSpace(_baselineName) ? "nothing yet" : _baselineName;

    /// <summary>Synthetic walkthrough capture used as the one-click comparison baseline.</summary>
    public MemSession? DemoBaseline { get; set; }

    public DiffSummary? Diff
    {
        get => _diff;
        private set => Set(ref _diff, value);
    }

    public void Load(MemSession session)
    {
        _session = session;
        _sourceCache.Clear();
        _expandedPaths.Clear();
        _selectedNode = null;
        _selectedRow = null;
        _inspectedStack = null;
        _selectedSnapshot = 0;
        _timelineSelectedIndex = -1;

        Modules.Clear();
        Modules.Add("All modules");
        foreach (var module in session.Modules.OrderBy(m => m.Name, StringComparer.OrdinalIgnoreCase))
            Modules.Add(module.Name);

        SnapshotOptions.Clear();
        SnapshotOptions.Add(new SnapshotOption(0, "Global"));
        for (int i = 0; i < session.Snapshots.Count; i++)
            SnapshotOptions.Add(new SnapshotOption(i + 1, $"{session.Snapshots[i].Name} · {Humanize.Duration(session.Snapshots[i].TimestampMs)}"));

        _moduleFilter = "All modules";
        _searchText = string.Empty;
        _minSizeValue = 0;
        _groupByModule = false;
        _hideUnknown = false;
        Raise(nameof(SearchText), nameof(MinSizeValue), nameof(MinSizeLabel), nameof(ModuleFilter), nameof(GroupByModule), nameof(HideUnknown));

        TreeBuild();
        RefreshHeaps();
        RefreshInsights();
        RefreshHotspots();
        RefreshLeaks();
        Timeline = TimelineBuilder.Build(session);
        Histogram = HistogramBuilder.Build(session);
        Stats = session.ComputeStatistics();
        UpdateSnapshotStats();
        OnPropertyChanged(nameof(Timeline));
        OnPropertyChanged(nameof(Histogram));
        OnPropertyChanged(nameof(SessionName));
        OnPropertyChanged(nameof(SessionSubtitle));
        OnPropertyChanged(nameof(SessionTarget));
        OnPropertyChanged(nameof(IsSynthetic));
        OnPropertyChanged(nameof(Origin));
        OnPropertyChanged(nameof(CaptureIdLabel));
        OnPropertyChanged(nameof(BacktraceCount));
        OnPropertyChanged(nameof(FrameCount));
        OnPropertyChanged(nameof(HasSession));
        OnPropertyChanged(nameof(GrowthLabel));
        OnPropertyChanged(nameof(GrowthRatio));
        OnPropertyChanged(nameof(LeakCountLabel));
        OnPropertyChanged(nameof(TreemapRoot));
        UpdateInspector();
        Diff = null;
        OnPropertyChanged(nameof(Diff));

        // Open on the heaviest allocation path so the inspector and treemap start populated.
        if (_selectedNode is null && Rows.Count > 0) SelectedRow = Rows[0];
    }

    private void TreeBuild()
    {
        if (_session is null) return;
        var options = new CallTreeOptions
        {
            GroupByModule = _groupByModule,
            MinBytes = 0,
            Search = string.IsNullOrWhiteSpace(_searchText) ? null : _searchText,
            ModuleFilter = _moduleFilter == "All modules" ? null : _moduleFilter,
            HideUnknown = _hideUnknown
        };
        _root = CallTreeBuilder.Build(_session, options);
        Stats = _session.ComputeStatistics();
        UpdateStatRows();
        RebuildRows(expandInitial: true);
        OnPropertyChanged(nameof(TreemapRoot));
        OnPropertyChanged(nameof(GrowthLabel));
        OnPropertyChanged(nameof(GrowthRatio));
        OnPropertyChanged(nameof(LeakCountLabel));
    }

    private void RebuildTree()
    {
        if (_suppressFilter || _session is null) return;
        TreeBuild();
        UpdateInspector();
    }

    private void RebuildRows(bool expandInitial)
    {
        Rows.Clear();
        if (_root is null) return;
        if (expandInitial)
        {
            foreach (var child in _root.Children)
            {
                _expandedPaths.Add(PathOf(child));
                if (child.Depth < 2)
                {
                    foreach (var grand in child.Children) _expandedPaths.Add(PathOf(grand));
                }
            }
        }

        foreach (var child in _root.Children) AddRow(child, 0);

        if (_selectedNode is not null)
        {
            var match = Rows.FirstOrDefault(r => ReferenceEquals(r.Node, _selectedNode));
            if (match is not null)
            {
                _selectedRow = match;
                OnPropertyChanged(nameof(SelectedRow));
            }
        }
    }

    private void AddRow(CallTreeNode node, int depth)
    {
        string path = PathOf(node);
        bool expanded = _expandedPaths.Contains(path);
        Rows.Add(new CallTreeRow(node, depth, expanded));
        if (!expanded) return;
        foreach (var child in node.Children) AddRow(child, depth + 1);
    }

    private static string PathOf(CallTreeNode node)
    {
        var segments = new List<string>();
        var current = node;
        while (current is not null)
        {
            segments.Add(current.FrameId.ToString());
            current = current.Parent;
        }
        segments.Reverse();
        return string.Join("/", segments);
    }

    private void ToggleRow(CallTreeRow row)
    {
        string path = PathOf(row.Node);
        if (!_expandedPaths.Remove(path)) _expandedPaths.Add(path);
        RebuildRows(expandInitial: false);
    }

    private void ExpandAll()
    {
        if (_root is null) return;
        foreach (var node in Enumerate(_root)) _expandedPaths.Add(PathOf(node));
        RebuildRows(expandInitial: false);
    }

    private void CollapseAll()
    {
        _expandedPaths.Clear();
        RebuildRows(expandInitial: false);
        SelectedRow = null;
    }

    private static IEnumerable<CallTreeNode> Enumerate(CallTreeNode node)
    {
        yield return node;
        foreach (var child in node.Children)
        {
            foreach (var nested in Enumerate(child)) yield return nested;
        }
    }

    private void ResetFilters()
    {
        _suppressFilter = true;
        _searchText = string.Empty;
        _moduleFilter = "All modules";
        _minSizeValue = 0;
        _groupByModule = false;
        _hideUnknown = false;
        _suppressFilter = false;
        Raise(nameof(SearchText), nameof(MinSizeValue), nameof(MinSizeLabel), nameof(ModuleFilter), nameof(GroupByModule), nameof(HideUnknown));
        TreeBuild();
        _toasts.Show("Filters cleared", "The full capture is visible again.", ToastKind.Info);
    }

    private void SelectNode(CallTreeNode node, bool updateTreemap)
    {
        _inspectedStack = null;
        if (!ReferenceEquals(_selectedNode, node))
        {
            _selectedNode = node;
            OnPropertyChanged(nameof(SelectedNode));
        }
        UpdateInspector();
    }

    private void SelectStack(int stackId)
    {
        if (_session is null) return;
        var stack = _session.Stacks.FirstOrDefault(s => s.Id == stackId);
        if (stack is null) return;
        _selectedNode = null;
        _selectedRow = null;
        _inspectedStack = stack;
        OnPropertyChanged(nameof(SelectedRow));
        OnPropertyChanged(nameof(SelectedNode));
        UpdateInspector();
    }

    private void ClearSelection()
    {
        _selectedNode = null;
        _selectedRow = null;
        _inspectedStack = null;
        Raise(nameof(SelectedRow), nameof(SelectedNode));
        UpdateInspector();
    }

    private void ClearSelectionSilent()
    {
        _selectedNode = null;
        _selectedRow = null;
        _inspectedStack = null;
    }

    private StackRecord? _singleStack;
    private StackRecord? InspectedStack => _inspectedStack ?? (_selectedNode is null ? null : FirstStackOf(_selectedNode));

    private StackRecord? FirstStackOf(CallTreeNode node)
    {
        if (_session is null || node.StackIds.Count == 0) return null;
        _singleStack = _session.Stacks.FirstOrDefault(s => s.Id == node.StackIds[0]);
        return _singleStack;
    }

    private FrameInfo? LeafOfStack(StackRecord? stack)
    {
        if (stack is null || _session is null) return null;
        return _session.LeafFrame(stack);
    }

    public void RefreshInsights()
    {
        Insights.Clear();
        if (_session is null) return;
        foreach (var insight in InsightAnalyzer.Analyze(_session)) Insights.Add(insight);
        OnPropertyChanged(nameof(Insights));
    }

    public void RefreshHotspots()
    {
        Hotspots.Clear();
        if (_session is null) return;
        foreach (var hotspot in HotspotAnalyzer.Analyze(_session, HotspotMode.LiveBytes, 120)) Hotspots.Add(hotspot);
    }

    public void RefreshLeaks()
    {
        Leaks.Clear();
        if (_session is null) return;
        foreach (var leak in LeakAnalyzer.Analyze(_session, 60)) Leaks.Add(leak);
        OnPropertyChanged(nameof(LeakCountLabel));
    }

    private void RefreshHeaps()
    {
        Heaps.Clear();
        if (_session is null) return;
        long total = Math.Max(1, _session.Heaps.Sum(h => h.CommittedBytes));
        foreach (var heap in _session.Heaps.OrderByDescending(h => h.CommittedBytes))
        {
            Heaps.Add(new HeapRow(heap.Name, $"0x{heap.Id:X}", heap.BlockCount, heap.CommittedBytes,
                (double)heap.CommittedBytes / total, heap.IsDefault));
        }
    }

    private void UpdateSnapshotStats()
    {
        if (_session is null) return;
        SnapshotStats = _selectedSnapshot <= 0 ? Stats : _session.ComputeStatistics(_selectedSnapshot - 1);
        UpdateStatRows();
        OnPropertyChanged(nameof(SnapshotStats));
        OnPropertyChanged(nameof(SnapshotLabel));
    }

    private void UpdateStatRows()
    {
        StatRows.Clear();
        var global = Stats;
        var snapshot = _selectedSnapshot <= 0 ? Stats : _session?.ComputeStatistics(_selectedSnapshot - 1) ?? Stats;
        double max(long a, long b) => Math.Max(1, Math.Max(a, b));
        StatRows.Add(new StatRow("Usage", Humanize.Bytes(global.UsageBytes), Humanize.Bytes(snapshot.UsageBytes), (double)snapshot.UsageBytes / max(global.UsageBytes, snapshot.UsageBytes), true));
        StatRows.Add(new StatRow("Usage peak", Humanize.Bytes(global.PeakUsageBytes), Humanize.Bytes(snapshot.PeakUsageBytes), (double)snapshot.PeakUsageBytes / max(global.PeakUsageBytes, snapshot.PeakUsageBytes)));
        StatRows.Add(new StatRow("Operations", Humanize.Count(global.Operations), Humanize.Count(snapshot.Operations), (double)snapshot.Operations / max(global.Operations, snapshot.Operations)));
        StatRows.Add(new StatRow("Allocations", Humanize.Count(global.Allocations), Humanize.Count(snapshot.Allocations), (double)snapshot.Allocations / max(global.Allocations, snapshot.Allocations)));
        StatRows.Add(new StatRow("Reallocations", Humanize.Count(global.Reallocations), Humanize.Count(snapshot.Reallocations), (double)snapshot.Reallocations / max(global.Reallocations, snapshot.Reallocations)));
        StatRows.Add(new StatRow("Frees", Humanize.Count(global.Frees), Humanize.Count(snapshot.Frees), (double)snapshot.Frees / max(global.Frees, snapshot.Frees)));
        StatRows.Add(new StatRow("Live blocks", Humanize.Count(global.LiveBlocks), Humanize.Count(snapshot.LiveBlocks), (double)snapshot.LiveBlocks / max(global.LiveBlocks, snapshot.LiveBlocks)));
        StatRows.Add(new StatRow("Overhead", Humanize.Bytes(global.OverheadBytes), Humanize.Bytes(snapshot.OverheadBytes), (double)snapshot.OverheadBytes / max(global.OverheadBytes, snapshot.OverheadBytes)));
        StatRows.Add(new StatRow("Overhead peak", Humanize.Bytes(global.PeakOverheadBytes), Humanize.Bytes(snapshot.PeakOverheadBytes), (double)snapshot.PeakOverheadBytes / max(global.PeakOverheadBytes, snapshot.PeakOverheadBytes)));
    }

    private void UpdateInspector()
    {
        if (_session is null)
        {
            StackFrames.Clear();
            Contributors.Clear();
            InspectorStats = new SessionStatistics();
            InspectedSource = string.Empty;
            InspectedSourceName = string.Empty;
            _inspectedStack = null;
            RaiseInspector();
            return;
        }

        if (_selectedNode is not null)
        {
            var stacks = _selectedNode.StackIds
                .Select(id => _session.Stacks.FirstOrDefault(s => s.Id == id))
                .Where(s => s is not null)
                .Cast<StackRecord>()
                .ToList();
            InspectorStats = _session.StatsForStacks(stacks);
            BuildStackFrames(_selectedNode);
            BuildContributors(stacks);
            InspectorPath = BuildPath(_selectedNode);
            LoadSource(_selectedNode.File, _selectedNode.Line);
        }
        else if (_inspectedStack is not null)
        {
            var stack = _inspectedStack;
            InspectorStats = _session.StatsForStacks(new[] { stack });
            BuildStackFrames(stack);
            BuildContributors(new[] { stack });
            var leaf = _session.LeafFrame(stack);
            InspectorPath = _session.PathOf(stack, 12);
            LoadSource(leaf?.File ?? string.Empty, leaf?.Line ?? 0);
        }
        else
        {
            StackFrames.Clear();
            Contributors.Clear();
            InspectorStats = new SessionStatistics();
            InspectedSource = string.Empty;
            InspectedSourceName = string.Empty;
            InspectorPath = string.Empty;
        }

        RaiseInspector();
    }

    private void RaiseInspector()
    {
        Raise(nameof(InspectorTitle), nameof(InspectorModule), nameof(InspectorLocation), nameof(InspectorFile),
            nameof(InspectorLine), nameof(InspectedSource), nameof(InspectedSourceName), nameof(InspectorStats),
            nameof(InspectorPath), nameof(HasSource), nameof(HasSelection), nameof(SelectionShareLabel),
            nameof(SourceButtonLabel), nameof(CanRevealSource));
    }

    private void LoadSource(string file, int line)
    {
        InspectedSourceName = string.IsNullOrEmpty(file) ? "source" : file;
        if (string.IsNullOrEmpty(file))
        {
            InspectedSource = string.Empty;
            return;
        }

        if (_session is not null && _session.SourceFiles.TryGetValue(file, out var embedded))
        {
            InspectedSource = embedded;
            return;
        }

        if (_sourceCache.TryGetValue(file, out var cached))
        {
            InspectedSource = cached ?? string.Empty;
            return;
        }

        string text = string.Empty;
        try
        {
            if (File.Exists(file)) text = File.ReadAllText(file);
        }
        catch
        {
            text = string.Empty;
        }
        _sourceCache[file] = string.IsNullOrEmpty(text) ? null : text;
        InspectedSource = text;
    }

    private void BuildStackFrames(CallTreeNode node)
    {
        StackFrames.Clear();
        var chain = new List<CallTreeNode>();
        var current = node;
        while (current is not null && current.Parent is not null)
        {
            chain.Add(current);
            current = current.Parent;
        }
        chain.Reverse();
        int index = chain.Count - 1;
        foreach (var frameNode in chain)
        {
            StackFrames.Add(new StackFrameRow
            {
                Index = index--,
                Function = frameNode.Name,
                Module = frameNode.Module,
                Location = frameNode.Line > 0 ? $"{Path.GetFileName(frameNode.File)}:{frameNode.Line}" : "—",
                AddressLabel = frameNode.Address > 0 ? Humanize.Address(frameNode.Address) : "—",
                File = frameNode.File,
                Line = frameNode.Line,
                IsLeaf = ReferenceEquals(frameNode, node),
                IsUnknown = frameNode.IsUnknown
            });
        }
    }

    private void BuildStackFrames(StackRecord stack)
    {
        StackFrames.Clear();
        var nodes = new List<CallTreeNode>();
        for (int i = stack.Frames.Length - 1; i >= 0; i--)
        {
            var frame = _session?.GetFrame(stack.Frames[i]);
            if (frame is null) continue;
            nodes.Add(new CallTreeNode
            {
                Name = frame.DisplayFunction,
                Module = _session?.ModuleNameOf(frame) ?? "Unknown",
                File = frame.File,
                Line = frame.Line,
                Address = frame.Address,
                FrameId = frame.Id,
                IsUnknown = frame.IsUnknown
            });
        }
        for (int i = 0; i < nodes.Count; i++)
        {
            var node = nodes[i];
            StackFrames.Add(new StackFrameRow
            {
                Index = nodes.Count - 1 - i,
                Function = node.Name,
                Module = node.Module,
                Location = node.Line > 0 ? $"{Path.GetFileName(node.File)}:{node.Line}" : "—",
                AddressLabel = node.Address > 0 ? Humanize.Address(node.Address) : "—",
                File = node.File,
                Line = node.Line,
                IsLeaf = i == nodes.Count - 1,
                IsUnknown = node.IsUnknown
            });
        }
    }

    private void BuildContributors(IEnumerable<StackRecord> stacks)
    {
        Contributors.Clear();
        var list = stacks.OrderByDescending(s => s.LiveBytes).Take(8).ToList();
        long total = Math.Max(1, list.Sum(s => s.LiveBytes));
        foreach (var stack in list)
        {
            Contributors.Add(new ContributorRow(
                _session?.TitleOf(stack, 3) ?? "Unknown",
                _session?.ModuleNameOf(_session.LeafFrame(stack)) ?? "Unknown",
                stack.LiveBytes,
                stack.Allocations,
                (double)stack.LiveBytes / total));
        }
    }

    private string BuildPath(CallTreeNode node)
    {
        var parts = new List<string>();
        var current = node;
        while (current is not null)
        {
            parts.Add(current.Name);
            current = current.Parent;
        }
        parts.Reverse();
        return string.Join("  ›  ", parts);
    }

    private void CopyStack()
    {
        if (StackFrames.Count == 0) return;
        var text = string.Join(Environment.NewLine, StackFrames.Select(f => $"{f.IndexLabel}  {f.Function}  [{f.Module}]  {f.Location}"));
        try { Clipboard.SetText(text); _toasts.Success("Stack copied", $"{StackFrames.Count} frames copied to the clipboard."); }
        catch { _toasts.Warn("Clipboard unavailable", "Windows denied clipboard access."); }
    }

    private void FilterToFunction()
    {
        if (_selectedNode is null) return;
        SelectedTab = 0;
        _suppressFilter = false;
        _searchText = _selectedNode.Name;
        OnPropertyChanged(nameof(SearchText));
        TreeBuild();
        _toasts.Show("Filtered", $"Call tree narrowed to ‘{Humanize.Shorten(_selectedNode.Name, 48)}’.", ToastKind.Info);
    }

    private void OpenSource()
    {
        if (string.IsNullOrEmpty(InspectorFile))
        {
            _toasts.Warn("No source mapped", "This frame has no source file in the capture.");
            return;
        }
        if (!File.Exists(InspectorFile))
        {
            _toasts.Warn("Source not found", Humanize.ShortPath(InspectorFile, 72));
            return;
        }
        _dialogs.OpenInShell(InspectorFile);
    }

    private void CompareWithDemo()
    {
        if (_session is null) { _toasts.Warn("No capture", "Load a capture before comparing."); return; }
        if (DemoBaseline is null) { _toasts.Warn("Walkthrough unavailable", "The synthetic walkthrough could not be prepared."); return; }
        CompareTo(DemoBaseline, "Aurora · earlier capture");
    }

    private void CompareTo(MemSession baseline, string label)
    {
        if (_session is null) return;
        BaselineName = label;
        // Order matters: LiveA is the baseline column, LiveB the current capture,
        // so positive deltas read as growth.
        Diff = SessionComparer.Compare(baseline, _session);
        DiffEntries.Clear();
        foreach (var entry in Diff.Entries) DiffEntries.Add(entry);
        SelectedTab = 4;
        _toasts.Show("Comparison ready", $"{Diff.Entries.Count} backtraces compared against {label}.", ToastKind.Success);
    }

    private void ChooseBaseline()
    {
        string? path = _dialogs.OpenFile("Choose baseline capture", "MemScope capture (*.msc)|*.msc|JSON capture (*.json)|*.json|All files (*.*)|*.*");
        if (path is null) return;
        try
        {
            var baseline = SessionSerializer.Load(path);
            CompareTo(baseline, Path.GetFileName(path));
        }
        catch (Exception ex)
        {
            _toasts.Error("Baseline failed", ex.Message);
        }
    }

    public void UseDemoBaseline(MemSession demo)
    {
        CompareTo(demo, "Aurora · earlier capture");
    }

    public void UseSessionAsBaselineFor(MemSession baseline, string label) => CompareTo(baseline, label);
}
