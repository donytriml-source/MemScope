using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Threading;
using MemScope.App.Mvvm;
using MemScope.App.Services;
using MemScope.Core;
using MemScope.Core.Analysis;
using MemScope.Core.Models;
using MemScope.Core.Sessions;
using MemScope.Core.Util;

namespace MemScope.App.ViewModels;

/// <summary>
/// The shell view model: navigation, captures, exports, the command palette and toasts.
/// </summary>
public sealed class MainViewModel : ObservableObject, IDisposable
{
    private readonly IDialogService _dialogs;
    private readonly ToastService _toasts;
    private readonly DispatcherTimer _toastTimer;
    private readonly List<(ToastMessage Message, DateTime Expires)> _toastQueue = new();
    private MemSession? _session;
    private MemSession? _demo;
    private CapturePage _currentPage = CapturePage.Home;
    private bool _busy;
    private string _busyLabel = string.Empty;
    private string _statusMessage = "Waiting for a capture";
    private string _sessionName = "No capture loaded";
    private string _sessionSubtitle = "Open a capture or explore the built-in walkthrough";
    private string _sessionTarget = "—";
    private string _captureIdLabel = "—";
    private string _capturedAtLabel = "—";
    private string _durationLabel = "—";
    private string _originLabel = "CAPTURE";
    private bool _isSynthetic;
    private string _usageLabel = "—";
    private string _peakLabel = "—";
    private string _allocationsLabel = "—";
    private string _backtracesLabel = "—";
    private string _framesLabel = "—";
    private string _heapsLabel = "—";
    private string _avgBlockLabel = "—";
    private string _liveBlocksLabel = "—";
    private string _overheadLabel = "—";
    private string _snapshotCountLabel = "—";
    private string _growthLabel = "—";
    private double _growthRatio;
    private double _usageRatio;
    private List<double> _usageTrend = new();
    private string _accentName = AccentManager.Current;
    private bool _isPaletteOpen;
    private string _paletteQuery = string.Empty;
    private PaletteCommand? _selectedPaletteItem;
    private bool _disposed;

    public MainViewModel(IDialogService dialogs, ToastService toasts, AppSettings settings)
    {
        _dialogs = dialogs;
        _toasts = toasts;
        Settings = settings;

        Analysis = new AnalysisViewModel(dialogs, toasts);
        Live = new LiveViewModel(toasts, settings);
        RecentCaptures = new ObservableCollection<RecentCaptureItem>();
        Toasts = new ObservableCollection<ToastMessage>();
        PaletteItems = new ObservableCollection<PaletteCommand>();
        PaletteResults = new ObservableCollection<PaletteCommand>();

        OpenCommand = new AsyncRelayCommand(OpenAsync);
        SaveCommand = new RelayCommand(SaveCapture);
        ExportHtmlCommand = new RelayCommand(ExportHtml);
        ExportCsvCommand = new RelayCommand(ExportCsv);
        ExportJsonCommand = new RelayCommand(ExportJson);
        LoadDemoCommand = new RelayCommand(() => LoadDemoInternal(announce: true, navigate: false));
        LoadDemoAndAnalyzeCommand = new RelayCommand(() => LoadDemoInternal(announce: true, navigate: true));
        GoHomeCommand = new RelayCommand(() => SelectedNavIndex = 0);
        GoLiveCommand = new RelayCommand(() => SelectedNavIndex = 1);
        GoAnalysisCommand = new RelayCommand(() => SelectedNavIndex = 2);
        NavigateCommand = new RelayCommand(Navigate);
        OpenRecentCommand = new RelayCommand(parameter =>
        {
            if (parameter is RecentCaptureItem item) _ = OpenRecentAsync(item);
        });
        ClearRecentsCommand = new RelayCommand(ClearRecents);
        AboutCommand = new RelayCommand(() => AboutRequested?.Invoke());
        OpenPaletteCommand = new RelayCommand(OpenPalette);
        ClosePaletteCommand = new RelayCommand(ClosePalette);
        ExecutePaletteCommand = new RelayCommand(ExecutePalette);
        SetAccentCommand = new RelayCommand(parameter => SetAccent(parameter?.ToString()));
        DismissToastCommand = new RelayCommand(parameter =>
        {
            if (parameter is ToastMessage message) Toasts.Remove(message);
        });
        RunDemoWorkloadCommand = new RelayCommand(() =>
        {
            SelectedNavIndex = 1;
            Live.RunDemoCommand.Execute(null);
        });

        Analysis.SelectedTab = 0;

        _toasts.Raised += OnToastRaised;
        _toastTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(400) };
        _toastTimer.Tick += (_, _) => SweepToasts();

        BuildPalette();
        PaletteResults.Clear();
        foreach (var item in PaletteItems) PaletteResults.Add(item);

        RefreshAccentLabels();
        RefreshRecents();
    }

    public AnalysisViewModel Analysis { get; }
    public LiveViewModel Live { get; }
    public AppSettings Settings { get; }
    public ObservableCollection<RecentCaptureItem> RecentCaptures { get; }
    public ObservableCollection<ToastMessage> Toasts { get; }
    public ObservableCollection<PaletteCommand> PaletteItems { get; }
    public ObservableCollection<PaletteCommand> PaletteResults { get; }

    public AsyncRelayCommand OpenCommand { get; }
    public RelayCommand SaveCommand { get; }
    public RelayCommand ExportHtmlCommand { get; }
    public RelayCommand ExportCsvCommand { get; }
    public RelayCommand ExportJsonCommand { get; }
    public RelayCommand LoadDemoCommand { get; }
    public RelayCommand LoadDemoAndAnalyzeCommand { get; }
    public RelayCommand GoHomeCommand { get; }
    public RelayCommand GoLiveCommand { get; }
    public RelayCommand GoAnalysisCommand { get; }
    public RelayCommand NavigateCommand { get; }
    public RelayCommand OpenRecentCommand { get; }
    public RelayCommand ClearRecentsCommand { get; }
    public RelayCommand AboutCommand { get; }
    public RelayCommand OpenPaletteCommand { get; }
    public RelayCommand ClosePaletteCommand { get; }
    public RelayCommand ExecutePaletteCommand { get; }
    public RelayCommand SetAccentCommand { get; }
    public RelayCommand DismissToastCommand { get; }
    public RelayCommand RunDemoWorkloadCommand { get; }

    public event Action? AboutRequested;
    public event Action? PaletteOpened;

    public MemSession? Session => _session;
    public bool HasSession => _session is not null;
    public bool IsSynthetic => _isSynthetic;
    public string SessionName { get => _sessionName; private set => Set(ref _sessionName, value); }
    public string SessionSubtitle { get => _sessionSubtitle; private set => Set(ref _sessionSubtitle, value); }
    public string SessionTarget { get => _sessionTarget; private set => Set(ref _sessionTarget, value); }
    public string CaptureIdLabel { get => _captureIdLabel; private set => Set(ref _captureIdLabel, value); }
    public string CapturedAtLabel { get => _capturedAtLabel; private set => Set(ref _capturedAtLabel, value); }
    public string DurationLabel { get => _durationLabel; private set => Set(ref _durationLabel, value); }
    public string OriginLabel { get => _originLabel; private set => Set(ref _originLabel, value); }
    public string UsageLabel { get => _usageLabel; private set => Set(ref _usageLabel, value); }
    public string PeakLabel { get => _peakLabel; private set => Set(ref _peakLabel, value); }
    public string AllocationsLabel { get => _allocationsLabel; private set => Set(ref _allocationsLabel, value); }
    public string BacktracesLabel { get => _backtracesLabel; private set => Set(ref _backtracesLabel, value); }
    public string FramesLabel { get => _framesLabel; private set => Set(ref _framesLabel, value); }
    public string HeapsLabel { get => _heapsLabel; private set => Set(ref _heapsLabel, value); }
    public string AvgBlockLabel { get => _avgBlockLabel; private set => Set(ref _avgBlockLabel, value); }
    public string LiveBlocksLabel { get => _liveBlocksLabel; private set => Set(ref _liveBlocksLabel, value); }
    public string OverheadLabel { get => _overheadLabel; private set => Set(ref _overheadLabel, value); }
    public string SnapshotCountLabel { get => _snapshotCountLabel; private set => Set(ref _snapshotCountLabel, value); }
    public string HeapSummaryLabel => $"{HeapsLabel} heaps · {LiveBlocksLabel} live blocks";
    public string GrowthLabel { get => _growthLabel; private set => Set(ref _growthLabel, value); }
    public double GrowthRatio { get => _growthRatio; private set => Set(ref _growthRatio, value); }
    public double UsageRatio { get => _usageRatio; private set => Set(ref _usageRatio, value); }
    public IReadOnlyList<double> UsageTrend => _usageTrend;
    public bool HasRecents => RecentCaptures.Count > 0;

    public bool IsBusy { get => _busy; private set => Set(ref _busy, value); }
    public string BusyLabel { get => _busyLabel; private set => Set(ref _busyLabel, value); }
    public string StatusMessage { get => _statusMessage; private set => Set(ref _statusMessage, value); }

    public CapturePage CurrentPage
    {
        get => _currentPage;
        private set
        {
            if (!Set(ref _currentPage, value)) return;
            Raise(nameof(IsHome), nameof(IsLive), nameof(IsAnalysis));
        }
    }

    public int SelectedNavIndex
    {
        get => (int)_currentPage;
        set
        {
            var page = (CapturePage)Math.Clamp(value, 0, 2);
            if (page == _currentPage) return;
            CurrentPage = page;
            Settings.LastPage = page.ToString();
            SettingsStore.Save(Settings);
            if (page == CapturePage.Live) _ = Live.OnNavigatedToAsync();
        }
    }

    public bool IsHome => _currentPage == CapturePage.Home;
    public bool IsLive => _currentPage == CapturePage.Live;
    public bool IsAnalysis => _currentPage == CapturePage.Analysis;

    public string AccentName { get => _accentName; private set => Set(ref _accentName, value); }
    public string AccentLabel => AccentManager.Get(_accentName).Label;
    public IReadOnlyList<AccentManager.Accent> AccentPresets => AccentManager.Presets;

    public bool IsPaletteOpen
    {
        get => _isPaletteOpen;
        private set => Set(ref _isPaletteOpen, value);
    }

    public string PaletteQuery
    {
        get => _paletteQuery;
        set
        {
            if (!Set(ref _paletteQuery, value)) return;
            FilterPalette();
        }
    }

    public PaletteCommand? SelectedPaletteItem
    {
        get => _selectedPaletteItem;
        set => Set(ref _selectedPaletteItem, value);
    }

    public async Task InitializeAsync()
    {
        RefreshRecents();
        string? lastPath = Settings.LastCapturePath;
        if (!string.IsNullOrWhiteSpace(lastPath) && File.Exists(lastPath))
        {
            await LoadPathAsync(lastPath, announce: false, navigate: false);
        }
        else
        {
            LoadDemoInternal(announce: false, navigate: false);
        }

        if (Enum.TryParse<CapturePage>(Settings.LastPage, out var page) && page != CapturePage.Live)
            CurrentPage = page;
        else
            CurrentPage = CapturePage.Home;

        StatusMessage = _session is null ? "Idle" : $"Capture ready · {_session.Metadata.TargetProcess}";
        Raise(nameof(StatusMessage));
    }

    public async Task LoadPathAsync(string path, bool announce = true, bool navigate = true)
    {
        if (IsBusy) return;
        IsBusy = true;
        BusyLabel = "Decoding capture…";
        StatusMessage = "Decoding capture";
        try
        {
            var session = await Task.Run(() => SessionSerializer.Load(path));
            ApplySession(session);
            Settings.LastCapturePath = path;
            AddRecent(path);
            if (navigate) SelectedNavIndex = 2;
            if (announce) _toasts.Success("Capture loaded", session.Describe());
            StatusMessage = $"Capture ready · {session.Metadata.TargetProcess}";
        }
        catch (Exception ex)
        {
            _toasts.Error("Could not open capture", ex.Message);
            StatusMessage = "Capture could not be decoded";
        }
        finally
        {
            IsBusy = false;
            BusyLabel = string.Empty;
        }
    }

    private async Task OpenAsync()
    {
        string? path = _dialogs.OpenFile(
            "Open MemScope capture",
            "MemScope capture (*.msc)|*.msc|JSON capture (*.json)|*.json|All files (*.*)|*.*");
        if (path is not null) await LoadPathAsync(path);
    }

    private async Task OpenRecentAsync(RecentCaptureItem item)
    {
        if (!item.Exists)
        {
            _toasts.Warn("File not found", Humanize.ShortPath(item.Path, 72));
            return;
        }
        await LoadPathAsync(item.Path);
    }

    private void LoadDemoInternal(bool announce, bool navigate)
    {
        _demo ??= DemoSessionFactory.Create();
        Analysis.DemoBaseline = DemoSessionFactory.CreateBaseline();
        ApplySession(_demo);
        if (navigate) SelectedNavIndex = 2;
        StatusMessage = "Walkthrough loaded · Aurora Studio";
        if (announce) _toasts.Show("Walkthrough loaded", "Aurora Studio · 47 backtraces · 12 snapshots.", ToastKind.Success);
    }

    private void ApplySession(MemSession session)
    {
        _session = session;
        Analysis.Load(session);

        var stats = Analysis.Stats;
        var timeline = Analysis.Timeline;
        SessionName = session.Metadata.Name;
        SessionSubtitle = Analysis.SessionSubtitle;
        SessionTarget = session.Metadata.TargetProcess;
        CaptureIdLabel = Analysis.CaptureIdLabel;
        CapturedAtLabel = session.Metadata.DisplayDate;
        DurationLabel = session.Metadata.DisplayDuration;
        OriginLabel = string.IsNullOrWhiteSpace(session.Metadata.Origin) ? "CAPTURE" : session.Metadata.Origin.ToUpperInvariant();
        _isSynthetic = session.Metadata.IsSynthetic;
        OnPropertyChanged(nameof(IsSynthetic));
        UsageLabel = Humanize.Bytes(stats.UsageBytes);
        PeakLabel = Humanize.Bytes(stats.PeakUsageBytes);
        AllocationsLabel = Humanize.Count(stats.Allocations);
        BacktracesLabel = Humanize.Count(session.Stacks.Count);
        FramesLabel = Humanize.Count(session.Frames.Count);
        HeapsLabel = Humanize.Count(session.Heaps.Count);
        AvgBlockLabel = Humanize.Bytes(stats.AverageBlockSize);
        LiveBlocksLabel = Humanize.Count(stats.LiveBlocks);
        OverheadLabel = Humanize.Bytes(stats.OverheadBytes);
        SnapshotCountLabel = $"{session.Snapshots.Count} snapshots";
        GrowthLabel = timeline is null ? "—" : Humanize.SignedBytes(timeline.Delta);
        GrowthRatio = timeline?.GrowthRatio ?? 0;
        UsageRatio = stats.PeakUsageBytes <= 0 ? 0 : Math.Clamp((double)stats.UsageBytes / stats.PeakUsageBytes, 0, 1);
        _usageTrend = timeline is null ? new List<double>() : timeline.Points.Select(p => (double)p.UsageBytes).ToList();
        Raise(nameof(UsageTrend), nameof(HasSession), nameof(AccentLabel), nameof(HeapSummaryLabel));
        Raise(nameof(StatusMessage));
    }

    private void SaveCapture()
    {
        if (_session is null)
        {
            _toasts.Warn("Nothing to save", "Load a capture before saving it.");
            return;
        }
        string defaultName = SafeName(_session.Metadata.TargetProcess) + "-" + DateTime.Now.ToString("yyyyMMdd-HHmm") + Branding.SessionExtension;
        string? path = _dialogs.SaveFile("Save MemScope capture", "MemScope capture (*.msc)|*.msc", defaultName);
        if (path is null) return;
        try
        {
            SessionSerializer.Save(_session, path);
            AddRecent(path);
            _toasts.Success("Capture saved", Humanize.ShortPath(path, 64));
        }
        catch (Exception ex)
        {
            _toasts.Error("Save failed", ex.Message);
        }
    }

    private void ExportHtml() => Export(
        "MemScope dossier (*.html)|*.html", ".html",
        (session, path) => SessionExporter.ExportHtmlReport(session, path), "HTML dossier");

    private void ExportCsv() => Export(
        "Call tree CSV (*.csv)|*.csv", ".csv",
        (session, path) => SessionExporter.ExportFlattenedCallTreeCsv(session, Analysis.TreemapRoot ?? CallTreeBuilder.Build(session), path),
        "Call tree CSV");

    private void ExportJson() => Export(
        "Metrics JSON (*.json)|*.json", ".json",
        (session, path) => SessionExporter.ExportMetricsJson(session, path), "Metrics JSON");

    private void Export(string filter, string extension, Action<MemSession, string> writer, string label)
    {
        if (_session is null)
        {
            _toasts.Warn("Nothing to export", "Load a capture before exporting.");
            return;
        }
        string defaultName = SafeName(_session.Metadata.TargetProcess) + "-" + DateTime.Now.ToString("yyyyMMdd-HHmm") + extension;
        string? path = _dialogs.SaveFile($"Export {label}", filter, defaultName);
        if (path is null) return;
        try
        {
            writer(_session, path);
            _toasts.Success($"{label} exported", Humanize.ShortPath(path, 64));
        }
        catch (Exception ex)
        {
            _toasts.Error("Export failed", ex.Message);
        }
    }

    private static string SafeName(string name)
    {
        foreach (char c in Path.GetInvalidFileNameChars()) name = name.Replace(c, '-');
        return string.IsNullOrWhiteSpace(name) ? "MemScope-capture" : name;
    }

    private void Navigate(object? parameter)
    {
        switch (parameter)
        {
            case CapturePage page:
                SelectedNavIndex = (int)page;
                break;
            case int index:
                SelectedNavIndex = index;
                break;
            case string text when int.TryParse(text, out int parsed):
                SelectedNavIndex = parsed;
                break;
            case string text:
                SelectedNavIndex = text.ToLowerInvariant() switch
                {
                    "live" => 1,
                    "analysis" or "analyse" => 2,
                    _ => 0
                };
                break;
        }
    }

    private void RefreshRecents()
    {
        RecentCaptures.Clear();
        foreach (string path in Settings.RecentCaptures.Distinct(StringComparer.OrdinalIgnoreCase).Take(8))
        {
            bool exists = File.Exists(path);
            string date = "Unknown date";
            string size = "—";
            if (exists)
            {
                try
                {
                    var info = new FileInfo(path);
                    date = info.LastWriteTime.ToString("MMM d · HH:mm");
                    size = Humanize.Bytes(info.Length);
                }
                catch
                {
                    // Keep the fallback labels.
                }
            }
            RecentCaptures.Add(new RecentCaptureItem(Path.GetFileName(path), path, date, size, exists));
        }
        OnPropertyChanged(nameof(HasRecents));
    }

    private void AddRecent(string path)
    {
        string full = Path.GetFullPath(path);
        Settings.RecentCaptures.RemoveAll(p => string.Equals(p, full, StringComparison.OrdinalIgnoreCase));
        Settings.RecentCaptures.Insert(0, full);
        if (Settings.RecentCaptures.Count > 8) Settings.RecentCaptures.RemoveRange(8, Settings.RecentCaptures.Count - 8);
        SettingsStore.Save(Settings);
        RefreshRecents();
    }

    private void ClearRecents()
    {
        Settings.RecentCaptures.Clear();
        SettingsStore.Save(Settings);
        RefreshRecents();
        _toasts.Show("Recent list cleared", "Your captures stay on disk — only the shortcut list was cleared.", ToastKind.Info);
    }

    private void SetAccent(string? name)
    {
        var accent = AccentManager.Get(name);
        AccentManager.Apply(accent.Name);
        Settings.Accent = accent.Name;
        SettingsStore.Save(Settings);
        AccentName = accent.Name;
        Raise(nameof(AccentLabel), nameof(AccentName));
        _toasts.Show("Accent applied", $"{accent.Label} is now the active palette.", ToastKind.Success);
    }

    /// <summary>Applies a palette for this session only — used by screenshot/preview runs.</summary>
    public void PreviewAccent(string? name)
    {
        var accent = AccentManager.Get(name);
        AccentManager.Apply(accent.Name);
        AccentName = accent.Name;
        Raise(nameof(AccentLabel), nameof(AccentName));
    }

    private void RefreshAccentLabels()
    {
        _accentName = AccentManager.Get(Settings.Accent).Name;
        OnPropertyChanged(nameof(AccentName));
        OnPropertyChanged(nameof(AccentLabel));
    }

    private void OpenPalette()
    {
        PaletteQuery = string.Empty;
        FilterPalette();
        SelectedPaletteItem = PaletteResults.FirstOrDefault();
        IsPaletteOpen = true;
        PaletteOpened?.Invoke();
    }

    private void ClosePalette()
    {
        IsPaletteOpen = false;
        PaletteQuery = string.Empty;
        SelectedPaletteItem = null;
    }

    private void ExecutePalette(object? parameter)
    {
        var command = parameter as PaletteCommand ?? SelectedPaletteItem;
        ClosePalette();
        if (command is null) return;
        try
        {
            command.Execute();
        }
        catch (Exception ex)
        {
            _toasts.Error("Command failed", ex.Message);
        }
    }

    private void FilterPalette()
    {
        PaletteResults.Clear();
        string needle = PaletteQuery.Trim();
        foreach (var item in PaletteItems)
        {
            if (needle.Length == 0
                || item.Title.Contains(needle, StringComparison.OrdinalIgnoreCase)
                || item.Group.Contains(needle, StringComparison.OrdinalIgnoreCase)
                || item.Hint.Contains(needle, StringComparison.OrdinalIgnoreCase))
            {
                PaletteResults.Add(item);
            }
        }
        SelectedPaletteItem = PaletteResults.FirstOrDefault();
    }

    private void BuildPalette()
    {
        void Add(string group, string title, string hint, string shortcut, Action execute) =>
            PaletteItems.Add(new PaletteCommand(group, title, hint, shortcut, execute));

        Add("Capture", "Open capture…", "Decode a .msc capture from disk", "Ctrl O", () => OpenCommand.Execute(null));
        Add("Capture", "Save capture as…", "Write the current capture to a .msc file", "Ctrl S", SaveCapture);
        Add("Capture", "Export HTML dossier", "Branded, self-contained report", "Ctrl E", ExportHtml);
        Add("Capture", "Export call tree CSV", "Flattened inclusive call tree", string.Empty, ExportCsv);
        Add("Capture", "Export metrics JSON", "Machine-readable capture summary", string.Empty, ExportJson);
        Add("Capture", "Load Aurora walkthrough", "Synthetic showcase capture with source", "Ctrl D", () => LoadDemoInternal(announce: true, navigate: true));
        Add("Capture", "Clear recent captures", "Forget shortcut entries only", string.Empty, ClearRecents);

        Add("Navigate", "Go to Home", "Capture dossier and observations", "Ctrl 1", () => SelectedNavIndex = 0);
        Add("Navigate", "Go to Live monitor", "Attach to a running Windows process", "Ctrl 2", () => SelectedNavIndex = 1);
        Add("Navigate", "Go to Analysis", "Call tree, hotspots, leaks and treemap", "Ctrl 3", () => SelectedNavIndex = 2);

        Add("Analyse", "Show call tree", "Inclusive allocation paths", string.Empty, () => OpenAnalysisTab(0));
        Add("Analyse", "Show hotspots", "Backtraces ranked by pressure", string.Empty, () => OpenAnalysisTab(1));
        Add("Analyse", "Show leak candidates", "Retention heuristics", string.Empty, () => OpenAnalysisTab(2));
        Add("Analyse", "Show heap treemap", "Squarified heap composition", string.Empty, () => OpenAnalysisTab(3));
        Add("Analyse", "Show capture comparison", "Diff against a baseline", string.Empty, () => OpenAnalysisTab(4));
        Add("Analyse", "Compare with walkthrough", "Diff against an earlier Aurora capture", string.Empty, () =>
        {
            SelectedNavIndex = 2;
            _demo ??= DemoSessionFactory.Create();
            Analysis.DemoBaseline ??= DemoSessionFactory.CreateBaseline();
            Analysis.UseDemoBaseline(Analysis.DemoBaseline);
        });

        Add("Monitor", "Refresh process list", "Rescan running processes", "F5", () => { SelectedNavIndex = 1; Live.RefreshCommand.Execute(null); });
        Add("Monitor", "Attach to selected process", "Start live sampling", string.Empty, () => { SelectedNavIndex = 1; Live.AttachCommand.Execute(null); });
        Add("Monitor", "Detach from target", "Stop live sampling", string.Empty, () => { SelectedNavIndex = 1; Live.DetachCommand.Execute(null); });
        Add("Monitor", "Launch demo workload", "Start the leaky MemScope.Demo process", string.Empty, () => RunDemoWorkloadCommand.Execute(null));

        foreach (var accent in AccentManager.Presets)
        {
            var captured = accent;
            Add("Appearance", $"Accent · {captured.Label}", "Switch the identity palette", string.Empty, () => SetAccent(captured.Name));
        }

        Add("Help", "About MemScope", "Identity, credits and capture format", string.Empty, () => AboutRequested?.Invoke());
        Add("Help", "Open project page", Branding.GitHub, string.Empty, () => _dialogs.OpenInShell(Branding.GitHub));
    }

    private void OpenAnalysisTab(int tab)
    {
        SelectedNavIndex = 2;
        Analysis.SelectedTab = tab;
    }

    private void OnToastRaised(ToastMessage message)
    {
        var dispatcher = Application.Current?.Dispatcher;
        if (dispatcher is not null && !dispatcher.CheckAccess())
        {
            dispatcher.BeginInvoke(new Action(() => OnToastRaised(message)));
            return;
        }
        _toastQueue.RemoveAll(t => t.Message.Title == message.Title && t.Message.Message == message.Message);
        Toasts.Add(message);
        _toastQueue.Add((message, DateTime.UtcNow.AddSeconds(4.6)));
        while (Toasts.Count > 4)
        {
            var oldest = Toasts[0];
            Toasts.RemoveAt(0);
            _toastQueue.RemoveAll(t => ReferenceEquals(t.Message, oldest));
        }
        if (!_toastTimer.IsEnabled) _toastTimer.Start();
    }

    private void SweepToasts()
    {
        var now = DateTime.UtcNow;
        for (int i = _toastQueue.Count - 1; i >= 0; i--)
        {
            if (_toastQueue[i].Expires > now) continue;
            Toasts.Remove(_toastQueue[i].Message);
            _toastQueue.RemoveAt(i);
        }
        if (_toastQueue.Count == 0) _toastTimer.Stop();
    }

    public void RaiseExternalToast(string title, string message, ToastKind kind = ToastKind.Info) =>
        OnToastRaised(new ToastMessage(title, message, kind));

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _toasts.Raised -= OnToastRaised;
        _toastTimer.Stop();
        Live.Dispose();
    }
}
