using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows.Data;
using System.Windows.Threading;
using MemScope.App.Mvvm;
using MemScope.App.Services;
using MemScope.Core.Analysis;
using MemScope.Core.Models;
using MemScope.Core.Native;
using MemScope.Core.Util;

namespace MemScope.App.ViewModels;

public sealed class LiveViewModel : ObservableObject, IDisposable
{
    private readonly ToastService _toasts;
    private readonly AppSettings _settings;
    private readonly DispatcherTimer _timer;
    private readonly List<LiveSample> _history = new();
    private LiveTarget? _target;
    private ProcessDescriptor? _selectedProcess;
    private string _filterText = string.Empty;
    private bool _isAttached;
    private bool _isAttaching;
    private bool _busy;
    private bool _deepSampling = true;
    private int _sampleIntervalIndex = 1;
    private LiveSample? _sample;
    private LiveSample? _lastDeepSample;
    private TimelineSeries? _timeline;
    private HistogramData? _blockHistogram;
    private string _statusText = "Select a process to begin monitoring.";
    private string _targetTitle = "No target attached";
    private string _targetSubtitle = "MemScope reads the target through the Windows memory APIs — no injection.";
    private string _targetPath = string.Empty;
    private string _warning = string.Empty;
    private int _deepCounter;
    private DateTimeOffset _attachedAt;
    private double _cpuPercent;
    private List<double> _workingSetTrend = new();
    private List<double> _privateTrend = new();
    private List<double> _cpuTrend = new();
    private string _processCountLabel = "Scanning…";

    public LiveViewModel(ToastService toasts, AppSettings settings)
    {
        _toasts = toasts;
        _settings = settings;

        RefreshCommand = new AsyncRelayCommand(() => RefreshAsync(silent: false));
        AttachCommand = new AsyncRelayCommand(AttachAsync, () => !_isAttaching && !_isAttached && SelectedProcess is not null);
        DetachCommand = new RelayCommand(Detach, () => _isAttached);
        RunDemoCommand = new RelayCommand(RunDemo);
        ClearHistoryCommand = new RelayCommand(ClearHistory, () => _isAttached);

        _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(300) };
        _timer.Tick += async (_, _) => await TickAsync();

        Processes = new ObservableCollection<ProcessDescriptor>();
        Heaps = new ObservableCollection<LiveHeap>();
        Modules = new ObservableCollection<LiveModule>();
        Regions = new ObservableCollection<MemoryRegionInfo>();
        ProcessView = CollectionViewSource.GetDefaultView(Processes);
        ProcessView.Filter = FilterProcess;
        ProcessView.SortDescriptions.Add(new SortDescription(nameof(ProcessDescriptor.HasWindow), ListSortDirection.Descending));
        ProcessView.SortDescriptions.Add(new SortDescription(nameof(ProcessDescriptor.WorkingSetBytes), ListSortDirection.Descending));

        _sampleIntervalIndex = settings.SamplingIntervalMs switch
        {
            <= 200 => 0,
            >= 1000 => 3,
            >= 500 => 2,
            _ => 1
        };

        _deepSampling = settings.DeepSampling;
    }

    public ObservableCollection<ProcessDescriptor> Processes { get; }
    public ICollectionView ProcessView { get; }
    public ObservableCollection<LiveHeap> Heaps { get; }
    public ObservableCollection<LiveModule> Modules { get; }
    public ObservableCollection<MemoryRegionInfo> Regions { get; }

    public AsyncRelayCommand RefreshCommand { get; }
    public AsyncRelayCommand AttachCommand { get; }
    public RelayCommand DetachCommand { get; }
    public RelayCommand RunDemoCommand { get; }
    public RelayCommand ClearHistoryCommand { get; }

    public LiveSample? Sample { get => _sample; private set => Set(ref _sample, value); }
    public TimelineSeries? Timeline { get => _timeline; private set => Set(ref _timeline, value); }
    public HistogramData? BlockHistogram { get => _blockHistogram; private set => Set(ref _blockHistogram, value); }
    public bool IsAttached { get => _isAttached; private set => Set(ref _isAttached, value); }
    public bool IsAttaching { get => _isAttaching; private set => Set(ref _isAttaching, value); }
    public string StatusText { get => _statusText; private set => Set(ref _statusText, value); }
    public string TargetTitle { get => _targetTitle; private set => Set(ref _targetTitle, value); }
    public string TargetSubtitle { get => _targetSubtitle; private set => Set(ref _targetSubtitle, value); }
    public string TargetPath { get => _targetPath; private set => Set(ref _targetPath, value); }
    public string Warning { get => _warning; private set { if (Set(ref _warning, value)) OnPropertyChanged(nameof(HasWarning)); } }
    public bool HasWarning => !string.IsNullOrWhiteSpace(Warning);
    public string ProcessCountLabel { get => _processCountLabel; private set => Set(ref _processCountLabel, value); }
    public double CpuPercent { get => _cpuPercent; private set { if (Set(ref _cpuPercent, value)) OnPropertyChanged(nameof(CpuLabel)); } }
    public string CpuLabel => _cpuPercent <= 0 ? "0%" : _cpuPercent < 0.1 ? "<0.1%" : $"{_cpuPercent:0.#}%";
    public IReadOnlyList<double> WorkingSetTrend => _workingSetTrend;
    public IReadOnlyList<double> PrivateTrend => _privateTrend;
    public IReadOnlyList<double> CpuTrend => _cpuTrend;
    public string SampleCountLabel => _history.Count == 0 ? "—" : $"{_history.Count} samples";
    public string LastSampleLabel => _sample is null ? "—" : _sample.Timestamp.ToString("HH:mm:ss.fff");
    public string UptimeLabel => !_isAttached ? "—" : Humanize.Elapsed(DateTimeOffset.Now - _attachedAt);
    public string GrowthLabel
    {
        get
        {
            if (_history.Count < 2) return "—";
            long first = _history[0].WorkingSetBytes;
            long last = _history[^1].WorkingSetBytes;
            return Humanize.SignedBytes(last - first);
        }
    }
    public string GrowthRatioLabel
    {
        get
        {
            if (_history.Count < 2 || _history[0].WorkingSetBytes <= 0) return "—";
            double ratio = (double)(_history[^1].WorkingSetBytes - _history[0].WorkingSetBytes) / _history[0].WorkingSetBytes;
            return (ratio >= 0 ? "+" : string.Empty) + Humanize.Percent(ratio);
        }
    }
    public string RegionSummary => Sample is null ? string.Empty : $"{Sample.RegionCount:N0} regions · {Humanize.Bytes(Sample.CommittedBytes)} committed";
    public string HeapSummary => Sample is null ? string.Empty : $"{Sample.Heaps.Count} heaps · {Humanize.Bytes(Sample.HeapBytes)}";
    public string ModuleSummary => Sample is null ? string.Empty : $"{Sample.Modules.Count} images";
    public string TargetBadge => _target is null ? "—" : $"PID {_target.ProcessId}";
    public string IntervalLabel => _sampleIntervalIndex switch { 0 => "200 ms", 2 => "500 ms", 3 => "1 s", _ => "300 ms" };
    public int SampleIntervalIndex
    {
        get => _sampleIntervalIndex;
        set
        {
            if (!Set(ref _sampleIntervalIndex, value)) return;
            int ms = value switch { 0 => 200, 2 => 500, 3 => 1000, _ => 300 };
            _timer.Interval = TimeSpan.FromMilliseconds(ms);
            _settings.SamplingIntervalMs = ms;
            Raise(nameof(IntervalLabel), nameof(StatusDetail));
        }
    }
    public bool DeepSampling
    {
        get => _deepSampling;
        set
        {
            if (!Set(ref _deepSampling, value)) return;
            _settings.DeepSampling = value;
        }
    }
    public string StatusDetail => IsAttached ? $"Sampling every {IntervalLabel} · deep scan {(DeepSampling ? "on" : "off")}" : "Live monitor idle";

    public ProcessDescriptor? SelectedProcess
    {
        get => _selectedProcess;
        set
        {
            if (!Set(ref _selectedProcess, value)) return;
            AttachCommand.RaiseCanExecuteChanged();
        }
    }

    public string FilterText
    {
        get => _filterText;
        set
        {
            if (!Set(ref _filterText, value)) return;
            ProcessView.Refresh();
        }
    }

    private bool FilterProcess(object item)
    {
        if (item is not ProcessDescriptor process) return false;
        if (string.IsNullOrWhiteSpace(_filterText)) return true;
        string needle = _filterText.Trim();
        return process.Name.Contains(needle, StringComparison.OrdinalIgnoreCase)
               || process.Id.ToString().Contains(needle, StringComparison.Ordinal)
               || (process.Path?.Contains(needle, StringComparison.OrdinalIgnoreCase) ?? false);
    }

    public async Task OnNavigatedToAsync()
    {
        if (Processes.Count == 0) await RefreshAsync(silent: true);
    }

    /// <summary>
    /// Attaches immediately to a process by name (with or without <c>.exe</c>) or PID.
    /// Backs the <c>--attach</c> command-line switch and the palette "attach by name" flow.
    /// </summary>
    public async Task<bool> AttachToAsync(string nameOrPid)
    {
        if (string.IsNullOrWhiteSpace(nameOrPid)) return false;
        if (Processes.Count == 0) await RefreshAsync(silent: true);
        if (IsAttached) Detach();

        string needle = nameOrPid.Trim();
        if (needle.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
            needle = needle[..^4];

        var match = int.TryParse(needle, out int pid)
            ? Processes.FirstOrDefault(p => p.Id == pid)
            : Processes.FirstOrDefault(p => p.Name.Equals(needle, StringComparison.OrdinalIgnoreCase))
              ?? Processes.FirstOrDefault(p => p.Name.Contains(needle, StringComparison.OrdinalIgnoreCase));

        if (match is null)
        {
            _toasts.Warn("Process not found", $"No running process matches \u201c{nameOrPid}\u201d.");
            return false;
        }

        SelectedProcess = match;
        if (!AttachCommand.CanExecute(null)) return false;
        await AttachAsync();
        return IsAttached;
    }

    private async Task RefreshAsync(bool silent)
    {
        string? previous = SelectedProcess?.Name;
        try
        {
            var list = await Task.Run(ProcessCatalog.List);
            Processes.Clear();
            foreach (var process in list) Processes.Add(process);
            ProcessCountLabel = $"{Processes.Count} processes";
            if (previous is not null)
                SelectedProcess = Processes.FirstOrDefault(p => p.Id == SelectedProcess?.Id) ?? Processes.FirstOrDefault(p => p.Name == previous);
            if (!silent)
                _toasts.Show("Process list refreshed", $"{Processes.Count} processes visible.", ToastKind.Info);
        }
        catch (Exception ex)
        {
            _toasts.Error("Process scan failed", ex.Message);
        }
    }

    private async Task AttachAsync()
    {
        var process = SelectedProcess;
        if (process is null) return;
        Detach();
        IsAttaching = true;
        StatusText = $"Attaching to {process.Name}…";
        try
        {
            var target = await Task.Run(() => new LiveTarget(process.Id));
            _target?.Dispose();
            _target = target;
            IsAttached = true;
            _attachedAt = DateTimeOffset.Now;
            _history.Clear();
            _lastDeepSample = null;
            _deepCounter = 0;
            TargetTitle = process.Name;
            TargetBadgeUpdate();
            TargetPath = target.ImagePath ?? process.Path ?? "Path unavailable";
            TargetSubtitle = $"PID {process.Id} · {Humanize.Bytes(process.WorkingSetBytes)} working set at attach";
            Warning = target.AccessWarning ?? string.Empty;
            StatusText = $"Attached to {process.Name}";
            _timer.Start();
            await SampleAsync(deep: true);
            _toasts.Success("Target attached", $"Sampling {process.Name} ({process.Id}).");
            Raise(nameof(StatusDetail), nameof(IsAttached), nameof(SampleCountLabel), nameof(UptimeLabel));
            DetachCommand.RaiseCanExecuteChanged();
            AttachCommand.RaiseCanExecuteChanged();
        }
        catch (Exception ex)
        {
            StatusText = "Attach failed";
            _toasts.Error("Could not attach", ex.Message);
        }
        finally
        {
            IsAttaching = false;
        }
    }

    private void TargetBadgeUpdate() => OnPropertyChanged(nameof(TargetBadge));

    private void Detach()
    {
        _timer.Stop();
        if (_target is not null)
        {
            _target.Dispose();
            _target = null;
        }
        bool wasAttached = IsAttached;
        IsAttached = false;
        IsAttaching = false;
        _busy = false;
        TargetTitle = "No target attached";
        TargetSubtitle = "MemScope reads the target through the Windows memory APIs — no injection.";
        TargetPath = string.Empty;
        TargetBadgeUpdate();
        Warning = string.Empty;
        StatusText = "Live monitor detached";
        Heaps.Clear();
        Modules.Clear();
        Regions.Clear();
        Sample = null;
        Timeline = null;
        BlockHistogram = null;
        CpuPercent = 0;
        Raise(nameof(StatusDetail), nameof(SampleCountLabel), nameof(UptimeLabel), nameof(GrowthLabel), nameof(GrowthRatioLabel), nameof(RegionSummary), nameof(HeapSummary), nameof(ModuleSummary));
        DetachCommand.RaiseCanExecuteChanged();
        AttachCommand.RaiseCanExecuteChanged();
        if (wasAttached) _toasts.Show("Detached", "Live sampling stopped.", ToastKind.Info);
    }

    private async Task TickAsync()
    {
        if (!IsAttached || _target is null || _busy) return;
        UptimeUpdate();
        // Deep scans walk every heap block and the whole virtual map, so they run
        // about every four seconds instead of on every tick.
        int deepEvery = Math.Max(3, 4000 / Math.Max(100, (int)_timer.Interval.TotalMilliseconds));
        bool deep = DeepSampling && (_deepCounter++ % deepEvery == 0);
        await SampleAsync(deep);
    }

    private async Task SampleAsync(bool deep)
    {
        var target = _target;
        if (target is null || _busy) return;
        _busy = true;
        try
        {
            var sample = await Task.Run(() => target.Sample(deep));
            if (sample.Error is not null)
            {
                _toasts.Warn("Target unavailable", sample.Error);
                Detach();
                return;
            }
            if (!target.IsAlive)
            {
                _toasts.Show("Target exited", "The monitored process has ended.", ToastKind.Warning);
                Detach();
                return;
            }

            Sample = sample;
            _history.Add(sample);
            if (_history.Count > 260) _history.RemoveAt(0);
            if (deep) _lastDeepSample = sample;

            if (deep)
            {
                Heaps.Clear();
                foreach (var heap in sample.Heaps) Heaps.Add(heap);
                Modules.Clear();
                foreach (var module in sample.Modules) Modules.Add(module);
                Regions.Clear();
                foreach (var region in sample.Regions) Regions.Add(region);
                BlockHistogram = BuildBlockHistogram(sample);
                Warning = sample.Warning ?? string.Empty;
                Raise(nameof(RegionSummary), nameof(HeapSummary), nameof(ModuleSummary), nameof(BlockHistogram));
            }

            CpuPercent = sample.CpuPercent;
            _workingSetTrend.Add(sample.WorkingSetBytes);
            _privateTrend.Add(sample.PrivateBytes);
            _cpuTrend.Add(sample.CpuPercent);
            if (_workingSetTrend.Count > 90) _workingSetTrend.RemoveAt(0);
            if (_privateTrend.Count > 90) _privateTrend.RemoveAt(0);
            if (_cpuTrend.Count > 90) _cpuTrend.RemoveAt(0);

            Timeline = TimelineBuilder.FromSamples(_history.Select(h => (
                h.Timestamp.ToUnixTimeMilliseconds(),
                h.WorkingSetBytes,
                h.PeakWorkingSetBytes,
                h.PagedPoolBytes + h.NonPagedPoolBytes,
                h.HeapBlocks,
                h.Heaps.Sum(x => x.BlockCount),
                0L)));
            Raise(nameof(Timeline), nameof(Sample), nameof(SampleCountLabel), nameof(LastSampleLabel),
                nameof(GrowthLabel), nameof(GrowthRatioLabel), nameof(WorkingSetTrend), nameof(PrivateTrend), nameof(CpuTrend));
        }
        catch (Exception ex)
        {
            StatusText = "Sampling error";
            _toasts.Error("Sampling failed", ex.Message);
            Detach();
        }
        finally
        {
            _busy = false;
        }
    }

    private static HistogramData BuildBlockHistogram(LiveSample sample)
    {
        var counts = new Dictionary<long, int>();
        foreach (var (size, count) in sample.BlockSizeHistogram) counts[size] = count;
        var buckets = new List<HistogramBucket>(HistogramBuilder.Ranges.Length);
        foreach (var range in HistogramBuilder.Ranges)
        {
            counts.TryGetValue(range.Min, out int count);
            buckets.Add(new HistogramBucket(
                HistogramBuilder.LabelFor(range.Min, range.Max),
                range.Min,
                range.Max,
                count,
                count * Math.Max(range.Min, 1)));
        }
        return new HistogramData
        {
            Buckets = buckets,
            TotalCount = buckets.Sum(b => b.Count),
            TotalBytes = buckets.Sum(b => b.Bytes),
            Estimated = false
        };
    }

    private void UptimeUpdate() => OnPropertyChanged(nameof(UptimeLabel));

    private void ClearHistory()
    {
        _history.Clear();
        Timeline = null;
        _workingSetTrend = new List<double>();
        _privateTrend = new List<double>();
        _cpuTrend = new List<double>();
        Raise(nameof(Timeline), nameof(WorkingSetTrend), nameof(PrivateTrend), nameof(CpuTrend), nameof(SampleCountLabel), nameof(GrowthLabel), nameof(GrowthRatioLabel));
    }

    private void RunDemo()
    {
        try
        {
            string[] candidates =
            {
                Path.Combine(AppContext.BaseDirectory, "MemScope.Demo.exe"),
                Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "MemScope.Demo", "bin", "Release", "net8.0", "MemScope.Demo.exe")),
                Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "MemScope.Demo", "bin", "Debug", "net8.0", "MemScope.Demo.exe"))
            };
            string? executable = candidates.FirstOrDefault(File.Exists);
            if (executable is null)
            {
                _toasts.Warn("Demo workload not built", "Build src/MemScope.Demo and try again, or attach to any process.");
                return;
            }

            var process = Process.Start(new ProcessStartInfo(executable)
            {
                UseShellExecute = true,
                WorkingDirectory = Path.GetDirectoryName(executable) ?? AppContext.BaseDirectory
            });
            if (process is null) return;
            _toasts.Success("Demo started", $"Attach to PID {process.Id} to watch the leak grow.");
            Task.Delay(600).ContinueWith(_ => Dispatcher.CurrentDispatcher.BeginInvoke(new Action(async () =>
            {
                await RefreshAsync(silent: true);
                SelectedProcess = Processes.FirstOrDefault(p => p.Id == process.Id);
            })));
        }
        catch (Exception ex)
        {
            _toasts.Error("Demo failed to start", ex.Message);
        }
    }

    public void Dispose()
    {
        _timer.Stop();
        _target?.Dispose();
    }
}
