using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using MemScope.App.Services;
using MemScope.App.ViewModels;
using MemScope.App.Views;

namespace MemScope.App;

public partial class MainWindow : Window
{
    private readonly MainViewModel _vm;

    public MainWindow(MainViewModel vm)
    {
        _vm = vm;
        InitializeComponent();
        DataContext = vm;
        vm.AboutRequested += ShowAbout;
        vm.PaletteOpened += FocusPalette;
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
        var settings = _vm.Settings;
        if (settings.WindowWidth >= MinWidth && settings.WindowWidth < 8000) Width = settings.WindowWidth;
        if (settings.WindowHeight >= MinHeight && settings.WindowHeight < 8000) Height = settings.WindowHeight;

        if (!double.IsNaN(settings.WindowLeft) && !double.IsNaN(settings.WindowTop)
            && settings.WindowLeft > -10000 && settings.WindowTop > -10000)
        {
            Left = settings.WindowLeft;
            Top = settings.WindowTop;
            EnsureOnScreen();
        }

        if (settings.WindowMaximized) WindowState = WindowState.Maximized;
        UpdateMaxIcon();
    }

    private void EnsureOnScreen()
    {
        double virtualLeft = SystemParameters.VirtualScreenLeft;
        double virtualTop = SystemParameters.VirtualScreenTop;
        double virtualWidth = SystemParameters.VirtualScreenWidth;
        double virtualHeight = SystemParameters.VirtualScreenHeight;
        if (Left + Width < virtualLeft + 120 || Left > virtualLeft + virtualWidth - 120) Left = virtualLeft + 60;
        if (Top + Height < virtualTop + 80 || Top > virtualTop + virtualHeight - 80) Top = virtualTop + 40;
    }

    private void Window_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        var settings = _vm.Settings;
        if (!App.CaptureMode)
        {
            var bounds = WindowState == WindowState.Normal
                ? new Rect(Left, Top, Math.Max(MinWidth, ActualWidth), Math.Max(MinHeight, ActualHeight))
                : RestoreBounds;

            if (bounds.Width > 0 && bounds.Height > 0 && !bounds.IsEmpty)
            {
                settings.WindowWidth = bounds.Width;
                settings.WindowHeight = bounds.Height;
                if (!double.IsNaN(bounds.Left) && !double.IsNaN(bounds.Top))
                {
                    settings.WindowLeft = bounds.Left;
                    settings.WindowTop = bounds.Top;
                }
            }
            settings.WindowMaximized = WindowState == WindowState.Maximized;
            SettingsStore.Save(settings);
        }
        _vm.AboutRequested -= ShowAbout;
        _vm.PaletteOpened -= FocusPalette;
        _vm.Dispose();
    }

    private void ShowAbout()
    {
        var dialog = new AboutWindow
        {
            Owner = this,
            DataContext = _vm
        };
        dialog.ShowDialog();
    }

    private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ClickCount == 2)
        {
            ToggleMaximize();
            return;
        }
        if (e.ButtonState != MouseButtonState.Pressed) return;
        try { DragMove(); } catch { /* dragging can race with maximize */ }
    }

    private void Minimize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;

    private void Maximize_Click(object sender, RoutedEventArgs e) => ToggleMaximize();

    private void ToggleMaximize() =>
        WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;

    private void Close_Click(object sender, RoutedEventArgs e) => Close();

    private void Window_StateChanged(object? sender, EventArgs e) => UpdateMaxIcon();

    private void UpdateMaxIcon()
    {
        if (MaxIcon is null) return;
        MaxIcon.Data = (Geometry)FindResource(WindowState == WindowState.Maximized ? "Icon.Restore" : "Icon.Maximize");
    }

    private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        bool ctrl = (Keyboard.Modifiers & ModifierKeys.Control) != 0;
        bool alt = (Keyboard.Modifiers & ModifierKeys.Alt) != 0;

        if (ctrl && e.Key == Key.K)
        {
            if (_vm.IsPaletteOpen) _vm.ClosePaletteCommand.Execute(null);
            else _vm.OpenPaletteCommand.Execute(null);
            e.Handled = true;
            return;
        }

        if (_vm.IsPaletteOpen)
        {
            if (e.Key == Key.Escape)
            {
                _vm.ClosePaletteCommand.Execute(null);
                e.Handled = true;
            }
            return;
        }

        if (ctrl)
        {
            switch (e.Key)
            {
                case Key.O:
                    _vm.OpenCommand.Execute(null);
                    e.Handled = true;
                    return;
                case Key.S:
                    _vm.SaveCommand.Execute(null);
                    e.Handled = true;
                    return;
                case Key.E:
                    _vm.ExportHtmlCommand.Execute(null);
                    e.Handled = true;
                    return;
                case Key.D:
                    _vm.LoadDemoAndAnalyzeCommand.Execute(null);
                    e.Handled = true;
                    return;
                case Key.D1:
                case Key.NumPad1:
                    _vm.SelectedNavIndex = 0;
                    e.Handled = true;
                    return;
                case Key.D2:
                case Key.NumPad2:
                    _vm.SelectedNavIndex = 1;
                    e.Handled = true;
                    return;
                case Key.D3:
                case Key.NumPad3:
                    _vm.SelectedNavIndex = 2;
                    e.Handled = true;
                    return;
            }
        }

        if (alt && e.Key == Key.R)
        {
            _vm.SelectedNavIndex = 1;
            _vm.Live.RefreshCommand.Execute(null);
            e.Handled = true;
            return;
        }

        if (e.Key == Key.F5)
        {
            _vm.SelectedNavIndex = 1;
            _vm.Live.RefreshCommand.Execute(null);
            e.Handled = true;
            return;
        }

        if (e.Key == Key.F1)
        {
            _vm.AboutCommand.Execute(null);
            e.Handled = true;
        }
    }

    private void FocusPalette()
    {
        Dispatcher.BeginInvoke(DispatcherPriority.Input, new Action(() =>
        {
            PaletteSearch.Focus();
            Keyboard.Focus(PaletteSearch);
            PaletteSearch.SelectAll();
            if (PaletteList.Items.Count > 0) PaletteList.SelectedIndex = 0;
        }));
    }

    private void PaletteSearch_KeyDown(object sender, KeyEventArgs e)
    {
        switch (e.Key)
        {
            case Key.Escape:
                _vm.ClosePaletteCommand.Execute(null);
                e.Handled = true;
                break;
            case Key.Enter:
                _vm.ExecutePaletteCommand.Execute(PaletteList.SelectedItem);
                e.Handled = true;
                break;
            case Key.Down:
                MovePaletteSelection(1);
                e.Handled = true;
                break;
            case Key.Up:
                MovePaletteSelection(-1);
                e.Handled = true;
                break;
        }
    }

    private void MovePaletteSelection(int delta)
    {
        if (PaletteList.Items.Count == 0) return;
        int index = PaletteList.SelectedIndex + delta;
        index = Math.Clamp(index, 0, PaletteList.Items.Count - 1);
        PaletteList.SelectedIndex = index;
        PaletteList.ScrollIntoView(PaletteList.Items[index]);
    }

    private void PaletteList_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (e.OriginalSource is not DependencyObject source) return;
        var container = ItemsControl.ContainerFromElement(PaletteList, source) as ListBoxItem;
        if (container?.DataContext is PaletteCommand command)
            _vm.ExecutePaletteCommand.Execute(command);
    }

    private void PaletteOverlay_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (ReferenceEquals(e.OriginalSource, sender))
            _vm.ClosePaletteCommand.Execute(null);
    }

    private void Window_DragOver(object sender, DragEventArgs e)
    {
        e.Effects = HasCapturePayload(e.Data) ? DragDropEffects.Copy : DragDropEffects.None;
        e.Handled = true;
    }

    private void Window_Drop(object sender, DragEventArgs e)
    {
        if (!HasCapturePayload(e.Data)) return;
        if (e.Data.GetData(DataFormats.FileDrop) is string[] files)
        {
            string? capture = files.FirstOrDefault(IsCapture);
            if (capture is not null) _ = _vm.LoadPathAsync(capture);
        }
        e.Handled = true;
    }

    private static bool HasCapturePayload(IDataObject data) =>
        data.GetDataPresent(DataFormats.FileDrop) && data.GetData(DataFormats.FileDrop) is string[] files && files.Any(IsCapture);

    private static bool IsCapture(string path)
    {
        string extension = Path.GetExtension(path);
        return extension.Equals(".msc", StringComparison.OrdinalIgnoreCase)
               || extension.Equals(".json", StringComparison.OrdinalIgnoreCase);
    }
}
